# CodeAudit Agent — Security Model (Phase 7)

## 8. Persistence, API-key auth & tenant isolation (Phase 7)

- API keys are the only credential type. Issued keys are shown once at
  creation; only salted SHA-256 hashes are stored (constant-time
  compare). Revocation is immediate. Scopes: `read` ⊂ `scan` ⊂ `admin`,
  enforced per endpoint family — a `read` key cannot trigger scans
  (tested).
- `CODEAUDIT_REQUIRE_AUTH=false` is the default (backward compatible
  local demo). Any network deployment must set it to `true`
  (documented in `.env.example`); unauthenticated requests then get
  401 without distinguishing valid from invalid keys.
- Tenant isolation is enforced in the repository layer: every query is
  scoped by project→user. Cross-user access returns 404 (never 403, so
  existence is not leaked). Tested at both repository and API layers.
- Live-scan credentials supplied for async website scans are held in
  memory only and never written to the database (tested: absent from
  persisted job rows).
- SQLite database files are created with mode 0600. The schema is
  Postgres-compatible; SQLite is the dev default, Postgres the
  documented production target.
- The in-process job worker is dev-only; production needs a separate
  worker process (documented, not built).
- Metering counters (analyses, scans, AI calls per key) are recorded
  for future billing; there is no billing yet.

How the platform protects itself, its operators, and third parties.
This document describes the **implemented** controls for live website
scanning (`POST /scan/website`, `backend/services/livescan/`) and the
residual risks that remain. Nothing here is aspirational: every control
named has a hermetic test in `backend/tests/test_livescan.py`.

## 1. Target authorization (no scan without permission)

Live website scanning is a **separate capability** from repository
analysis, with its own endpoint and result contract. Scanning someone's
infrastructure without permission may be illegal; the API enforces a
two-factor authorization model **before any network I/O**:

1. **Per-host token.** The operator configures
   `CODEAUDIT_SCAN_TOKENS="host:token,host2:token2"` server-side,
   out-of-band. The request must supply the token for the target host;
   comparison uses `hmac.compare_digest`. Error messages never reveal
   whether a host is enrolled (no oracle).
2. **Explicit confirmation.** The request must set
   `"i_authorize_this_scan": true` — a per-request attestation that the
   caller is permitted to test the target.

Missing either → HTTP 403 `SCAN_UNAUTHORIZED`. With no tokens
configured, **every** scan is refused. There is no default-allow path.

## 2. SSRF guard (fail-closed, resolve-then-check)

Every outbound URL — including **each redirect hop** — passes through
`services/livescan/ssrf.py::validate_url` before any socket opens:

- Only `http`/`https` schemes; userinfo (`user:pass@host`) rejected.
- The host is resolved via `socket.getaddrinfo` and **every** resolved
  IP is checked (not the hostname string). Rejected: private (RFC 1918
  + CGNAT), loopback, link-local (including `169.254.169.254`,
  the cloud-metadata address), multicast, reserved, unspecified, and
  documentation ranges. Resolution also defeats decimal/octal/hex IP
  spellings (e.g. `http://2130706433/`).
- `localhost` / `127.0.0.1` / `::1` are rejected unless the operator
  explicitly sets `CODEAUDIT_SCAN_ALLOW_LOCALHOST=true` (intended for
  hermetic tests against a fixture server; must stay `false` in
  production).
- DNS resolution failure → blocked (fail closed).
- Redirects are followed **manually** (never by the transport) with
  re-validation per hop, capped at `CODEAUDIT_SCAN_MAX_REDIRECTS` (5);
  a redirect to an internal address or outside the scope is refused.
- `trust_env=False` on the HTTP client: proxy environment variables
  cannot reroute or bypass the guard.

**Residual risk — DNS TOCTOU.** The address checked is the address at
check time; a hostile DNS operator for the target could rebind between
the check and the connect. Connections are short-lived and redirects
re-validated, but this guard is a strong default, not a proof against a
determined attacker controlling the target's DNS.

## 3. Scope enforcement

Each scan is confined to scheme + host (+ port) + path prefix, with an
opt-in `include_subdomains` flag (default: exact host only). The crawler
follows only in-scope links; out-of-scope URLs are skipped and listed
in `urls_skipped_out_of_scope` (never fetched). Redirect targets are
scope-checked per hop by the HTTP client.

## 4. Active-probe bounds

Active checks are deliberately minimal:

- **GET-only.** No POST/PUT/DELETE, no form submission, no login flows.
- **Two probes:** a reflected-XSS canary (unique token as a query
  parameter; HTML-escaped reflections are *not* flagged) and a SQL-error
  probe (a single quote appended to ≤2 parameter values; database error
  signatures only — **no data is ever extracted**).
- **Rate-limited:** configurable delay between requests (default 250ms),
  hard request cap (default 200), page cap (default 50), per-response
  byte cap (1MB, streamed), per-request timeout (10s), and an overall
  scan wall-clock budget (300s → HTTP 504).
- **Capped confidence:** every active finding is at most MEDIUM and
  carries an explicit "requires manual verification" note. Probes
  observe; they do not prove exploitability.

## 5. Credential handling

- Scan tokens, session cookies, and `Authorization` headers are used for
  the scan only: **never logged, never stored, never echoed** in
  responses or error messages. Error logs record only the request path
  and the machine-readable error code.
- Authenticated scanning (optional `session_cookie` /
  `authorization_header`) sends the caller's own credentials only within
  the authorized scope.

## 6. Honesty constraints (what a scan does NOT claim)

- The result carries a standard disclaimer: the scan covered N URLs
  with M passive checks and K active probes; **absence of findings is
  not proof of security**.
- Active-probe findings are observations requiring manual verification,
  not confirmed vulnerabilities.
- Static-analysis findings never claim deployed exploitability; live
  findings never claim code-level root cause. The two pipelines share
  the Finding contract but are labeled by `source`
  (`deterministic` / `ai` / `live-scan`).

## 9. What is NOT yet implemented

- Scan history and retest tracking are now persisted (Phase 7); finding
  lifecycle states (acknowledged/fixed) and retest comparison belong to
  Phase 8.
- No authenticated login flows (the caller supplies session material).
- No JavaScript rendering; the crawler sees plain GET responses.
- No inter-scan rate limiting per operator (single-scan budgets only).
