# CodeAudit Agent — Engineering Audit (Phase Zero)

Date: 2026-10-02. Grounded in source inspection of `~/workspace/codeaudit-agent`
at commit state "multi-language Phase A" (303 tests green). Nothing below is
assumed from the README alone; every claim cites the module that implements it.

## 1. Existing architecture

```
POST /analyze ──┐
POST /remediate ─┴─> app/main.py (routes + error mapping only)
                        │
                        v
              agents/supervisor_agent.py  (SupervisorAgent: plan, budget,
                                           parallel specialists, fusion)
                        │  uses tool-style methods on:
                        v
              services/orchestrator.py    (AnalysisOrchestrator: fetch_repo,
                                           scan_files, parse, analyze_static,
                                           validate_findings, score_risk,
                                           investigate_with_ai)
                        │
        ┌───────────────┼───────────────────────────────┐
        v               v                               v
 services/        services/languages/            services/ai_*
 github_service   registry -> python_analyzer    nemotron_service (Nebius)
 repository_      |          javascript_analyzer  groq_service (opt-in)
 scanner          |          (tree-sitter)        provider_factory
        │         v                               ai_budget_manager (hard caps)
        │   services/static_analyzer.py           ai_context_builder (budgets)
        │   (10 Python AST detectors)             ai_result_processor (dedup)
        v                                         evidence_agent (bounded review)
 services/finding_validator.py  <── evidence hard gate (drop on mismatch)
 services/risk_engine.py        <── deterministic 0-10 score, auditable formula
 agents/finding_fusion_agent.py <── dedup + provenance stamping
```

Remediation (`POST /remediate`) reuses the same pipeline:

```
supervisor.remediate_finding
  -> FixAgent.propose (budgeted AI, cache-backed)
  -> services/patch_engine.validate_changes (fail-closed: path/line/old_text/overlap gates)
  -> remediation_engine.temporary_workspace (copytree, .git excluded, originals never touched)
  -> patch_engine.apply_validated_changes (bottom-up, symlink/root-escape refusal, disk re-verify)
  -> AFTER analysis with AI disabled (AnalysisOrchestrator + StubAIProvider)
  -> verification_engine.verify_fix (BEFORE/AFTER comparison, 6 deterministic outcomes)
```

### Real call chain for POST /analyze

1. `app/main.py::analyze` — `github_service.validate_github_url` (strict regex)
2. `temporary_repo_dir()` context manager; `orchestrator.fetch_repo` → `github_service.clone_repository` (`git clone --depth 1 --no-checkout` + `checkout -f`, arg-list subprocess, per-call timeout)
3. `supervisor.run` → `validate_github_url` (again) + `fetch_metadata` (best-effort PyGithub, 15s timeout, never raises)
4. `supervisor.run_analysis`:
   - `orch.scan_files` → `repository_scanner.scan_repository`
   - `orch.parse` → per-language `analyzer.parse_source` (registry)
   - `orch.analyze_static` → per-language `analyzer.analyze_file` (**re-parses every file** — see §6)
   - `performance_agent.detect` + `quality_agent.detect` (extra AST rules)
   - `orch.validate_findings` → `finding_validator` hard gate
   - `SharedRepositoryContext.build`
   - Security/Performance/Quality specialists in parallel (`ThreadPoolExecutor(max_workers=3)`)
   - full/economy: budgeted EvidenceAgent review (Nemotron/Groq, fail-soft)
   - `finding_fusion_agent.fuse` (dedup on file/line/detector, provenance)
   - `risk_engine.calculate_risk` (deterministic)
5. Structured `AnalysisResult` JSON (findings, risk breakdown, AI status, agent run summary, budget report).

### Trust boundaries (where untrusted content enters)

| Boundary | Module | Control |
|---|---|---|
| Repository URL (HTTP input) | `github_service.validate_github_url` | strict `^https://github\.com/owner/repo$` regex; rejects credentials-in-URL, lookalike domains |
| Cloned repo content | `repository_scanner` | ignore dirs, binary/empty/oversize skips, symlinks never followed, `safe_relative_path` escape check, file-count + payload budgets |
| File content → parsers | `code_parser`, `javascript_analyzer` | per-file try/except; syntax errors structural, never fatal |
| Detector output → API | `finding_validator` | file must exist, line must exist, evidence must be substring of the cited line (whitespace-insensitive); failures dropped + counted |
| AI output → findings | `ai_result_processor`, `nemotron_service._normalize_*` | Pydantic validation, same evidence hard gate, dedup into deterministic anchors (anchors never rewritten) |
| AI fix proposal → disk | `patch_engine` | safe-relative-path, finding's-own-file scope, exact-or-ws-loose old_text anchored to range, overlap rejection, symlink/root-escape refusal, disk re-verification; writes only inside temp workspace |
| Repo code execution | — | **never executed**: no installs, no scripts, no builds anywhere in the pipeline |

## 2. Implemented vs incomplete features

### Implemented (verified in source)

- FastAPI + Pydantic API: `GET /health`, `POST /analyze`, `POST /remediate`, `POST /remediate/batch` (`app/main.py`)
- Safe GitHub acquisition: URL validation, shallow clone, timeouts, temp-dir cleanup (`github_service.py`)
- File discovery with ignore rules + budgets (`repository_scanner.py`)
- Deep analysis: Python (10 AST detectors) + JavaScript/TypeScript (9 tree-sitter detectors) via plugin registry (`services/languages/`)
- Evidence validation hard gate (`finding_validator.py`)
- Deterministic 0–10 risk scoring with auditable breakdown (`risk_engine.py`)
- AI layer: provider abstraction, Nemotron (Nebius Token Factory) + Groq (opt-in), bounded context, retries, budgets, graceful degradation (`nemotron_service.py`, `groq_service.py`, `provider_factory.py`, `ai_budget_manager.py`, `ai_call_cache.py`)
- Multi-agent backend: supervisor, security/performance/quality specialists (parallel), evidence agent, fusion with provenance, fix agent, verification agent (`agents/`)
- Remediation: FIND → FIX → VERIFY with isolated workspace (`remediation_engine.py`, `patch_engine.py`, `verification_engine.py`)
- Markdown/dict report rendering (`report_generator.py`)
- 303 hermetic tests, demo script, env-example, pinned deps

### Incomplete / absent (matches README's own limitations)

- No dependency/supply-chain scanning, no secret scanning beyond hardcoded-secret detectors, no infra/config scanning (Dockerfile, YAML, Terraform, GH Actions)
- No live website scanning (no crawler, no HTTP probes, no ZAP adapter)
- No source-to-sink / data-flow analysis (detectors are per-file, pattern/AST-local)
- No database, no auth, no background job queue, no frontend, no Docker, no CI/CD
- No RAG / security-knowledge retrieval layer
- `code_parser.parse_file` is Python-only legacy (kept for one existing test); the registry is the real dispatch
- Performance/quality specialist AST extras are Python-oriented (they skip non-Python parsed files)

## 3. File-by-file responsibilities

### `backend/app/`
- `main.py` — route registration + exception→HTTP mapping only. Module-level `orchestrator`, `remediation_engine`, `supervisor` singletons.
- `config.py` — frozen `Settings` dataclass; all env vars with safe defaults; AI budgets, scanner limits, agent modes.

### `backend/models/`
- `schemas.py` — Pydantic contracts: `AnalysisRequest/Result`, `Finding`/`ValidatedFinding` (+`language`, AI traceability, `provenance`), `RiskResult` (+formula text), `AnalysisSummary` (accounting invariant enforced by model validator), remediation models (`FixProposal`, `FixChange`, `VerificationResult`, `RemediationResult`), AI contracts.

### `backend/services/`
- `orchestrator.py` — `AnalysisOrchestrator`: tool-style pipeline stages; `investigate_with_ai` degrades gracefully (never raises); `run_on_local_path` for hermetic use.
- `github_service.py` — URL validation, shallow clone, temp-dir CM, best-effort metadata. Typed errors → HTTP codes.
- `repository_scanner.py` — safe walk, ignore rules, budgets (`RepositoryTooLargeError` → 413), `supports_deep_analysis` via registry.
- `languages/base.py` — `LanguageAnalyzer` ABC + `ParsedSource` (parse never raises).
- `languages/registry.py` — `get_analyzer`/`supported_languages`, built from `DEEP_ANALYSIS_LANGUAGES`.
- `languages/python_analyzer.py` — adapter over `code_parser` + `static_analyzer` (zero behavior change).
- `languages/javascript_analyzer.py` — tree-sitter JS/TS/JSX/TSX parsing, 9 deterministic detectors, lazy imports.
- `code_parser.py` — Python AST symbols (functions/classes/imports); syntax errors structural.
- `static_analyzer.py` — 10 Python detectors, registry `(tree, lines, path) -> findings`; per-detector try/except.
- `finding_validator.py` — evidence hard gate (file/line/evidence-substring).
- `risk_engine.py` — `severity_weight × confidence_factor × reachability_factor`; `min(10, round(total/100))`.
- `ai_provider.py` — `AIProvider` protocol + `StubAIProvider` + result dataclasses.
- `nemotron_service.py` — live OpenAI-compatible client (Nebius default); reasoning-content fallback; structured-output parsing; `AIError` taxonomy; `_normalize_fix_payload` enforces `fix_max_changes`.
- `groq_service.py` — thin `NemotronService` subclass, honest "groq" attribution.
- `provider_factory.py` — `build_ai_provider()` (Nebius default, Groq opt-in, None when unconfigured/disabled).
- `ai_budget_manager.py` — thread-safe per-run hard caps (analysis/remediation), `AI_BUDGET_EXHAUSTED`.
- `ai_call_cache.py` — request-scoped SHA-256 cache for AI calls.
- `ai_context_builder.py` — budgeted evidence selection (24k chars, 12 files, 6k/file, 25 findings, ±15 lines).
- `ai_result_processor.py` — pure assessment application + dedup rules.
- `ai_errors.py` — typed `AI_*` codes + sanitized `SAFE_MESSAGES`.
- `remediation_engine.py` — 12-step FIND→FIX→VERIFY; isolated `temporary_workspace` (copytree, no .git, symlinks preserved-as-links).
- `patch_engine.py` — fail-closed change validation + bottom-up application inside workspace only.
- `verification_engine.py` — pure BEFORE/AFTER comparison; 6 deterministic outcomes; `verified` true only for VERIFIED.
- `fix_context_builder.py` — bounded evidence window + enclosing symbol for one finding.
- `remediation_errors.py` — typed `REMEDIATION_*` codes + sanitized messages.
- `report_generator.py` — markdown/dict rendering from `AnalysisResult` (interface-level).
- `prompts/` — versioned prompt templates (`codeaudit-*-v1`) with untrusted-data delimiters.

### `backend/agents/`
- `supervisor_agent.py` — coordinates analysis + remediation; sole budget enforcer; parallel specialists; never inspects files directly.
- `security_agent.py` — deterministic triage over validated security findings (group/rank/review-queue).
- `performance_agent.py` — conservative AST performance rules (no fake measurements); skips non-Python.
- `quality_agent.py` — analyzer detectors + conservative AST extras; skips non-Python.
- `evidence_agent.py` — single bounded Nemotron review; anchors never rewritten.
- `finding_fusion_agent.py` — deterministic dedup + provenance stamping.
- `fix_agent.py` — proposes fixes only; budgeted + cache-backed; never writes.
- `verification_agent.py` — deterministic verdict + explanation; never overrides engine.
- `contracts.py`, `registry.py`, `shared_context.py` — typed agent I/O, agent names, shared repo context.

### `backend/utils/`
- `constants.py` — ignore rules, `LANGUAGE_BY_EXTENSION`, `DEEP_ANALYSIS_LANGUAGES`, risk weights, secret hints.
- `file_utils.py` — `is_binary`, `read_text_safe`, `safe_relative_path`.

### `backend/scripts/`
- `demo.py` — hermetic end-to-end demo (free mode).
- `benchmark.py` — **added in Phase Zero**: per-stage timings on fixed fixtures (additive-only).
- `check_token_factory.py`, `smoke_nemotron.py`, `live_groq.py` — manual, network-requiring (not in CI).

## 4. Baseline test results (Phase 0.2)

```
cd ~/workspace/codeaudit-agent/backend && ../.venv/bin/python -m pytest tests/ -q
→ 303 passed, 0 failed, 0 skipped in ~4s (hermetic; no test touches the network)
```

- Warnings: 2 × pre-existing `DeprecationWarning` from `httpx` (`verify=<str>` deprecated) in `test_nemotron_reasoning.py` — upstream, not our code.
- No startup/import errors. No type-check or lint configuration exists (no mypy.ini, pyproject.toml, setup.cfg, .flake8, tox.ini) — recorded as a gap.
- `requirements.txt` / `requirements-dev.txt` pinned; no lockfile beyond pins.

## 5. Platform's own security weaknesses (found by inspection)

1. **No request correlation ID.** Logs in `main.py` handlers don't carry a per-request ID; tracing a failure across stages is manual. (Fixed in Phase One.)
2. **Unbounded input string lengths.** `AnalysisRequest.repository_url` had no `max_length` (a multi-MB JSON body is parsed before the URL regex rejects it). (Fixed in Phase One.)
3. **No analysis wall-clock budget.** File-count/payload budgets bound input size, but a pathological repo (deep trees, huge-but-under-limit files) could burn CPU indefinitely; only the clone and AI calls had timeouts. (Fixed in Phase One: `CODEAUDIT_MAX_ANALYSIS_SECONDS`.)
4. **`sorted(root.rglob("*"))` materializes the entire file list** before the `max_files` budget can trip — a repo with millions of paths could exhaust memory first. (Fixed in Phase One: lazy iteration.)
5. **Clone has no disk-usage guard.** A shallow clone of a repo with huge blobs could fill the temp disk; only timeouts bound it. Documented limitation; no portable fix applied.
6. **`fetch_metadata` does a live PyGithub call on every `/analyze`** (15s timeout, best-effort). Adds latency and an external dependency to the hot path; failure is silent but the call is unconditional.
7. **No authentication/authorization, no tenant isolation, no persistence.** Any caller can trigger scans; concurrent scans share the process. By design for the current phase; required before any multi-user exposure.
8. **AI prompts treat repo content as untrusted** (delimiters + injection defenses in prompts) — good; but there is no automated prompt-injection regression beyond unit tests on delimiters.

### Phase One disposition (2026-10-02)

Weaknesses 1–4 above were fixed in Phase One (see `docs/IMPLEMENTATION_LOG.md`):
correlation-ID middleware, `repository_url` length bounds (2048), `CODEAUDIT_MAX_ANALYSIS_SECONDS`
wall-clock budget with `ANALYSIS_TIMEOUT` → HTTP 504, and a lazy directory walk so the
`max_files` budget trips during iteration. Weaknesses 5–8 remain open and are tracked
for later phases (5: no portable disk guard; 6: metadata call still unconditional;
7: by design until Phase 7; 8: Phase 5/10 work).

## 6. Measured bottlenecks (Phase 0.4 — measured, not estimated)

Method: `backend/scripts/benchmark.py` (added Phase Zero; additive-only, drives orchestrator stages directly, free mode / StubAIProvider). 3 runs per fixture. Host: linux, Python 3.12.3. Fetch stage skipped (local fixtures).

### Fixture timings (ms, min/mean/max)

| fixture | files | scan | parse | analyze | validate | risk | full (supervisor) |
|---|---|---|---|---|---|---|---|
| js_vulnerable | 1 | 1.06/1.21/1.31 | 0.76/1.86/4.02 | 2.70/4.16/4.98 | 0.26/0.28/0.31 | 0.07/0.09/0.12 | 6.58/6.87/7.37 |
| ts_vulnerable | 1 | 1.00/1.09/1.22 | 0.70/1.13/1.99 | 1.35/1.45/1.51 | 0.08/0.10/0.11 | 0.05/0.07/0.10 | 4.75/6.00/7.25 |
| sql_injection_example | 1 | 0.98/1.01/1.06 | 0.48/0.49/0.51 | 1.08/3.05/6.70 | 0.06/0.08/0.09 | 0.04/0.05/0.06 | 4.89/6.53/8.38 |
| mixed_repository | 1 (+3 skipped) | 3.19/3.25/3.32 | 0.12/0.15/0.18 | 0.20/0.26/0.30 | 0.00/0.00/0.00 | 0.02/0.03/0.04 | 4.95/5.67/6.14 |

### Scaling probe: backend's own source tree (104 files scanned, 98 skipped)

| stage | min | mean | max (ms) |
|---|---|---|---|
| scan | 106.3 | 113.0 | 123.3 |
| parse | 230.9 | 238.1 | 246.2 |
| analyze (incl. re-parse) | 755.3 | 759.4 | 763.5 |
| full supervisor (free mode) | 1540.2 | 1581.7 | 1611.8 |

### Findings (observed, with the code that causes them)

1. **Double parsing is the dominant repeated work.** `orchestrator.parse()` parses every file
   (`analyzer.parse_source`), then `orchestrator.analyze_static()` parses every file **again**
   (`analyzer.analyze_file` → `ast.parse` / `Parser().parse`). On the 104-file tree, analyze
   (~759ms) costs ~3× parse (~238ms) largely because it re-parses. Fix belongs to Phase Two
   (6.1): pass parsed trees into the analysis stage via the `LanguageAnalyzer` interface.
2. **A fresh tree-sitter `Parser` is constructed per file per analyze call**
   (`javascript_analyzer.py:226`). Parser construction is cheap but needless; reuse per language.
3. **Supervisor overhead is modest in free mode** (~400–500ms over parse+analyze on 104 files:
   ThreadPoolExecutor fan-out, shared context, fusion, risk, summary). Not the bottleneck.
4. **Validation and risk are negligible** (<1ms on fixtures; sub-150ms on 104 files).
5. **Scan is I/O-bound and linear** (~1ms/file on fixtures, ~1.1ms/file on the tree).
6. **`/remediate` costs ~2 full analyses + workspace copy + AFTER analysis** by design
   (`supervisor.run` then `remediate_finding` re-scans; `temporary_workspace` copytrees the repo).
   Correct but expensive — incremental re-analysis is Phase Two work.
7. **First-parse latency is higher** (js_vulnerable parse max 4.02ms vs min 0.76ms): lazy
   tree-sitter import + grammar load on first use. Warm-up, not a defect.

No AI-stage timings are reported: AI is disabled in free mode and no API key exists in this
environment; AI latency/cost measurement requires a key and belongs to Phase Two (6.6).

## 7. Dependency / deployment issues

- Pinned runtime deps: fastapi, uvicorn, pydantic, PyGithub, openai, tree-sitter ×3. No known CVEs
  checked in this phase (no audit tooling configured — Phase Two/CI item).
- `openai==3.22.1` is only needed when the AI layer is configured; import is lazy in
  `nemotron_service` (verified: `test_nemotron_reasoning` covers poisoned-proxy survival).
- No Docker, no CI, no deployment config, no `.env` committed (only `.env.example`). Correct.
- `PyGithub` is used only for best-effort metadata; the clone path is pure `git` subprocess.

## 8. Dependency-aware roadmap (summary; full tracker in IMPLEMENTATION_ROADMAP.md)

1. **Phase One (this audit's follow-up):** input bounds, correlation IDs, analysis wall-clock
   budget, lazy walk — all land without touching detector behavior.
2. **Phase Two:** eliminate double parsing (needs `LanguageAnalyzer` interface change — do it
   before adding more languages, or every new analyzer inherits the 2× cost); commit-aware
   caching; background job queue (needs persistence decision first); benchmark AI stages
   once a key exists.
3. **Phase Three:** rule registry with CWE mappings; source-to-sink (needs parsed-tree reuse
   from Phase Two); benchmark corpus with precision/recall.
4. **Phase Four:** dependency/secret/config analyzers plug into `services/languages/`-style
   registries — architecture already supports this.
5. **Phase Five+:** RAG, live scanning, DB/auth/SaaS — each depends on the job/persistence
   layer from Phase Two and the finding model from Phase Three. Do not start live scanning
   before the authorization model (10.1) exists.
