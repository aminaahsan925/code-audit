# Deployment guide

One container serves everything: the API **and** the demo frontend at
`/ui` (same origin, no CORS configuration needed).

## What gets deployed

- `Dockerfile` at the repo root builds `python:3.12-slim` + backend
  deps + `backend/` + `frontend/`, running as non-root user
  `codeaudit`: `uvicorn app.main:app` on `$PORT` (default 8000).
- Health probe: `GET /health` → `{"status":"ok"}`.
- Demo UI: `https://<your-host>/ui/`

## Option A — Render (simplest)

1. New → Web Service → connect the repo → **Dockerfile** runtime.
2. Environment variables (see table below).
3. Add a Postgres database; copy its internal URL into
   `CODEAUDIT_DATABASE_URL`.
4. Health check path: `/health`.

## Option B — Railway

1. New project → Deploy from repo → it detects the Dockerfile.
2. Add Postgres plugin; set variables below.
3. Railway sets `$PORT` automatically — the Dockerfile honors it.

## Option C — Fly.io

```bash
fly launch   # it will detect the Dockerfile; say yes to Postgres
fly secrets set CODEAUDIT_REQUIRE_AUTH=true NEBIUS_API_KEY=... \
  CODEAUDIT_SCAN_TOKENS=... CODEAUDIT_DATABASE_URL=...
fly deploy
```

## Environment variables

| Variable | Required | Notes |
|---|---|---|
| `CODEAUDIT_REQUIRE_AUTH` | **yes** | `true` — keyless demo mode must be off |
| `CODEAUDIT_DATABASE_URL` | **yes** | Postgres URL (`postgresql+psycopg2://…`) |
| `NEBIUS_API_KEY` | for AI | Enables Nemotron review; without it the app runs deterministic-only (`free` mode forces this) |
| `CODEAUDIT_AGENT_MODE` | no | `free` (default, zero AI calls) / `economy` / `full` |
| `CODEAUDIT_SCAN_TOKENS` | for website scans | `host:token,host2:token2`; empty = all scans refused |
| `CODEAUDIT_WEBHOOK_URL` / `CODEAUDIT_WEBHOOK_SECRET` | no | HMAC-signed completion webhooks |
| `CODEAUDIT_MAX_ANALYSIS_SECONDS` | no | Default 600; analyses 504 past it |
| `PORT` | platform-set | Default 8000 |

Create the first admin API key after deploy (one-time, then rotate):

1. Deploy once with `CODEAUDIT_DEV_BOOTSTRAP_KEY=true`. On startup the
   server creates a dev admin user + key and prints the plaintext key
   to stdout **once** — copy it from the deploy logs immediately.
2. Redeploy with `CODEAUDIT_DEV_BOOTSTRAP_KEY=false`.
3. Issue scoped keys with that admin key:
   `POST /keys` `{"name":"demo","scopes":["scan"]}` with
   `X-API-Key: <admin-key>` — the plaintext is returned once.
4. Revoke with `DELETE /keys/{key_id}`; list with `GET /keys`.

## After deploy

1. Open `https://<your-host>/ui/` — the backend URL defaults to the
   same origin; the health dot should go green.
2. Run one `/analyze` on a small repo and one authorized
   `/scan/website` as a smoke test.
3. Check `docs/PRODUCTION.md` for the full pre-launch checklist.
