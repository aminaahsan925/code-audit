# Hackathon submission checklist — Nebius x NVIDIA

Deadline: **Friday, October 30, 2026, 5:00 PM UTC / 10:00 PM PKT**.
Track: **Best Apps & Agents**.

## Submission requirements (from Devpost)

| # | Requirement | Status |
|---|---|---|
| 1 | Built with **Nebius Token Factory or Nebius AI Cloud**, using an **NVIDIA open-source model** | ⏳ Code done (Nemotron via Nebius, `free`/`economy`/`full` modes); **live smoke test pending — needs `NEBIUS_API_KEY`** |
| 2 | **Public repo** | ⏳ Code is local-only; **push to GitHub pending approval**, then make sure visibility is public |
| 3 | **Top-level OSS license** | ✅ Apache-2.0 `LICENSE` at repo root |
| 4 | **Working demo URL** | ⏳ Deploy via `docs/DEPLOYMENT.md`, then smoke-test `/ui/` |
| 5 | **Setup / model documentation** | ✅ README (quickstart, env vars, architecture, phases); `docs/` covers security model, production, deployment |
| 6 | **Public demo video, under 3 minutes** | ⏳ Script in `docs/DEMO_VIDEO_SCRIPT.md`; recording + upload pending |

## Before submitting

- [ ] Nebius smoke test passes (economy mode, 1 budgeted call, correct
      provider attribution) — unblocks requirement 1 honestly.
- [ ] Repo pushed to `aminaahsan925/codeAudit-agent`, `main`, public.
- [ ] Demo deployed; `/ui/` loads, health dot green, one `/analyze`
      and one authorized `/scan/website` succeed on the deployed URL.
- [ ] Video recorded (< 3:00), uploaded (YouTube unlisted/public),
      linked in the submission.
- [ ] Submission text written: what it does, how Nebius/Nemotron is
      used, honest capabilities + limitations (deterministic-first,
      evidence-gated; AI enriches but never invents findings).
- [ ] `.env` / secrets audit: `git log` clean, no keys in history.
      (Nothing was ever stored — keys were transient-only.)

## What NOT to claim

- Do not claim live Nemotron results until the smoke test runs.
- Do not claim the demo scans arbitrary third-party sites — website
  scans require per-host authorization tokens by design.
- Findings are evidence-grounded observations, not confirmed exploits;
  absence of findings is not proof of security. The demo UI says this
  on every screen; the submission should too.
