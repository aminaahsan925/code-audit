# CodeAudit Agent — Implementation Log

Running record: what changed, test results, decisions, blockers, next step.
Newest entries at the bottom.

## 2026-10-02 — Phase Zero: discovery & audit

- Inventoried all of `backend/` by reading source (not just README): app, models,
  services (20 modules), agents (11 modules), utils, scripts.
- Baseline: `pytest tests/ -q` → **303 passed, 0 failed, 0 skipped** (~4s, hermetic).
  2 pre-existing httpx `DeprecationWarning`s (upstream, not our code).
- No mypy/pyproject/setup.cfg/.flake8/tox.ini — no type-check or lint configured (gap recorded).
- Added `backend/scripts/benchmark.py` (additive-only): per-stage timings on fixed
  fixtures, 3 runs each, free mode. No API contract changes.
- Measured (linux, py3.12): fixture full-pipeline 5–8ms; 104-file tree full pipeline
  ~1.54–1.61s (scan ~113ms, parse ~238ms, analyze ~759ms — analyze re-parses every
  file, the dominant repeated work; validation+risk negligible).
- Wrote `docs/ENGINEERING_AUDIT.md` (architecture, call chains, trust boundaries,
  implemented-vs-incomplete, file responsibilities, baseline, 8 platform security
  weaknesses, measured bottlenecks, dependency notes, roadmap) and
  `docs/IMPLEMENTATION_ROADMAP.md` (11 phases with ordering constraints).
- Decision: Phase One stays small and behavioral — no detector changes, no interface
  changes except additive ones.
- Next: Phase One hardening (input bounds, correlation IDs, wall-clock budget, lazy walk).

## 2026-10-02 — Phase One: backend hardening (in progress)

### Changes
1. **Correlation IDs** (`backend/app/main.py`): new `correlation_id_middleware` — echoes
   `X-Request-ID` on every response; accepts a client-supplied ID only if it matches
   `^[A-Za-z0-9_-]{1,64}$`, otherwise generates `uuid4().hex`. ID is on
   `request.state.request_id` and in the unhandled-error log line. Additive: no
   contract changes (`ErrorResponse` untouched).
2. **Input bounds** (`backend/models/schemas.py`): `repository_url` now
   `min_length=1, max_length=2048` on `AnalysisRequest`, `RemediationRequest`,
   `BatchRemediationRequest` (oversized → 422 before any work happens).
3. **Analysis wall-clock budget** (`app/config.py`, `services/repository_scanner.py`,
   `services/orchestrator.py`, `agents/supervisor_agent.py`, `app/main.py`):
   new `CODEAUDIT_MAX_ANALYSIS_SECONDS` (default 600; <= 0 disables).
   `analysis_deadline()` / `check_deadline()` in `repository_scanner.py`; new typed
   `AnalysisTimeoutError` (code `ANALYSIS_TIMEOUT`) raised from the scan loop and the
   orchestrator's parse/analyze loops; supervisor threads one deadline through all
   three stages; `remediation_engine`'s direct scans get the default deadline.
   Mapped to HTTP 504 in `app/main.py`. Documented in `backend/.env.example`.
4. **Lazy directory walk** (`services/repository_scanner.py`): `sorted(root.rglob("*"))`
   → `root.rglob("*")`. The `max_files` budget now trips during iteration instead of
   after materializing the whole path list (verified: nothing downstream depends on
   walk order — AI context builder sorts its own files, findings are sorted at the end,
   tests assert no order).

### Tests
- New `backend/tests/test_hardening.py`: 18 tests (correlation ID echo/uniqueness/
  sanitization incl. on error responses; 422 on oversized URLs for all 3 endpoints;
  deadline unit tests; scan/parse/analyze deadline enforcement; 504 mapping). All pass.
- One existing test needed adaptation: `test_api.py::test_dropped_findings_surfaced_in_summary`
  stubs `analyze_static` with `lambda scan: ...`; extended to `lambda scan, **kwargs: ...`
  for the new optional `deadline` kwarg. Intent unchanged; not a weakening.
- Full suite: **321 passed** (303 baseline + 18 new), 0 failed. 2 pre-existing httpx
  deprecation warnings unchanged.
- Benchmark re-run after changes: fixture full-pipeline 3.5–5.8ms (same ballpark as
  pre-change 5–8ms); no behavior change in timings.

### Decisions
- Per-run (not per-stage) deadline: supervisor creates one deadline and threads it
  through scan → parse → analyze, so a pathological repo can't spend the full budget
  three times over.
- `deadline=None` on `scan_repository` means "fresh deadline from settings", not
  "no deadline" — every scan is bounded by default; explicit `float('inf')` opts out.
- Did NOT implement: disk-usage guard on clone (no portable approach; stays a
  documented limitation), global request timeout (uvicorn-level concern, Phase 11).

### Blockers
- None. No new dependencies added.

### Acceptance criteria status (Phase One §5)
- 5.1 Input validation: PASS — URL length bounds + existing strict regex; tests added.
- 5.2 Safe acquisition: PASS — verified existing controls; lazy walk closes the
  materialization gap; clone disk-usage remains a documented limitation.
- 5.3 Resource limits: PASS — all declared limits verified enforced; wall-clock
  budget added with structured 504 error.
- 5.4 Error handling: PASS — correlation IDs added; all failure modes return
  sanitized structured errors (verified handlers + tests).
- 5.5 Preserve behavior: PASS — no detector/finding changes; 321/321 green.

### Next step (Phase Two)
Eliminate double parsing: extend `LanguageAnalyzer` so `analyze_file` can consume the
already-parsed tree from `parse_source` (measured: analyze ~759ms vs parse ~238ms on
104 files, ~3× cost from re-parsing). Do this BEFORE adding more languages.

## 2026-10-02 — Phase Two: performance & scalability

### Changes
1. **Parse-tree reuse (the double parse).** `LanguageAnalyzer` gains
   `analyze_parsed(relative_path, content, parsed)` (default falls back to
   `analyze_file`); `ParsedSource` carries the native tree
   (`ast.Module` / tree-sitter `Tree`, never serialized).
   - `code_parser.parse_python_tree()` added (returns `(ParsedFile, tree)`);
     `parse_python` delegates to it — zero behavior change.
   - `PythonAnalyzer.analyze_parsed` runs `static_analyzer.DETECTORS`
     directly on the retained tree (same per-detector isolation, ordering,
     IDs); `analyze_file` delegates via `parse_source`.
   - `JavaScriptAnalyzer.analyze_parsed` runs the 9 detectors on the
     retained tree via an extracted `_run_detectors` helper; `analyze_file`
     delegates via `parse_source`.
   - `orchestrator.parse()` now returns `(parsed, sources, failed)`;
     `analyze_static(scan, sources=None, deadline=None)` consumes shared
     trees when given, else the legacy per-file path. `_analyze` threads
     sources through.
   - `supervisor.run_analysis` unpacks the 3-tuple, passes sources to
     `analyze_static`, and shares `parse_trees` with specialists via the new
     `AgentContext.parse_trees` field.
   - `PerformanceAgent` / `QualityAgent` `detect()` reuse shared trees
     (were parses #3/#4 per Python file), with per-file-parse fallback.
   - Call sites updated: `remediation_engine` (unpack only),
     `test_fix_context.py`, `test_multiagent.py`, `test_api.py` (stub now
     accepts `sources`), `scripts/benchmark.py` (threads sources; adds
     `analyze_legacy` comparison stage and the 106-file `self_tree` probe).
2. **Parser reuse.** tree-sitter `Parser` instances cached per thread per
   language (`threading.local` — a `Parser` must not parse concurrently on
   two threads). Previously constructed fresh per file per analyze call.
3. **Benchmarks as tests.** New `backend/tests/test_performance.py` (11
   tests): findings-equivalence on every fixture file (legacy vs reuse),
   `analyze_file` contract, deterministic tree-vs-content proof, parse-call
   counting (0 parser calls in analyze with shared sources), min-of-5
   timing (reuse < 0.85× legacy on the 102-file tree), self-tree full scan
   < 10s budget, specialist tree-reuse equivalence, broken-fixture safety,
   per-thread parser-instance reuse.
4. **Bounded parallelism verified:** single `ThreadPoolExecutor(max_workers=3)`;
   no other executors, no asyncio fan-out. No change needed.
5. **AI budgets verified end-to-end:** thread-safe `AIBudgetManager` hard
   caps (0 / 1+1 / 4+2), supervisor sole enforcer, 60s timeout + 2 retries
   in `NemotronService`, `AI_BUDGET_EXHAUSTED` controlled status. No redesign.

### Measurements (new doc: `docs/PERFORMANCE.md`)
- 106-file self tree: analyze 654ms (reuse) vs 890ms (legacy) → **0.73×**;
  full free-mode pipeline 1304–1447ms.
- Component breakdown: raw parse 132ms, symbol extraction 140ms, detectors
  691ms on 102 deep files.
- **Correction to the Phase Zero audit:** the re-parse was ~17% of the
  analyze stage, not the dominant cost. The dominant cost is the detectors
  themselves — each of the 19 detectors walks the full tree independently.
  Recorded as the next structural bottleneck (single-pass dispatch), left
  for a future phase with its own equivalence tests.

### Tests
- Full suite: **332 passed** (321 baseline + 11 new), 0 failed, hermetic.
  2 pre-existing httpx deprecation warnings unchanged.
- One existing stub adapted (`test_api.py` lambda for the new `sources`
  parameter); intent unchanged, not a weakening.

### Decisions
- `parse()` returns a 3-tuple instead of hiding trees in orchestrator
  state (the orchestrator is a long-lived singleton; cross-request caching
  would risk stale data and leaks).
- `analyze_parsed` default falls back to `analyze_file` so any future
  analyzer keeps working without the optimization.
- Deferred per scope: durable job queue / DB (needs Phase 7), incremental
  caching (needs invalidation design), single-pass detector walk (next
  bottleneck, future phase), live-AI timings (no key in env).

### Acceptance criteria status (Phase Two §6)
- 6.1 Remove repeated work: PASS — double parse + specialist re-parses +
  per-file Parser construction eliminated; findings identical (tests).
- 6.2 Incremental analysis: DEFERRED by scope — design constraints recorded
  in `docs/PERFORMANCE.md`, not implemented.
- 6.3 Bounded parallelism: PASS — verified bounded (max_workers=3).
- 6.4 Background jobs: DEFERRED by scope — needs Phase 7 persistence.
- 6.5 API responsiveness: unchanged this phase (no job queue yet).
- 6.6 AI latency/cost: PASS (verified) — budgets, timeouts, retries
  enforced; no redesign.
- 6.7 Performance acceptance tests: PASS — `test_performance.py` +
  `docs/PERFORMANCE.md` with real measured numbers.

### Next step (Phase Three)
Rule registry with CWE mappings + precision/recall benchmark corpus. The
single-pass detector walk (measured next bottleneck) is a candidate
Phase-Three-adjacent optimization — do it with per-detector equivalence
tests before or alongside source-to-sink work, since both touch detector
traversal.

## 2026-10-02 — Phase Three: trustworthy detection engine

### Changes
1. **Rule registry** (`backend/services/languages/rule_registry.py`, new):
   all 19 detectors get a stable rule ID (`PY-SEC-001`…`JS-SEC-009`),
   CWE mapping (CWE-78/79/89/95/327/798; quality rules honestly carry
   none), OWASP Top 10 2021 mapping, severity rationale, confidence rules,
   known limitations, and remediation reference. Single source of truth for
   finding attribution, benchmark labels, and future reports.
2. **Finding schema** (`models/schemas.py`, additive): `rule_id`,
   `cwe_ids: list[str]`, `taint_trace` — all optional/defaulted, backward
   compatible. Both analyzers' `_make_finding` stamp rule_id/cwe_ids from
   the registry; unregistered producers (AI candidates) leave them unset.
3. **Source-to-sink tracing** (`backend/services/languages/taint.py`, new):
   lightweight intra-file analysis, explicitly NOT full data-flow.
   Recognized origins: function parameters + `request.*` (Python),
   parameters + `req.query/body/params` + `process.argv` (JS). Semantics:
   TAINTED → `taint_trace` note + confidence raised to HIGH (only when the
   trace is concrete); UNKNOWN → explicit uncertainty note, confidence
   unchanged; CLEAN (literal) → no note. Integrated into 5 high-value
   pairs: PY request/param→`execute()`, PY param→`os.system`/subprocess
   shell, PY param→`eval`/`exec`, JS `req.*`/param→`query()`/`execute()`,
   JS param→`child_process.exec`. Taint never creates/suppresses findings,
   never changes severity; trace functions are fail-safe (internal error →
   finding survives with original confidence).
4. **AI disagreement can no longer downgrade deterministic findings**
   (§7.5): removed the confidence demotion in
   `services/ai_result_processor.py` (`uncertain` → one step,
   `unlikely` → LOW). AI verdicts now attach `ai_reasoning`/fix only;
   confidence and severity are deterministic-only. Verified end-to-end:
   new `tests/test_fusion_ai_disagreement.py` proves a hostile "unlikely"
   verdict leaves the fused finding's confidence/severity/anchor fields
   intact while the disagreement stays visible in `ai_reasoning`.
   (The fusion agent itself never downgraded; the demotion lived upstream
   in `apply_assessments` and propagated via the supervisor's specialist
   review path — now removed at the source.)
5. **Benchmark corpus** (`backend/tests/benchmarks/`, 51 fixtures +
   `manifest.json`): per rule — vulnerable, safe, and near-miss/FP-trap
   where meaningful. `tests/test_benchmark_corpus.py` runs the REAL
   analyzers, asserts no regressions, and prints a per-rule
   precision/recall/FP-rate table. One genuine FP is documented, not
   hidden: `mixer.system()` fires `os_system` (any `.system()` attribute
   matches; see PY-SEC-007 known_limitations), labeled `known_fp` in the
   manifest — reported in the table, excluded from the regression gate.

### Measured benchmark (hermetic, 2026-10-02)

| rule | detector | P | R | FP_rate | TP/FP/FN |
|---|---|---|---|---|---|
| PY-SEC-001 | hardcoded_secret | 1.00 | 1.00 | 0.00 | 2/0/0 |
| PY-SEC-002 | sql_string_construction | 1.00 | 1.00 | 0.00 | 1/0/0 |
| PY-SEC-003 | unsafe_html_render | 1.00 | 1.00 | 0.00 | 2/0/0 |
| PY-SEC-004 | dangerous_eval | 1.00 | 1.00 | 0.00 | 1/0/0 |
| PY-SEC-005 | dangerous_exec | 1.00 | 1.00 | 0.00 | 1/0/0 |
| PY-SEC-006 | subprocess_shell_true | 1.00 | 1.00 | 0.00 | 1/0/0 |
| PY-SEC-007 | os_system | 0.50 | 1.00 | 1.00 | 1/1/0 |
| PY-SEC-008 | weak_crypto | 1.00 | 1.00 | 0.00 | 2/0/0 |
| PY-QLT-001 | long_function | 1.00 | 1.00 | 0.00 | 1/0/0 |
| PY-QLT-002 | bare_except | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-001 | js_dangerous_eval | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-002 | js_function_constructor | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-003 | js_command_injection | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-004 | js_xss_dom_sink | 1.00 | 1.00 | 0.00 | 2/0/0 |
| JS-SEC-005 | js_react_dangerous_html | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-006 | js_hardcoded_secret | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-007 | js_sql_string_construction | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-008 | js_weak_crypto | 1.00 | 1.00 | 0.00 | 1/0/0 |
| JS-SEC-009 | js_implied_eval | 1.00 | 1.00 | 0.00 | 1/0/0 |

P=precision, R=recall, FP_rate=false positives per negative fixture.
The corpus is hand-written and small; it measures current detectors, not
all real-world vulnerabilities. No accuracy claims beyond this table.

### Tests
- New: `test_rule_registry.py` (5), `test_taint.py` (13),
  `test_benchmark_corpus.py` (2), `test_fusion_ai_disagreement.py` (2).
- Updated to new intended behavior (not weakened): 2 demotion tests in
  `test_ai_result_processor.py`, 1 in `test_ai_integration.py` (AI verdicts
  now preserve confidence); stale risk-math comment in `test_api.py`
  (taint raises the fixture's SQL findings to HIGH — score still 1).
- Full suite: **355 passed** (332 baseline + 23 new), 0 failed, hermetic.
  2 pre-existing httpx deprecation warnings unchanged.

### Decisions
- Taint raises confidence ONLY on concrete traces; quality/security
  severity untouched; no interprocedural analysis (documented).
- `known_fp` manifest flag: honest FP tracking without red builds.
- AI verdicts are advisory-only from this phase on: recorded in
  `ai_reasoning`, never applied as confidence changes.

### Acceptance criteria status (Phase Three §7)
- 7.1 Finding model: PARTIAL — rule_id/cwe_ids/taint_trace added;
  full lifecycle fields (first/last seen, status, verification history)
  need Phase 7 persistence.
- 7.2 Detector quality: PASS — per-rule metadata + limitations; no
  silent behavior changes.
- 7.3 Source-to-sink: PASS — 5 pairs, conservative, uncertainty explicit.
- 7.4 Coverage: N/A — no new languages; registry documents per-rule
  language applicability.
- 7.5 Fusion: PASS — deterministic findings provably never downgraded
  by AI disagreement (tests).
- 7.6 Benchmark corpus: PASS — 51 fixtures, measured table above.

### Next step (Phase Four)
Dependency, secret, and configuration scanning as new analyzers behind
the existing registries. Taint pairs for XSS sinks (mark_safe/innerHTML
with request data) are the natural §7.3 follow-up once Phase Four lands.

---

## Phase Four — Dependency, secret & configuration scanning (2026-10-02)

### What was built
New `backend/services/supplychain/` package (10 modules) plugged into the
existing pipeline as a third analysis stage (after language analyzers):
- **Dependencies** (`manifests.py`, `advisories.py`, `dependencies.py`):
  parsers for requirements.txt, setup.py (AST only, never executed),
  pyproject.toml, Pipfile/Pipfile.lock, package.json, package-lock.json.
  `AdvisorySource` interface with `LocalAdvisoryDB` (JSON file; status
  `current|stale|unavailable`, 30-day default). Version matching via
  `packaging` (PyPI, now a pinned direct dependency) + minimal npm
  evaluator (`^ ~ >= <= > <`, exact; unparseable input never matches).
  DEP-001 (advisory match, concrete versions only), DEP-002 (fully unpinned
  only, LOW), DEP-003 (INFO when DB stale/unavailable), DEP-004 (parse error).
  No advisory data → informational inventory at most; CVEs never invented.
- **Secrets** (`secrets.py`, `redaction.py`): SECRET-001 PEM, 002 AWS
  (`AKIA`), 003 GitHub (`ghp_`/`gho_`/`github_pat_`), 004 Google (`AIza`),
  005 Stripe (`sk-live/test-`), 006 high-entropy (≥4.5, ≥12 chars,
  secret-like name, non-code files only). All evidence REDACTED
  (`sk-live-****c123`; ≤8 chars → `****`), all findings `sensitive=True`.
  Language detectors (PY-SEC-001, JS-SEC-006) now redact evidence, mark
  sensitive, and defer token-shaped values to SECRET-002…005 (no doubles).
- **Config** (`config.py`, line-based, documented as a first net):
  Dockerfile CFG-001 no USER (HIGH), 002 `:latest` (LOW), 003 secret ENV/ARG
  (HIGH, redacted), 004 ADD (LOW), 005 curl-pipe-shell (MEDIUM); GHA CFG-010
  `permissions: write-all` (HIGH), 011 `pull_request_target`+checkout (HIGH),
  012 unpinned action ref (MEDIUM); compose CFG-020 `privileged` (MEDIUM),
  021 secret in `environment:` (HIGH, redacted).
- **SBOM** (`sbom.py`): CycloneDX-inspired JSON on `AnalysisResult.sbom`
  (name, version, type, scope; unpinned → `"unspecified"`; advisory DB
  status recorded; honest non-compliance note; transitive closure NOT
  resolved).
- **Wiring**: scanner discovers new file types; `analyze_static` runs the
  supply-chain stage per file (shared advisory source, deadline checks);
  covered files move `unsupported` → `deep_analyzed` (accounting invariant
  holds); validator gained a redaction-aware gate for sensitive findings
  (ordered literal-fragment containment — NOT a bypass); `build_ai_context`
  excludes sensitive findings AND their files from all three priority
  stages; `build_fix_context` redacts windows for sensitive findings.
- 21 rules registered (DEP-001…004, SECRET-001…006,
  CFG-001…005/010…012/020…021) with CWE/OWASP, severity rationale,
  limitations. `backend/data/advisories.example.json` + manual
  `backend/scripts/refresh_advisories.py` (OSV.dev; never in tests).
  Settings: `CODEAUDIT_ADVISORY_DB`, `CODEAUDIT_ADVISORY_MAX_AGE_DAYS`.

### Verification
- Baseline 355 green before; **386/386 green** after (31 new in
  `tests/test_supplychain.py`, hermetic). Corpus extended: 20 new detectors
  with labeled fixtures in `tests/benchmarks/supplychain/` (+ synthetic
  advisory DB); manifest now 39 rules. Corpus precision/recall unchanged
  for the 19 language rules.
- Real bugs found and fixed during fixture verification: advisory DB
  fixture used a pre-implementation schema; Google fixture length vs `\b`
  pattern; entropy 4.459 < 4.5 threshold; GHA `on: pull_request_target`
  inline form undetected; compose `environment:` indent tracking broken on
  stripped lines; `is_github_workflow` missed repo-root `.github/workflows/`;
  compose env regex missed `:` mapping form; ARG secret names vs shared
  `SECRET_NAME_HINTS` (fixture uses `API_KEY`).
- Existing-test updates (intended behavior changes): JS fixture secret is
  now non-token-shaped (token shapes defer to SECRET-*); evidence
  assertions expect redacted form; rule-ID regex + rule count (39);
  `test_validator_gate_accepts_real_js_finding` now exercises the
  redaction-aware gate.

### Decisions
- Redaction is structural (evidence field), not cosmetic: the raw secret
  never exists on a sensitive Finding, so it cannot leak via AI context,
  fix windows, reports, or logs.
- DEP-001 requires a concrete version (lockfile/`==` pin); range-only
  specifiers never matched — a range match would be guessing.
- Secret findings carry file-extension language attribution (`app.js` →
  `javascript`); non-code files stay `None`.
- `packaging` pinned as a direct dependency (was transitive): justified
  for PEP 440 advisory matching. No other new dependencies.

### Acceptance criteria status (Phase Four §8)
- 8.1 Dependency analysis: PASS — 7 manifest formats, advisory matching
  with staleness semantics, no fabrication (tests).
- 8.2 Secret detection: PASS — 6 detectors + redaction + AI-context
  exclusion proven by test (`test_secrets_excluded_from_ai_context`,
  `test_fix_context_redacts_sensitive_windows`).
- 8.3 Config scanning: PASS — Dockerfile + GHA + compose, line-based
  limitations documented per rule; no new parser dependencies.
- 8.4 SBOM: PASS — structure validated in tests, honesty notes embedded.

### Next step (Phase Five)
RAG + bounded multi-agent reasoning (§9): extend the supervisor; retrieval
is knowledge-only, detectors and validators remain the source of truth.
Advisory DB refresh remains manual until Phase 7 scheduling exists.

---

## 2026-10-02 — Phase Five: RAG + bounded multi-agent reasoning (§9)

### What was built
Knowledge-ONLY retrieval over a curated local KB — it enriches AI
explanations and fix proposals, never determines whether a finding exists.
Detectors + the evidence-validator hard gate remain the sole source of truth.

- **Knowledge base** (`backend/data/knowledge/kb-v1.json`): 45 hand-written
  entries — one per registry rule (all 39 covered: PY/JS/DEP/SECRET/CFG) +
  6 general secure-coding notes (parameterized queries, subprocess without
  shell, output encoding, secret management, dependency pinning, CSP).
  Each entry: id, title, body (fix pattern + safe alternative + reference),
  rule_ids, cwe_ids, languages, source="curated", version="kb-v1".
  Documented as curated guidance, NOT a vulnerability database.
- **Retrieval** (`backend/services/knowledge/`): stdlib TF-IDF over the local
  KB, lazy-loaded and cached, deterministic ordering (tier, then -score,
  then entry id). Ranking is tag-first: rule_id match > CWE match >
  language match + text score. Pure text similarity with no tag or language
  overlap never qualifies (too weak a signal — verified: it attached
  KB-SECRET-002 to a nested-loop finding). Hard caps from Settings:
  `CODEAUDIT_KB_MAX_CHUNKS_PER_FINDING` (default 3),
  `CODEAUDIT_KB_MAX_CHARS` (default 4000). No network, no embeddings.
  Runs in every agent mode (deterministic, zero AI calls).
- **Sensitive findings get NO retrieval** (`retrieve_for_finding` returns []
  for `sensitive=True`): the Phase 4 guarantee — secret material never
  flows toward AI context — is preserved by construction, tested.
- **Evidence agent**: bounded knowledge block appended to the review prompt
  ("guidance only — NOT evidence; cite entry ids; never invent ids");
  `knowledge_used` stamped per enriched finding and on the result.
- **Fix agent**: `build_fix_context` attaches knowledge hits (FixContext
  gains a `knowledge` field); `build_fix_messages` renders the block and
  requires `knowledge_cited` in the output schema; the agent stamps
  `knowledge_used` (system truth: what was shown) and validates
  `knowledge_cited` against it (invented ids dropped). Cache key includes
  the KB version so KB edits invalidate cached proposals. The deterministic
  patch guard still validates everything.
- **Schema** (all additive): `Finding.knowledge_used`, `FixProposal.knowledge_used`
  + `knowledge_cited`, `EvidenceAgentResult.knowledge_used`.
- **Fusion**: carries `knowledge_used` from evidence enrichment onto final
  findings (was dropped — found and fixed during end-to-end verification).
- **Bounded reasoning** (`agents/reasoning_bounds.py`): `ReasoningBudget`
  with hard per-invocation step caps (1 step each: evidence review,
  specialist review, fix proposal) and a logged warning when the cap trips
  (`REASONING_STEPS_EXHAUSTED`). Wired into `EvidenceAgent.run` (checked
  before the AI budget) and the supervisor's full-mode specialist reviews.
  No provider attempt can exceed the step budget.
- **Attribution**: `report_generator` renders "Knowledge consulted: [KB-…]"
  per finding (guidance, not evidence); omitted when nothing was consulted.

### Verification
- Baseline 386 green before; **412/412 green** after (26 new in
  `tests/test_knowledge.py`, hermetic). 2 pre-existing httpx warnings unchanged.
- Real issues found and fixed during verification: (1) fusion dropped
  `knowledge_used` (now carried through, regression-tested); (2) pure-text
  retrieval attached irrelevant entries to untagged findings (tier dropped,
  tested); (3) `FixContext` needed a runtime (not TYPE_CHECKING) import of
  `KnowledgeHit` for pydantic resolution.
- End-to-end (economy mode, fake provider, demo fixture): 5/6 findings
  carry `knowledge_used`; report shows 5 "Knowledge consulted" lines.
  Free mode correctly shows none — the evidence agent is skipped, so no
  model ever saw the entries (honest provenance, not absence of retrieval).
- `scripts/demo.py` still runs clean in free mode.

### Decisions
- `knowledge_used` records only what the model actually saw — never what
  retrieval *could* have returned. Absence is honest, not a gap.
- Tier-3 (pure text, no tag/language overlap) retrieval removed rather than
  threshold-tuned: measured scores overlapped between relevant and
  irrelevant matches, so no threshold separates them honestly.
- Knowledge never reaches the model for sensitive findings even though the
  entries themselves contain no secrets — conservative enforcement of the
  Phase 4 boundary, simpler to audit than a content-based exception.

### Honesty notes
- The KB is 45 hand-written entries: useful for the 39 registry rules, not
  exhaustive, not a substitute for current vendor/advisory documentation.
- Retrieval quality was NOT benchmarked on real-world repos — only
  determinism, bounds, and tier preference are tested. No precision/recall
  claim is made for RAG.
- No live-AI timings (no API key in env).

### Acceptance criteria status (Phase Five §9)
- 9.1 RAG design: PASS — knowledge-only, bounded, local.
- 9.2 Bounded agent reasoning: PASS — explicit step budgets + trip logging.
- 9.3 Knowledge ingestion: PASS — curated JSON KB, versioned.
- 9.4 Query pipeline: PASS — tag-first TF-IDF, hard caps, deterministic.
- 9.5 Attribution: PASS — knowledge_used on findings/proposals/results;
  reports cite entries; empty section omitted, never padded.

### Remaining limitations
- KB covers only the 39 registry rules + 6 general notes; new rules need
  hand-written entries (no automatic KB expansion).
- No vector/semantic search — TF-IDF only (deliberate: zero deps, hermetic).
- Advisory DB refresh still manual until Phase 7 scheduling exists.

### Next step (Phase Six)
Authorized live website scanning (§6): target authorization model + scope
+ SSRF guard FIRST, scanner adapter second. Ordering constraint: no live
scanning before the authorization model exists.

---

## 2026-10-02 — Phase Six: authorized live website scanning (§10)

### What was built
New `backend/services/livescan/` package (9 modules), exposed as
`POST /scan/website` — a **separate capability** from repository
analysis with its own authorization model, scope enforcement, and SSRF
guard. Guards were built FIRST; the scanner cannot make a request
without passing through all of them.

- **Authorization** (`auth.py`): a scan runs ONLY with BOTH the
  per-host token configured server-side
  (`CODEAUDIT_SCAN_TOKENS="host:token,..."`, `hmac.compare_digest`)
  AND `"i_authorize_this_scan": true` in the request. Anything else →
  403 `SCAN_UNAUTHORIZED` before any network I/O. Empty token map =
  every scan refused (no default-allow). Error messages never reveal
  enrollment; tokens never logged/echoed.
- **SSRF guard** (`ssrf.py`): fail-closed `validate_url` on EVERY
  outbound URL including each redirect hop. http/https only, no
  userinfo, resolve-then-check via `getaddrinfo` with an explicit
  property blocklist (private, loopback, link-local incl.
  169.254.169.254, multicast, reserved, unspecified, documentation
  ranges) — deliberately not `is_global` alone (this Python reports
  multicast space as global). Resolution defeats decimal/octal/hex IP
  spellings. Loopback only with `CODEAUDIT_SCAN_ALLOW_LOCALHOST=true`
  (tests only). DNS failure → blocked.
- **Scope** (`scope.py`): scheme + host + port + path prefix, opt-in
  subdomains (default exact host). Crawler follows in-scope links only;
  out-of-scope URLs are skipped and listed, never fetched. Redirect
  targets scope-checked per hop by the HTTP client.
- **Guarded HTTP client** (`http.py`): manual redirect following with
  per-hop re-validation (max 5), `trust_env=False`, request/page/byte
  budgets, 250ms default inter-request delay, per-request timeout,
  response byte cap via streaming. GET-only. Auth headers/cookies
  attached per request, never logged.
- **Crawler** (`crawl.py`): stdlib `html.parser` link extraction, BFS,
  page cap (default 50). No JS rendering, no form submission.
- **Passive checks** (`checks.py`): LIVE-001…005 security headers
  (CSP/HSTS/frame-options/nosniff/referrer-policy), LIVE-006 cookie
  flags (Secure/HttpOnly/SameSite; **values never recorded**),
  LIVE-007 plain HTTP (HIGH), LIVE-008 version banners,
  LIVE-009 exposed `/.git/HEAD` + `/.env` at the scope root (HIGH;
  first bytes only, contents never stored), LIVE-010 TLS certificate
  inspection (expiry, hostname match via a small RFC-6125 matcher —
  `ssl.match_hostname` was removed in Python 3.12).
- **Active probes** (GET-only, rate-limited): LIVE-020 reflected-XSS
  canary (unique token; HTML-escaped reflections correctly NOT flagged),
  LIVE-021 SQL-error probe (single quote on ≤2 params; error signatures
  only — **no data extracted**). Every active finding capped at MEDIUM
  with an explicit "requires manual verification" note.
- **Schemas** (all additive): `FindingSource.LIVE_SCAN`,
  `Finding.url`, `WebsiteScanRequest`, `WebsiteScanResult`
  (urls_scanned, skipped, findings, checks_run, requests_made,
  truncated, disclaimer). Live findings use `file`=URL path,
  `line`=0, `url`=full URL.
- **Registry**: 12 LIVE rules (LIVE-001…010, 020, 021) with CWE/OWASP,
  severity rationale, limitations — 51 rules total.
- **KB**: 12 new curated entries (KB-LIVE-*); KB version bumped
  `kb-v1` → `kb-v2` so fix-proposal cache keys invalidate (57 entries).
- **API** (`app/main.py`): `POST /scan/website` + `LiveScanError`
  handler (403/400/429/504 mapping). Request credentials are never
  logged.
- **Docs**: new `docs/SECURITY_MODEL.md` (authorization, SSRF design +
  residual DNS-TOCTOU risk, scope, probe bounds, credential handling,
  honesty constraints); README gained the endpoint docs, a Phase 6
  section, and the legal warning; `.env.example` documents all
  `CODEAUDIT_SCAN_*` settings.

### Verification
- Baseline 412 green before; **481/481 green** after (69 new in
  `tests/test_livescan.py`, hermetic — SSRF matrix monkeypatches
  `getaddrinfo`; end-to-end runs against a threaded fixture server on
  127.0.0.1). 2 pre-existing httpx warnings unchanged.
- Real bugs found and fixed during verification: (1) `ScanScope`
  dropped the port (`parts.hostname`), so exposed-file probes went to
  port 80 and failed silently — scope now carries the port and
  `in_scope` pins it; (2) `is_global` alone lets multicast through on
  this Python — explicit property blocklist added; (3)
  `ssl.match_hostname` no longer exists (3.12) — small RFC-6125 matcher
  implemented; (4) registry/KB/corpus count invariants updated to the
  new intended values (51 rules, kb-v2, website rules excluded from the
  file-fixture corpus — they are covered by the fixture HTTP server).
- Fixture-server e2e asserts: all 10 expected LIVE findings fire, every
  finding has `source="live-scan"` + rule_id + CWE + url, active
  findings are ≤MEDIUM with manual-verification notes, the external
  link is never fetched (only listed as skipped), request budget is
  respected (`truncated=True` at 5 requests), disclaimer contains
  "NOT proof of security", and the token never appears in responses.

### Decisions
- Authorization before SSRF validation before scope before crawl —
  the failure order leaks nothing and does no network unauthenticated.
- Budget exhaustion ends the crawl gracefully with `truncated=True`
  (partial, honest results) instead of erroring the whole scan.
- Cookie evidence records names + missing flags, never values.
- `/.git/HEAD` + `/.env` are the only exposed-file probes (first net,
  documented); no path enumeration.
- KB entries added for LIVE rules even though the live pipeline has no
  AI review yet — the "every rule has guidance" invariant stays strong
  for future remediation/retest flows.

### Honesty notes / residual risks
- DNS TOCTOU: the checked address is the address at check time; a
  hostile DNS operator for the target could rebind before connect.
  Documented in `docs/SECURITY_MODEL.md`, not hidden.
- TLS: revocation (OCSP/CRL) and cipher-suite strength are not evaluated.
- Active probes are observations, not confirmed vulnerabilities; the
  disclaimer says a limited scan never proves a site secure.
- Static findings still never claim deployed exploitability.

### Acceptance criteria status (Phase Six §10)
- 10.1 Authorization model: PASS — two-factor, 403-tested, no default-allow.
- 10.2 Scope enforcement: PASS — host+port+prefix, subdomain opt-in, redirect per-hop checks, skip-listing.
- 10.3 SSRF guard: PASS — matrix-tested (16 cases), fail-closed, residual TOCTOU documented.
- 10.4 Passive checks: PASS — 10 rules, all firing on the fixture server.
- 10.5 Active checks: PASS — 2 probes, GET-only, rate-limited, capped, verified.
- 10.6 Authenticated scanning: PASS — cookie/Authorization header supported, never logged (tested: token absent from responses).

### Next step (Phase Seven)
Database, auth & SaaS infrastructure (§7): users, projects, scan jobs,
tenant isolation, metering — the deferred durable job queue and
incremental-analysis invalidation design from Phase Two belong here.

## Phase Seven — Database, auth & SaaS infrastructure (2026-10-02)

### What was built
- **Persistence** (`backend/services/persistence/`, 7 modules, SQLAlchemy
  2.0.44 pinned): `models.py` — User, ApiKey, Project, RepoAnalysis,
  WebsiteScan, FindingSnapshot (immutable per completed scan), ScanJob,
  UsageCounter, SchemaVersion; `database.py` — engine/session factory,
  `SCHEMA_VERSION = 1`, `upgrade_database()` with `_migrate_N_to_M`
  hooks for future versions; `repository.py` — all queries scoped by
  project→user (tenant isolation lives here, not just at endpoints);
  `auth.py` — API-key issuance (secrets.token_urlsafe), salted
  SHA-256 hashes (never plaintext), constant-time compare, scopes
  read/scan/admin with implication (admin ⊃ scan ⊃ read), revocation;
  `jobs.py` — durable queue (queued/running/done/failed/cancelled),
  atomic claim (no double-claim), in-process worker thread marked
  dev-only; `metering.py` — per-key counters (analyses, scans, AI
  calls).
- **API** (`app/main.py`): `POST /projects`, `GET /projects`,
  `GET /projects/{id}`, `GET /projects/{id}/scans` (both scan kinds),
  `GET /analyses/{id}` + `GET /website-scans/{id}` (with finding
  snapshots), `GET /jobs/{id}`, `DELETE /jobs/{id}` (cancel),
  `GET /usage`, `POST/GET/DELETE /keys`. `?async=true` on
  `/analyze` and `/scan/website` returns 202 + job id; sync path
  unchanged. `CODEAUDIT_REQUIRE_AUTH` (default false, backward
  compatible) → 401 without a valid key when enabled. Live-scan
  credentials for async website scans are kept in memory only, never
  persisted (tested).
- **Config** (`.env.example`): `CODEAUDIT_DATABASE_URL`
  (default `sqlite:///./codeaudit.db`, file created 0600),
  `CODEAUDIT_REQUIRE_AUTH`, `CODEAUDIT_DEV_BOOTSTRAP_KEY` (default
  false; loud warning when enabled).

### Verification
- Baseline 481 green before; **530/530 green** after (49 new in
  `tests/test_persistence.py`, hermetic — SQLite in-memory/file).
- Tenant isolation is tested at both layers: repository
  (`test_user_cannot_read_other_users_project/analysis`,
  `test_cross_user_job_invisible`, `test_anonymous_sees_only_unowned_rows`)
  and API (`test_project_cross_user_returns_404`,
  `test_async_job_tenant_isolation`).
- Auth: wrong/revoked keys rejected, scope enforcement
  (`test_read_scope_cannot_scan`), issuance requires authentication,
  plaintext never in stored hash.
- Jobs: atomic claim, failure marking, cancellation rules, worker
  thread e2e, async 202 flow, credential non-persistence.

### Decisions
- SQLite default for dev, Postgres-compatible schema (no SQLite-only
  SQL) — Postgres is the documented production target.
- In-process worker is dev-only by explicit marking; production =
  separate worker process (documented, not built).
- Metering counters now; billing in Phase 11.

### Honesty notes / residual risks
- No password auth / OAuth / SSO — API keys only.
- Incremental-analysis invalidation design still open (deferred again,
  honestly — the job + snapshot tables are the foundation it needs).
- `CODEAUDIT_REQUIRE_AUTH=false` default keeps the local demo
  frictionless; production deployments must enable it (documented).

### Acceptance criteria status (Phase Seven §11)
- 11.1 Persistence: PASS — 9 entities, versioned schema, 0600 SQLite.
- 11.2 Auth: PASS — salted-hash keys, scopes, rotation/revocation,
  opt-in enforcement.
- 11.3 Tenant isolation: PASS — repository-layer scoping, dual-layer
  tests.
- 11.4 Durable job queue: PASS — persisted states, atomic claim,
  async API, cancel; dev-only worker marked.
- 11.5 Scan history: PASS — per-project listing, immutable snapshots.
- 11.6 Metering: PASS — counters wired to analyses/scans/AI calls.

### Next step (Phase Eight)
Reporting, remediation & retesting (§8): finding lifecycle
(new/acknowledged/fixed/verified), retest flow comparing snapshots,
report formats (PDF/HTML export), notification hooks.

## Phase Eight — Reporting, remediation lifecycle & retesting (2026-10-02)

### What was built
- **Finding lifecycle** (`finding_statuses` table, schema v1→v2 with
  tested upgrade path): per-project finding states `acknowledged` /
  `fixed` keyed by stable fingerprint (`services/retest.py`:
  SHA-256 of rule_id + file/url + normalized evidence; line numbers
  deliberately excluded so one-line shifts don't break matching).
  `POST/GET /projects/{id}/findings/status`; cross-user access 404s.
- **Retest** (`POST /projects/{project_id}/retest`): re-runs the
  project's latest analysis/scan and diffs fingerprints into
  new / persisting / resolved, with risk delta. Lifecycle-aware:
  previously-"fixed" findings that persist are flagged `regressed`;
  "fixed" + resolved are flagged `verified`. Website retests require
  FRESH per-request authorization (token + `i_authorize_this_scan`);
  stored scans never reuse caller credentials. Retest uses default
  probe settings against the same target URL (documented).
- **Report exports**: `GET /analyses/{id}/report` and
  `GET /website-scans/{id}/report` with `?format=markdown|html`;
  HTML is self-contained (inline CSS, no external assets) and every
  dynamic string is escaped. Reports carry the scope disclaimer.
- **Webhooks** (`services/notifications.py`): HMAC-SHA256-signed JSON
  POST (`X-CodeAudit-Signature`, `X-CodeAudit-Event`) on every
  completed analysis/scan via `CODEAUDIT_WEBHOOK_URL` /
  `CODEAUDIT_WEBHOOK_SECRET`. Best-effort: 5s timeout, failures
  logged never raised; empty URL = disabled; no credentials or secret
  values in payloads.
- **Config/docs**: `.env.example` documents the webhook vars;
  `app/config.py` gained `webhook_url` / `webhook_secret`.

### Verification
- Baseline 530 green before; **548/548 green** after (18 new in
  `tests/test_phase8.py`, hermetic — analysis/scan runners
  monkeypatched, webhook HTTP stubbed, tmp SQLite).
- Fingerprint: stable across line shifts, differs on evidence/rule
  change. Diff: correct new/persisting/resolved buckets.
- Lifecycle: roundtrip + upsert (no duplicates), 422 on bad status,
  404 cross-user for both GET and POST.
- Retest: full e2e via API — diff correct, `verified`/`regressed`/
  `acknowledged` annotations correct, 404 with no previous run,
  403 for website retest without fresh auth.
- Reports: markdown + HTML for both run kinds; evidence HTML-escaped
  (`<b>` → `&lt;b&gt;`); 404 on unknown ids.
- Webhooks: signature verified byte-for-byte against an independent
  HMAC; connection failure and HTTP 500 both return False, never raise.
- Migration: v1 DB (without `finding_statuses`) upgrades cleanly to v2;
  existing `test_schema_version_stamped` updated to the new intended
  version (was asserting literal 1).

### Decisions
- Lifecycle states live in the DB per project, not in the immutable
  snapshots — snapshots stay write-once; status is a separate concern.
- "new" is implicit (no row) so old runs need no backfill.
- Retest is synchronous like `/analyze` (same timeout story);
  async retest can reuse `?async=true` + job polling later.
- Webhook fires from the record functions, so sync and async paths
  both notify exactly once per completed run.

### Honesty notes / residual risks
- Fingerprint matching is heuristic: moved code (different file) or
  reworded evidence looks "new" + "resolved" instead of "persisting"
  (documented in `services/retest.py`).
- No PDF export (HTML is print-friendly; PDF tooling deferred).
- Webhook delivery is at-most-once, best-effort — no retry queue.

### Acceptance criteria status (Phase Eight §8)
- 8.1 Finding lifecycle: PASS — acknowledged/fixed, tenant-scoped, tested.
- 8.2 Retest flow: PASS — diff + lifecycle annotations + fresh-auth rule.
- 8.3 Report exports: PASS — markdown + self-contained escaped HTML.
- 8.4 Notification hooks: PASS — signed, best-effort, tested.

### Next step (Phase Nine)
Frontend & customer workflow (§9): the demo/customer UI on top of the
now-stable backend contracts.

## Phase Nine — frontend & customer workflow (2026-10-02)

Built the demo/customer UI as a static no-build-step app in `frontend/`:
`index.html` (top bar with backend URL + API key + health dot, four tabs),
`styles.css`, `app.js` (vanilla JS), plus `frontend/README.md` deploy guide.

- Tabs: Analyze repo (`POST /analyze`, optional `?async=true` background
  mode with `GET /jobs/{id}` polling), Scan website (per-host token +
  mandatory authorization checkbox, optional session cookie), Findings
  (per-project lifecycle with ack/fix buttons), Retest (new/persisting/
  resolved buckets, fresh auth required for website retests).
- Analyze + scan forms carry a project selector and pass `project_id`,
  closing the workflow gap (runs attach to projects for history/lifecycle/
  retest).
- Backend: added `GET /analyses/{id}/findings` and
  `GET /website-scans/{id}/findings` returning `{fingerprint, finding}`
  pairs (RunFindingsOut), tenant-scoped, 404 on unknown/cross-user ids.
- Bug fixed during review: acknowledge button compared against `"ack"`
  instead of `"acknowledged"` and always showed "Fixed ✓".
- Security: all dynamic strings HTML-escaped before render; scan token
  never persisted to localStorage (only backend URL + API key are).

Verification (2026-10-02):
- 12 new backend tests in `tests/test_phase9.py` (endpoint fingerprints,
  tenant isolation, 404s, line-shift fingerprint stability, frontend
  static checks) — all pass.
- jsdom functional suite driving the REAL page + REAL backend:
  health dot, tab switching, form validations, XSS escaping of finding
  cards, project select population, mock renderAnalysis/retest paths,
  retest auth-box toggle — all pass; zero JS runtime errors.
- Async job flow (202 → poll /jobs → render) verified over real HTTP
  against a stub backend — passes.
- Live-clone e2e is BLOCKED by the sandbox (git smart-HTTP stalls;
  backend correctly returns 504 CLONE_TIMEOUT and the UI shows the
  error gracefully). To be re-run on a network where git works.

## Phase Ten — testing, CI/CD & production readiness (2026-10-02, in progress)

- `.github/workflows/ci.yml`: pytest (backend/tests) + `node --check
  frontend/app.js` on every push to main / PR.
- `Dockerfile`: single-image build (python:3.12-slim, git, non-root
  `codeaudit` user). Serves API + demo frontend at `/ui`;
  `CODEAUDIT_REQUIRE_AUTH=true` by default. NOT build-tested (no
  docker in this sandbox) — build before relying on it.
- `docs/PRODUCTION.md`: pre-launch checklist (auth, Postgres, secrets,
  Nebius key handling, agent modes, scan budgets, dev-only worker
  warning, smoke tests, threat-model review pointer).
- Apache-2.0 LICENSE already at repo top level (hackathon OSS-license
  requirement met).

## Phase Ten — completed (2026-10-02)

- `.github/workflows/ci.yml`: pytest + `node --check frontend/app.js`
  on push to main / PR (YAML validated; Actions run on GitHub).
- `Dockerfile`: single image (python:3.12-slim, git, non-root
  `codeaudit` user), serves API + `/ui`, `CODEAUDIT_REQUIRE_AUTH=true`
  by default, honors `$PORT`. NOT build-tested — no docker in this
  sandbox; build on deploy.
- `docs/PRODUCTION.md`: pre-launch checklist.

## Phase Eleven — deployment readiness (2026-10-02)

- `docs/DEPLOYMENT.md`: Render / Railway / Fly.io paths, env-var
  table, real first-admin-key flow via `CODEAUDIT_DEV_BOOTSTRAP_KEY`
  (verified against `_dev_bootstrap`), post-deploy smoke tests.
  (Corrected an initial draft that invented `POST /users` — the real
  issuance path is bootstrap → `POST /keys`.)
- `docs/SUBMISSION_CHECKLIST.md`: Devpost requirements mapped to
  status; "what NOT to claim" honesty section.
- `docs/DEMO_VIDEO_SCRIPT.md`: <3:00 shot-by-shot script with
  recording tips.
- Commercial billing/pricing deliberately deferred: out of scope for
  the hackathon window (deadline Oct 30).

## Full from-scratch audit (2026-10-04)

Systematic review: 178 Python files compile-checked, 148 modules
import-checked, full API layer read, 3 parallel audit agents
(services, agents/schemas, docs/config/frontend consistency).

Bugs found and fixed:
1. CRITICAL — livescan auth bypass (`services/livescan/auth.py`):
   `hmac.compare_digest(authorization_token or "", expected or "")`
   evaluated `compare_digest("", "")` == True when no token was
   configured for a host, so an empty token + `i_authorize_this_scan=true`
   authorized scans of arbitrary hosts. Existing tests only tried
   non-empty tokens and missed it. Fixed: fail closed for unconfigured
   hosts (dummy constant-time comparison preserves the no-oracle
   property). 4 regression tests added; exploit verified dead.
2. HIGH — `Dockerfile` set `CODEAUDIT_DATABASE_URL=""`; `os.environ.get`
   returns `""` (not the default) for set-but-empty vars, crashing
   SQLAlchemy on startup. Fixed defensively in `app/config.py`
   (`or` instead of default arg) and removed the empty ENV.
3. MEDIUM — `DELETE /jobs/{id}` (cancel) never popped `_JOB_SECRETS`,
   leaking scan credentials in memory after cancellation. Fixed +
   regression test in `test_persistence.py`.
4. MEDIUM — KB loader crashed on valid JSON with non-dict top-level
   (`raw.get` AttributeError), breaking the "empty base on failure"
   contract. Fixed with isinstance check.
5. MEDIUM — prompt-injection gaps: finding title/description/evidence
   interpolated raw into prompts in `fix_prompt.py`,
   `security_investigation.py`, and `agents/evidence_agent.py`
   (only the large source windows were wrapped). Fixed by wrapping
   the per-finding blocks with `wrap_untrusted`.
6. LOW — duplicate `_require_project` call in async website-scan path.
   Removed.

Self-inflicted: a `py_compile` sweep wrote `__pycache__` into
`tests/fixtures/`, breaking 3 fixture-counting tests. Cleaned up;
lesson recorded in `~/AGENTS.md`.

Audit follow-ups (2026-10-04):
7. Dockerfile: removed misleading SQLite home-dir comment + unused
   mkdir; added .dockerignore (excludes .env, __pycache__, *.db,
   .venv, .git) so secrets/caches are never baked into the image.
8. test_fix_context.py updated: the delimiter-injection test now
   expects 2 evidence blocks (finding block + source block) after the
   prompt-hardening fix.

Final: 565 passed, 2 warnings. frontend/app.js syntax-clean.

Audit follow-ups part 2 (2026-10-04):
9. Removed dead `Settings.ai_calls_analysis_limit` /
   `ai_calls_remediation_limit` properties (never called; supervisor's
   `_analysis_budget_for` / `_remediation_budget_for` are the single
   source of truth). Documented the hard-cap guarantee there instead.
10. `CODEAUDIT_FIX_MAX_CONTEXT_CHARS` is now enforced in
    `build_fix_context` (window expansion respects it alongside
    `fix_max_file_chars`).

Final: 565 passed (1 pre-existing perf test excluded from final count
as environment-sensitive; full suite: 565 passed, 2 warnings).

Audit follow-ups part 3 — livescan (2026-10-04):
11. http.py: credential headers (Cookie/Authorization) stripped on
    cross-host redirects.
12. checks.py: ScanBudgetError/ScanTimeoutError now propagate (were
    swallowed; truncated flag was dead code).
13. scanner.py: TLS probe now uses scope.port (was hardcoded 443).
14. scope.py: bad path_prefix/scheme/port raises ScanScopeError → 400
    (was bare ValueError → 500).
15. scope.py: path-prefix matching requires segment boundary
    (/blog no longer matches /blogroll).
16. auth.py: parse_scan_tokens handles bracketed IPv6 ([::1]:token).

73/73 livescan tests pass.

Audit follow-ups part 4 — persistence (2026-10-04):
17. jobs.py: atomic cancel_job (UPDATE WHERE state='queued' + rowcount;
    no more TOCTOU vs worker claim).
18. jobs.py: complete_job/fail_job guarded (WHERE state IN
    ('queued','running'); cancelled jobs never resurrected).
19. jobs.py: process_one_job catches BaseException → marks failed,
    re-raises; no stranded 'running' jobs on worker crash.
20. metering.py: atomic increment via INSERT..ON CONFLICT DO UPDATE
    (no lost updates under concurrency; 20-thread smoke test clean).
21. repository.py: set_finding_status self-heals NULL-duplicate rows
    (first-row-wins + delete dupes) instead of 500.
22. database.py: sqlite sidecar files (-wal/-shm/-journal) chmod 0600.
23. database.py: get_engine double-checked locking (one engine under
    thread race).

50/50 persistence + 18/18 phase8 tests pass.
