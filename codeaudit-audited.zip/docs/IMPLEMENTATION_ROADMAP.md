# CodeAudit Agent — Implementation Roadmap

All 11 phases from the master engineering prompt, with status and dependencies.
Updated as phases complete. Evidence for each claim lives in
`docs/IMPLEMENTATION_LOG.md` and `docs/ENGINEERING_AUDIT.md`.

| # | Phase | Status | Depends on | Notes |
|---|---|---|---|---|
| 0 | Repository discovery & engineering audit | **Complete** 2026-10-02 | — | `docs/ENGINEERING_AUDIT.md`; 303/303 baseline; benchmark script added |
| 1 | Harden the existing backend | **Complete** 2026-10-02 | Phase 0 | Correlation IDs, URL length bounds, analysis wall-clock budget (504), lazy walk; 321/321 green |
| 2 | Performance & scalability | **Complete** 2026-10-02 | Phase 1 | Double parse + specialist re-parses + per-file Parser eliminated (332/332 green); job queue & incremental caching deferred to Phase 7; `docs/PERFORMANCE.md` |
| 3 | Trustworthy detection engine | **Complete** 2026-10-02 | Phase 2 (parse reuse) | Rule registry + CWE (19 rules); 5 source-to-sink pairs; 51-fixture precision/recall corpus (18/19 rules at P=R=1.0); AI disagreement can no longer downgrade deterministic findings; 355/355 green |
| 4 | Dependency, secret & config scanning | **Complete** 2026-10-02 | Phase 2 (registry pattern) | supplychain/ package: 7 manifest formats, advisory DB (current/stale/unavailable), 6 secret detectors (redacted, AI-excluded), Dockerfile/GHA/compose checks, SBOM on result; 386/386 green |
| 5 | RAG + bounded multi-agent reasoning | **Complete** 2026-10-02 | Phase 3 (finding model) | 45-entry curated KB (all 39 rules covered), tag-first TF-IDF retrieval (knowledge-only, bounded, no AI calls), sensitive findings get nothing, step budgets with trip logging, knowledge_used provenance on findings/proposals/results, report attribution; 412/412 green |
| 6 | Live website security testing | **Complete** 2026-10-02 | Phase 2 (jobs), auth model | livescan/ package: two-factor target authorization (403-tested, no default-allow) + resolve-then-check SSRF guard (16-case matrix) + scope enforcement (host+port+prefix, per-hop redirect checks) + GET-only rate-limited active probes (capped MEDIUM, manual-verification notes); 10 passive + 2 active rules (LIVE-001…021); `POST /scan/website`; docs/SECURITY_MODEL.md; 481/481 green |
| 7 | Database, auth & SaaS infra | **Complete** 2026-10-02 | Phase 2 (job design) | persistence/ (SQLAlchemy 2.0.44): users, API keys (salted hashes, read/scan/admin scopes), projects, scan jobs (durable queue, atomic claim, async 202 API, cancel), scan history + immutable finding snapshots, metering counters; tenant isolation at repository layer (dual-layer tests); versioned schema (SCHEMA_VERSION=1, upgrade_database); SQLite dev default (0600), Postgres production target; 530/530 green |
| 8 | Reporting, remediation & retesting | **Complete** 2026-10-02 | Phase 3, 7 | Finding lifecycle (acknowledged/fixed per fingerprint, schema v2); retest with new/persisting/resolved diff + verified/regressed annotations (website retest needs fresh auth); markdown + self-contained HTML report exports; HMAC-signed best-effort webhooks; 548/548 green |
| 9 | Frontend & customer workflow | Done (2026-10-02) | Phase 7, 8 | Verified via jsdom + stub-backend suites; live-clone e2e blocked by sandbox network (re-run where git works) |
| 10 | Testing, CI/CD & production readiness | Pending | Ongoing | Start CI early (Phase 1/2); full gates before launch |
| 11 | Deployment & commercial readiness | Pending | Phase 7, 10 | Threat model + independent review before public launch |

## Ordering constraints (do not violate)

- Do not add languages (Phase 3/4 work) before fixing double parsing (Phase 2): every new
  analyzer would inherit the 2× parse cost.
- Do not build live scanning (Phase 6) before the target authorization model exists.
- Do not expose multi-user access before tenant isolation (Phase 7).
- Do not claim benchmark numbers without the corpus + methodology from Phase 3.
- RAG (Phase 5) retrieves knowledge only; detectors and validators remain the source of truth.
