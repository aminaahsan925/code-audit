# CodeAudit Agent — Performance

Methodology, measured numbers, bottlenecks found, and what was fixed.
Numbers are observations on the stated host, not performance claims.

## Methodology

- Tool: `backend/scripts/benchmark.py` — drives the orchestrator's tool-style
  stages directly (no API, no network, no AI: `StubAIProvider` / free mode).
  Hermetic and repeatable.
- Runs: 3 per fixture; reported as min/mean/max milliseconds. Test
  assertions in `backend/tests/test_performance.py` use min-of-5 with wide
  margins so CI doesn't flake.
- Host: linux, Python 3.12.3 (venv at `~/workspace/codeaudit-agent/.venv`).
- Corpora: fixed analysis fixtures (`tests/fixtures/*`) plus a scaling
  probe over this backend's own source tree (`backend/`, ~106 files).

## Measured: pipeline stages, 106-file self tree (post-Phase-Two)

| stage          | min     | mean    | max     |
|----------------|---------|---------|---------|
| scan           | 81.84   | 84.18   | 86.26   |
| parse          | 232.87  | 299.17  | 354.29  |
| analyze (tree reuse) | 654.21 | 671.51 | 685.19 |
| analyze_legacy (re-parse path) | 890.05 | 919.05 | 965.67 |
| validate       | 1.79    | 1.95    | 2.08    |
| risk           | 0.16    | 0.16    | 0.17    |
| full (supervisor, free mode) | 1303.75 | 1375.93 | 1447.07 |

Parse-reuse speedup on the analyze stage: **0.73×** (mean), i.e. ~27%
faster than the legacy re-parse path, with identical findings
(asserted by the benchmark itself and by `test_performance.py`).

Fixture-scale numbers (1 file each) are in the benchmark output; all
fixtures complete end-to-end in under 6ms.

## Measured: analyze-stage component breakdown (102 deep files)

| component | ms |
|---|---|
| raw parsing only (`ast.parse` / tree-sitter `parse`) | 132 |
| symbol extraction (full tree walk per file) | 140 |
| detectors on reused trees | 691 |

## Bottlenecks found and fixed (Phase Two)

1. **Double parsing — fixed.** `orchestrator.parse()` parsed every file, then
   `analyze_static()` parsed every file again. `LanguageAnalyzer` now exposes
   `analyze_parsed(relative_path, content, parsed)`, and the orchestrator
   threads `ParsedSource` trees (retained `ast.Module` / tree-sitter `Tree`)
   from parse into analysis. Proven by `test_no_reparse_when_sources_shared`:
   the analyze stage performs **zero** parser calls when sources are shared.
   The legacy `analyze_file` path (parse-inside) is kept for standalone/test
   use and produces identical findings (equivalence asserted on every
   fixture file).
2. **Specialist agents re-parsed — fixed.** `PerformanceAgent.detect()` and
   `QualityAgent.detect()` each ran `ast.parse` per Python file (parses #3
   and #4). They now consume the supervisor-shared `parse_trees` when
   available, with a per-file-parse fallback. Findings identical either way
   (tested).
3. **tree-sitter Parser per file — fixed.** A fresh `Parser` was constructed
   per file per analyze call. Parsers are now cached per thread per language
   (`threading.local`; a `Parser` must not parse concurrently on two
   threads). Grammar loading was already cached.

## Correction to the Phase Zero audit (§6)

The audit framed the re-parse as the dominant cost ("analyze ~3× parse
largely because it re-parses"). Profiling shows the re-parse was ~17% of
the analyze stage. The dominant cost is the **detectors themselves**
(~691ms / ~75%): each of the 19 detectors walks the entire syntax tree
independently (10 `ast.walk` passes per Python file, 9 `_walk` passes per
JS/TS file). This is the next structural bottleneck: a single-pass walk
dispatching to all detectors would remove ~18 redundant tree walks per
file. Documented here as future work — not fixed in this phase, because it
touches every detector's traversal and deserves its own phase with its own
equivalence tests.

Symbol extraction (~140ms, a full tree walk per file) is the second
contributor; it could share the detector walk as well.

## Verified, not changed (Phase Two scope items 4–5)

- **Bounded parallelism:** specialists run in a single
  `ThreadPoolExecutor(max_workers=3)` (`agents/supervisor_agent.py`).
  No other executors exist; no unbounded `asyncio` fan-out. Sane as-is.
- **AI cost/latency controls:** `AIBudgetManager` is thread-safe
  (`threading.Lock` on all mutations) with hard per-run caps by agent mode
  (free 0 / economy 1+1 / full 4+2 analysis+remediation calls); the
  supervisor is the sole enforcer (`budget.allow_call` gates every review);
  `NemotronService` enforces `CODEAUDIT_AI_TIMEOUT_SECONDS` (default 60s)
  and `CODEAUDIT_AI_MAX_RETRIES` (default 2); exhaustion surfaces the
  controlled `AI_BUDGET_EXHAUSTED` status, never a silent partial result.
  Covered by existing AI/budget tests (45 passing). No live-AI timings
  measured: no API key exists in this environment.

## Explicitly deferred (with where they belong)

- **Durable background-job queue / DB persistence:** needs Phase 7
  decisions first; no half-queue built (roadmap ordering constraint).
- **Incremental / cached analysis across commits:** needs a
  cache-invalidation design (keys: commit SHA + analyzer version + rule
  version; per-tenant isolation). Design sketched, not implemented.
- **Single-pass detector walk:** the measured next bottleneck (above).
- **AI-stage latency/cost measurement:** requires an API key; belongs to
  Phase Two §6.6 follow-up once a key exists.
- **Clone disk-usage guard:** still no portable approach (carried over from
  Phase One limitations).
