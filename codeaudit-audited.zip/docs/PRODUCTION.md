# Production readiness checklist

Ship this list before pointing real users at a deployment. The local
defaults are deliberately unsafe-for-production (keyless demo mode);
every item below flips one of them.

## 1. Authentication & secrets

- [ ] `CODEAUDIT_REQUIRE_AUTH=true` — every endpoint except `/health`
      requires `X-API-Key`. The default `false` is dev/demo only.
- [ ] `CODEAUDIT_DEV_BOOTSTRAP_KEY=false` (default). Never enable in
      production — it prints an admin key to stdout.
- [ ] API keys are issued via `POST /users` + key creation and stored
      only as salted hashes. Hand the plaintext to the owner once.
- [ ] `CODEAUDIT_SCAN_TOKENS` set to `host:long-random-token` pairs for
      every host you intend to scan. Empty = all website scans 403.
- [ ] `CODEAUDIT_WEBHOOK_SECRET` set if webhooks are configured.
- [ ] No secret is ever baked into the image, committed to git, or
      printed in logs. Scan tokens are compared with
      `hmac.compare_digest` and never logged.

## 2. Database

- [ ] `CODEAUDIT_DATABASE_URL` points at Postgres
      (`postgresql+psycopg2://…`). SQLite is the dev default; the file
      gets 0600 permissions but it does not survive multi-instance
      deploys.
- [ ] Run migrations on deploy (schema versions are tracked in the
      `schema_versions` table; v1 → v2 adds `finding_statuses`).

## 3. AI provider (Nebius / Nemotron)

- [ ] `NEBIUS_API_KEY` injected at runtime (secret manager / env),
      never stored in the repo or the image.
- [ ] `CODEAUDIT_AGENT_MODE` chosen deliberately: `free` (no AI calls),
      `economy` (1+1 budgeted calls), `full` (4+2). Free mode forces the
      stub provider — zero external calls by construction.
- [ ] `CODEAUDIT_AI_TIMEOUT_SECONDS` / retries reviewed for your
      latency budget.

## 4. Resource limits & scanning safety

- [ ] `CODEAUDIT_MAX_ANALYSIS_SECONDS` (default 600) and
      `CODEAUDIT_CLONE_TIMEOUT` fit your instance size; analyses return
      HTTP 504 past the budget instead of hanging workers.
- [ ] `CODEAUDIT_SCAN_ALLOW_LOCALHOST=false` in production (default).
- [ ] Scan budgets (`CODEAUDIT_SCAN_MAX_PAGES/REQUESTS/SECONDS`, …)
      reviewed against abuse potential — a scan is outbound traffic
      billed to you.
- [ ] Only scan systems you own or have written permission to test.

## 5. Runtime

- [ ] The in-process job worker is **dev-only**. `?async=true` jobs on a
      production deploy need a durable worker story (persistence layer
      records job state; wire your own runner/queue).
- [ ] Liveness probe: `GET /health` → `{"status":"ok"}`.
- [ ] `CODEAUDIT_LOG_LEVEL` set (INFO default); logs contain request
      IDs (`X-Request-ID` echoed) and never credentials.
- [ ] The Docker image runs as non-root (`codeaudit`); `/ui` serves the
      demo frontend same-origin so no CORS configuration is needed.
      If you host the frontend on a separate origin instead, configure
      CORS explicitly on the API deployment.

## 6. Pre-launch verification

- [ ] `pytest tests/ -q` green on the exact image/commit being
      deployed (CI runs it on every push to `main`).
- [ ] `node --check frontend/app.js` (also in CI).
- [ ] Smoke test against the deployed URL: `/health`, one
      `/analyze` on a small repo, one authorized `/scan/website`.
- [ ] Threat-model review of anything you changed since the last
      review — especially auth, SSRF guard, and token handling
      (see `docs/SECURITY_MODEL.md`).
