# Demo video script — under 3 minutes

Target: < 3:00. Record at 1080p, narrate plainly, no hype words you
can't defend. Suggested timing below; rehearse once with a timer.

## 0:00–0:15 — Hook
Show the deployed `/ui/` page. Say:
> "Every repo ships vulnerabilities. CodeAudit Agent finds them with
> evidence — file, line, and the exact code — then helps you fix and
> verify. Let me show you."

## 0:15–1:00 — Analyze a repo
- Paste a GitHub URL (pick a small repo with known findings; rehearse
  which one), click **Analyze**.
- While it runs: "Deterministic detectors scan Python and JS/TS —
  no regexes, real parsing. Optional Nemotron review on Nebius enriches
  the evidence, inside a hard AI-call budget."
- Results land: point at the risk score, expand one finding — show the
  evidence block, rule ID, and CWE. "Every finding carries its proof."

## 1:00–1:30 — Finding lifecycle
- Switch to **Findings**, pick the project, click **Acknowledge** on one
  finding. "Triage state is tracked per project."
- (If you have a fix ready) "Mark fixed after remediation."

## 1:30–1:50 — Retest
- **Retest** tab → Retest. "It re-runs the analysis and diffs: new,
  persisting, resolved." Point at a `verified` or `regressed` badge.

## 1:50–2:20 — Authorized website scan
- **Scan website** tab: enter a URL you own, paste the per-host token,
  check **"I authorize this scan"**. Run.
- "Scans only run with a server-side token plus explicit authorization —
  you can't point this at someone else's site."
- Show findings: missing security headers, cookie flags. "Passive checks
  plus bounded GET-only probes; findings are capped and marked for
  manual verification."

## 2:20–2:45 — How it's built (honesty round)
- "Deterministic first: 19 code rules, supply-chain and secret scanning,
  all evidence-gated — a finding without verifiable evidence doesn't
  ship. Nemotron on Nebius reviews evidence inside a budget; it can
  enrich findings but never invent or suppress them."
- Flash the architecture: supervisor + specialist agents, tenant
  isolation, immutable finding snapshots.

## 2:45–3:00 — Close
- "Open source, Apache 2.0. Try the demo at <URL>, repo at
  github.com/aminaahsan925/codeAudit-agent."
- End card with both links.

## Recording tips
- Use a fresh project so the lifecycle/retest story is clean.
- Pre-run the analysis once so you know the findings you'll narrate.
- Keep the API key out of frame (paste as password field, or blur).
- If anything fails live: keep the take — cut in post, don't re-record
  the whole thing.
