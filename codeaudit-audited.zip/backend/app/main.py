"""CodeAudit Agent backend — FastAPI application entry point.

Small by design: route registration and error mapping only. All analysis
logic lives in the service layer (see services/orchestrator.py).
"""

from __future__ import annotations

import json
import logging
import threading
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel

from app.config import settings
from models.schemas import (
    AnalysisDetailOut,
    AnalysisRequest,
    AnalysisResult,
    ApiKeyCreate,
    ApiKeyCreatedOut,
    ApiKeyOut,
    BatchRemediationRequest,
    ErrorResponse,
    FindingStatusIn,
    FindingStatusOut,
    JobAcceptedOut,
    JobOut,
    ProjectCreate,
    ProjectHistoryOut,
    ProjectOut,
    RemediationRequest,
    RemediationResult,
    RepoAnalysisHistoryOut,
    RetestFindingOut,
    RetestRequest,
    RetestResultOut,
    UsageOut,
    WebsiteScanDetailOut,
    WebsiteScanHistoryOut,
    WebsiteScanRequest,
    WebsiteScanResult,
)
from services import github_service, repository_scanner
from services.livescan import errors as livescan_errors
from services.livescan.scanner import WebsiteScanner, scan_config_from_settings
from services import notifications
from services import retest as retest_lib
from agents.supervisor_agent import SupervisorAgent
from services.orchestrator import AnalysisOrchestrator
from services.remediation_engine import RemediationEngine
from services.remediation_errors import (
    RemediationError,
    RemediationFindingNotFound,
    SAFE_MESSAGES as REMEDIATION_SAFE_MESSAGES,
)
# Phase 7: persistence, auth, durable jobs, metering.
from services.persistence import auth as persistence_auth
from services.persistence import database as persistence_db
from services.persistence import jobs as job_queue
from services.persistence import metering
from services.persistence import repository as persistence_repo

import re
import uuid

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# Client-supplied request IDs are echoed only when they look safe; anything
# else (missing, too long, odd characters) gets a generated one. This keeps
# the header usable for tracing without letting a client inject log content.
_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

# ---------------------------------------------------------------------------
# Phase 7 — authentication, persistence, jobs, metering
# ---------------------------------------------------------------------------


@dataclass
class AuthContext:
    """Who is calling. ``anonymous`` is only possible when
    CODEAUDIT_REQUIRE_AUTH=false (single-user dev default)."""

    user_id: str | None
    api_key_id: str | None
    key_prefix: str | None
    scopes: frozenset
    anonymous: bool


def _api_error(status_code: int, code: str, message: str) -> HTTPException:
    # Raised (not returned) so the pass-through handler emits
    # {"detail": {"error": {"code": ..., "message": ...}}}.
    return HTTPException(
        status_code=status_code,
        detail={"error": {"code": code, "message": message}},
    )


def get_auth_context(request: Request) -> AuthContext:
    """Resolve the caller from the ``X-API-Key`` header.

    No header + CODEAUDIT_REQUIRE_AUTH=false → anonymous dev context.
    No header + required → 401. Bad/revoked key → 401 (never reveals
    whether a key prefix exists).
    """
    raw = request.headers.get("X-API-Key", "").strip()
    if not raw:
        if settings.require_auth:
            raise _api_error(
                status.HTTP_401_UNAUTHORIZED,
                "AUTH_REQUIRED",
                "This deployment requires an API key (X-API-Key header).",
            )
        return AuthContext(
            user_id=None, api_key_id=None, key_prefix=None,
            scopes=frozenset(), anonymous=True,
        )
    session_factory = persistence_db.get_session_factory(settings.database_url)
    with session_factory() as session:
        record = persistence_repo.authenticate_api_key(session, raw)
        if record is None:
            session.rollback()
            raise _api_error(
                status.HTTP_401_UNAUTHORIZED,
                "INVALID_API_KEY",
                "The API key is invalid or revoked.",
            )
        session.commit()
        return AuthContext(
            user_id=record.user_id,
            api_key_id=record.id,
            key_prefix=record.key_prefix,
            scopes=frozenset(persistence_auth.decode_scopes(record.scopes)),
            anonymous=False,
        )


def require_scope(*needed: str):
    """Endpoint dependency: caller must hold every listed scope.

    Anonymous callers pass only when auth is not required (dev default);
    with CODEAUDIT_REQUIRE_AUTH=true they never get here.
    """

    def _dep(ctx: AuthContext = Depends(get_auth_context)) -> AuthContext:
        if ctx.anonymous:
            return ctx
        granted = list(ctx.scopes)
        for scope in needed:
            if not persistence_auth.scopes_grant(granted, scope):
                raise _api_error(
                    status.HTTP_403_FORBIDDEN,
                    "INSUFFICIENT_SCOPE",
                    f"This endpoint requires the '{scope}' scope.",
                )
        return ctx

    return _dep


def _require_project(ctx: AuthContext, project_id: str | None) -> None:
    """404 unless the project exists and is owned by the caller.

    None (no project requested) is a no-op.
    """
    if project_id is None:
        return
    factory = _session_factory()
    with factory() as session:
        if persistence_repo.get_project(session, ctx.user_id, project_id) is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "PROJECT_NOT_FOUND", "Project not found."
            )


def _session_factory():
    return persistence_db.get_session_factory(settings.database_url)


def _record_completed_analysis(
    ctx: AuthContext,
    project_id: str | None,
    repository_url: str,
    result: AnalysisResult,
) -> None:
    """Persist a finished repo analysis (+ finding snapshots) and meter it.

    A persistence failure never fails the request — it is logged.
    """
    if ctx.api_key_id is not None:
        try:
            with _session_factory()() as session:
                metering.increment(session, ctx.api_key_id, metering.COUNTER_ANALYSES)
                if result.ai_budget is not None and result.ai_budget.used:
                    metering.increment(
                        session, ctx.api_key_id, metering.COUNTER_AI_CALLS,
                        amount=result.ai_budget.used,
                    )
                session.commit()
        except Exception:
            logger.warning("Metering failed for repo analysis", exc_info=True)
    if not settings.persistence_enabled:
        return
    try:
        with _session_factory()() as session:
            findings = [f.model_dump(mode="json") for f in result.findings]
            summary = {
                "risk": result.risk.model_dump(mode="json"),
                "summary": result.summary.model_dump(mode="json"),
                "agents": result.agents.model_dump(mode="json") if result.agents else None,
                "ai_budget": result.ai_budget.model_dump(mode="json")
                if result.ai_budget
                else None,
            }
            persistence_repo.record_repo_analysis(
                session,
                user_id=ctx.user_id,
                project_id=project_id,
                repository_url=repository_url,
                findings=findings,
                risk_score=result.risk.score,
                summary=summary,
            )
            session.commit()
    except Exception:
        logger.warning("Failed to persist repo analysis", exc_info=True)
    _fire_webhook(
        event="scan.completed",
        kind="repo_analysis",
        project_id=project_id,
        findings_count=len(result.findings),
        risk_score=result.risk.score,
    )


def _record_completed_website_scan(
    ctx: AuthContext,
    project_id: str | None,
    result: WebsiteScanResult,
) -> None:
    """Persist a finished website scan (+ finding snapshots) and meter it."""
    if ctx.api_key_id is not None:
        try:
            with _session_factory()() as session:
                metering.increment(session, ctx.api_key_id, metering.COUNTER_SCANS)
                session.commit()
        except Exception:
            logger.warning("Metering failed for website scan", exc_info=True)
    if not settings.persistence_enabled:
        return
    try:
        with _session_factory()() as session:
            findings = [f.model_dump(mode="json") for f in result.findings]
            summary = {
                "scope": result.scope,
                "checks_run": result.checks_run,
                "requests_made": result.requests_made,
                "duration_ms": result.duration_ms,
                "disclaimer": result.disclaimer,
            }
            persistence_repo.record_website_scan(
                session,
                user_id=ctx.user_id,
                project_id=project_id,
                target_url=result.target_url,
                findings=findings,
                urls_scanned=len(result.urls_scanned),
                truncated=result.truncated,
                summary=summary,
            )
            session.commit()
    except Exception:
        logger.warning("Failed to persist website scan", exc_info=True)
    _fire_webhook(
        event="scan.completed",
        kind="website_scan",
        project_id=project_id,
        findings_count=len(result.findings),
        risk_score=None,
    )


def _fire_webhook(
    *,
    event: str,
    kind: str,
    project_id: str | None,
    findings_count: int,
    risk_score: float | None,
) -> None:
    """Phase 8: best-effort signed webhook on completed runs.

    Disabled when CODEAUDIT_WEBHOOK_URL is empty. Never raises and never
    carries credentials or secret values.
    """
    url = settings.webhook_url
    if not url:
        return
    if not settings.webhook_secret:
        logger.warning("CODEAUDIT_WEBHOOK_URL set without CODEAUDIT_WEBHOOK_SECRET — skipping webhook")
        return
    notifications.send_webhook(
        url,
        settings.webhook_secret,
        event,
        {
            "kind": kind,
            "project_id": project_id,
            "findings_count": findings_count,
            "risk_score": risk_score,
        },
    )


# --- Async job handlers (registered below; executed by the worker) ---

# Caller credentials for async website scans are kept in memory only,
# keyed by job id and consumed exactly once by the worker. They are never
# written to the database (Phase 6: credentials are never stored). If the
# worker runs as a separate process, the handoff is unavailable and the
# job fails with a clear code — documented, not silent.
_JOB_SECRETS: dict[str, dict] = {}


def _handle_repo_analysis_job(request: dict) -> dict:
    repository_url = request["repository_url"]
    github_service.validate_github_url(repository_url)
    with github_service.temporary_repo_dir() as tmp:
        repo_dir = tmp / "repo"
        orchestrator.fetch_repo(repository_url, repo_dir)
        result = supervisor.run(repository_url, repo_dir)
    ctx = AuthContext(
        user_id=request.get("user_id"),
        api_key_id=request.get("api_key_id"),
        key_prefix=None,
        scopes=frozenset(),
        anonymous=request.get("user_id") is None,
    )
    _record_completed_analysis(ctx, request.get("project_id"), repository_url, result)
    return result.model_dump(mode="json")


def _handle_website_scan_job(request: dict) -> dict:
    job_id = request["job_id"]
    secrets = _JOB_SECRETS.pop(job_id, None)
    if secrets is None:
        raise livescan_errors.ScanAuthorizationError(
            "Scan credentials are held in memory only and are unavailable "
            "to this worker (e.g. separate worker process). Run the scan "
            "synchronously or enable the in-process dev worker."
        )
    config = scan_config_from_settings(
        target_url=request["target_url"],
        authorization_token=secrets["authorization_token"],
        i_authorize_this_scan=True,
        include_subdomains=request.get("include_subdomains", False),
        path_prefix=request.get("path_prefix"),
        max_pages=request.get("max_pages"),
        active_probes=request.get("active_probes", True),
        session_cookie=secrets.get("session_cookie"),
        authorization_header=secrets.get("authorization_header"),
        settings=settings,
    )
    result = WebsiteScanner(config).run()
    ctx = AuthContext(
        user_id=request.get("user_id"),
        api_key_id=request.get("api_key_id"),
        key_prefix=None,
        scopes=frozenset(),
        anonymous=request.get("user_id") is None,
    )
    _record_completed_website_scan(ctx, request.get("project_id"), result)
    return result.model_dump(mode="json")


job_queue.HANDLERS[job_queue.JOB_KIND_REPO_ANALYSIS] = _handle_repo_analysis_job
job_queue.HANDLERS[job_queue.JOB_KIND_WEBSITE_SCAN] = _handle_website_scan_job


def _dev_bootstrap() -> None:
    """CODEAUDIT_DEV_BOOTSTRAP_KEY=true: create a dev user + admin key and
    print the key to stdout ONCE. Loud banner on purpose; never logged."""
    print("=" * 72)
    print("CODEAUDIT_DEV_BOOTSTRAP_KEY=true — DEVELOPMENT ONLY. Do not enable")
    print("in production: anyone with server log access gets an admin key.")
    print("=" * 72)
    persistence_db.init_db(settings.database_url)
    factory = _session_factory()
    with factory() as session:
        if persistence_repo.any_api_keys_exist(session):
            print("API keys already exist — not creating a bootstrap key.")
            return
        user = persistence_repo.create_user(session, "dev")
        record, plaintext = persistence_repo.create_api_key(
            session, user.id, name="dev-bootstrap", scopes=["admin"]
        )
        session.commit()
    # Intentional print (not logger): the key must be copyable from stdout
    # exactly once. It is never stored in plaintext anywhere.
    print(f"DEV API KEY (shown once — save it now): {plaintext}")
    print(f"Key prefix: {record.key_prefix}  (use X-API-Key header)")
    print("=" * 72)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: init DB (+ dev bootstrap, + dev worker). Shutdown: stop it."""
    if settings.persistence_enabled:
        persistence_db.init_db(settings.database_url)
    if settings.dev_bootstrap_key:
        _dev_bootstrap()
    stop_event: threading.Event | None = None
    worker: threading.Thread | None = None
    if settings.job_worker_enabled:
        stop_event = threading.Event()
        factory = _session_factory()
        worker = threading.Thread(
            target=job_queue.run_worker_forever,
            args=(factory, stop_event),
            kwargs={"handlers": None, "poll_interval": 1.0},
            daemon=True,
            name="codeaudit-dev-job-worker",
        )
        worker.start()
        logger.warning(
            "DEV-ONLY in-process job worker started "
            "(production: run the worker as a separate process)"
        )
    yield
    if stop_event is not None:
        stop_event.set()
    if worker is not None:
        worker.join(timeout=10)


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan,
    description=(
        "Evidence-driven security and code-quality analysis for GitHub repositories. "
        "Multi-agent backend: deterministic specialist agents (security, "
        "performance, quality) coordinated by a supervisor, with cost-capped "
        "Nemotron AI reasoning over verified repository evidence."
    ),
)

orchestrator = AnalysisOrchestrator()
remediation_engine = RemediationEngine()
# Multi-agent backend: the supervisor coordinates specialist agents with a
# hard AI-call budget (FREE/ECONOMY/FULL modes). Module-level `orchestrator`
# and `remediation_engine` names are kept for backward compatibility.
supervisor = SupervisorAgent(orchestrator=orchestrator)


# Phase 9 — serve the demo frontend from /ui when the frontend/ directory
# sits next to backend/ (single-URL deployment: same origin, no CORS
# configuration needed). Skipped silently when the directory is absent so
# the API still runs standalone.
_FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"
if _FRONTEND_DIR.is_dir():
    from fastapi.staticfiles import StaticFiles

    app.mount("/ui", StaticFiles(directory=str(_FRONTEND_DIR), html=True), name="ui")





@app.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    """Attach a per-request correlation ID.

    Echoed as the ``X-Request-ID`` response header so a client can match a
    response to server logs. The ID is also available to handlers as
    ``request.state.request_id``. Additive only: no contract changes.
    """
    raw = request.headers.get("X-Request-ID", "")
    request_id = raw if _REQUEST_ID_RE.match(raw) else uuid.uuid4().hex
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


@app.exception_handler(RemediationFindingNotFound)
async def remediation_not_found_handler(
    request: Request, exc: RemediationFindingNotFound
) -> JSONResponse:
    logger.warning("Remediation finding not found for %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=status.HTTP_404_NOT_FOUND,
        content=ErrorResponse(
            error={
                "code": exc.code,
                "message": REMEDIATION_SAFE_MESSAGES.get(exc.code, exc.code),
            }
        ).model_dump(mode="json"),
    )


@app.exception_handler(RemediationError)
async def remediation_error_handler(
    request: Request, exc: RemediationError
) -> JSONResponse:
    logger.warning("Remediation error for %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error={
                "code": exc.code,
                "message": REMEDIATION_SAFE_MESSAGES.get(exc.code, exc.code),
            }
        ).model_dump(mode="json"),
    )


@app.exception_handler(github_service.GitHubError)
async def github_error_handler(request: Request, exc: github_service.GitHubError) -> JSONResponse:
    status_code = {
        github_service.InvalidRepositoryURLError: status.HTTP_422_UNPROCESSABLE_CONTENT,
        github_service.RepositoryNotFoundError: status.HTTP_404_NOT_FOUND,
        github_service.CloneTimeoutError: status.HTTP_504_GATEWAY_TIMEOUT,
    }.get(type(exc), status.HTTP_502_BAD_GATEWAY)
    logger.warning("GitHub error for %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(
            error={"code": exc.code, "message": str(exc)}
        ).model_dump(mode="json"),
    )


@app.exception_handler(repository_scanner.RepositoryTooLargeError)
async def repo_too_large_handler(
    request: Request, exc: repository_scanner.RepositoryTooLargeError
) -> JSONResponse:
    logger.warning("Repository too large for %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=status.HTTP_413_CONTENT_TOO_LARGE,
        content=ErrorResponse(
            error={"code": exc.code, "message": str(exc)}
        ).model_dump(mode="json"),
    )


@app.exception_handler(repository_scanner.AnalysisTimeoutError)
async def analysis_timeout_handler(
    request: Request, exc: repository_scanner.AnalysisTimeoutError
) -> JSONResponse:
    logger.warning("Analysis timed out for %s: %s", request.url.path, exc)
    return JSONResponse(
        status_code=status.HTTP_504_GATEWAY_TIMEOUT,
        content=ErrorResponse(
            error={"code": exc.code, "message": str(exc)}
        ).model_dump(mode="json"),
    )


@app.exception_handler(livescan_errors.LiveScanError)
async def livescan_error_handler(
    request: Request, exc: livescan_errors.LiveScanError
) -> JSONResponse:
    # Never log the request body here: it carries the authorization token
    # and optional session credentials.
    status_code = {
        livescan_errors.ScanAuthorizationError: status.HTTP_403_FORBIDDEN,
        livescan_errors.ScanScopeError: status.HTTP_400_BAD_REQUEST,
        livescan_errors.SSRFBlockedError: status.HTTP_400_BAD_REQUEST,
        livescan_errors.ScanBudgetError: status.HTTP_429_TOO_MANY_REQUESTS,
        livescan_errors.ScanTimeoutError: status.HTTP_504_GATEWAY_TIMEOUT,
    }.get(type(exc), status.HTTP_400_BAD_REQUEST)
    logger.warning("Live scan error for %s: %s", request.url.path, exc.code)
    return JSONResponse(
        status_code=status_code,
        content=ErrorResponse(
            error={"code": exc.code, "message": str(exc)}
        ).model_dump(mode="json"),
    )


@app.exception_handler(Exception)
async def unhandled_error_handler(request: Request, exc: Exception) -> JSONResponse:
    # Preserve FastAPI's own HTTP error contract (validation 422s, etc.);
    # only unexpected failures become structured 500s.
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail},
            headers=getattr(exc, "headers", None),
        )
    logger.exception(
        "Unhandled error during %s %s (request_id=%s)",
        request.method,
        request.url.path,
        getattr(request.state, "request_id", "-"),
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(
            error={
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred while analyzing the repository.",
            }
        ).model_dump(mode="json"),
    )


@app.get("/health")
def health() -> dict:
    """Liveness probe: stable, minimal contract."""
    return {"status": "ok", "version": settings.app_version}


@app.post("/analyze", response_model=AnalysisResult)
def analyze(
    request: AnalysisRequest,
    async_req: bool = Query(default=False, alias="async"),
    ctx: AuthContext = Depends(require_scope("scan")),
):
    """Analyze a public GitHub repository and return structured findings.

    Runs through the multi-agent supervisor: deterministic specialists
    (security, performance, quality) in parallel, budgeted Nemotron
    evidence review per the configured agent mode, deterministic fusion.

    With ``?async=true`` the analysis runs as a durable background job:
    HTTP 202 with ``{"job_id": ...}``; poll ``GET /jobs/{job_id}``.
    """
    ref = github_service.validate_github_url(request.repository_url)
    if request.project_id is not None:
        _require_project(ctx, request.project_id)
    if async_req:
        factory = _session_factory()
        with factory() as session:
            job = job_queue.enqueue_job(
                session,
                kind=job_queue.JOB_KIND_REPO_ANALYSIS,
                request={
                    "repository_url": request.repository_url,
                    "project_id": request.project_id,
                    "user_id": ctx.user_id,
                    "api_key_id": ctx.api_key_id,
                },
                user_id=ctx.user_id,
                project_id=request.project_id,
                api_key_id=ctx.api_key_id,
            )
            session.commit()
            job_id, state = job.id, job.state
        # 202 with a job payload (not an AnalysisResult): return a raw
        # JSONResponse so response_model validation is bypassed.
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED,
            content=JobAcceptedOut(job_id=job_id, state=state).model_dump(mode="json"),
        )
    with github_service.temporary_repo_dir() as tmp:
        repo_dir = tmp / "repo"
        orchestrator.fetch_repo(request.repository_url, repo_dir)
        result = supervisor.run(request.repository_url, repo_dir)
    _record_completed_analysis(ctx, request.project_id, request.repository_url, result)
    return result


@app.post("/remediate", response_model=RemediationResult)
def remediate(
    request: RemediationRequest,
    ctx: AuthContext = Depends(require_scope("scan")),
) -> RemediationResult:
    """Propose and deterministically verify a fix for one finding.

    FIND -> FIX -> VERIFY, coordinated by the supervisor: the Fix agent
    proposes a minimal patch (budgeted), the patch engine validates and
    applies it inside an isolated temporary workspace, and the
    Verification agent verifies the outcome deterministically. The
    original repository is never modified.
    """
    github_service.validate_github_url(request.repository_url)
    with github_service.temporary_repo_dir() as tmp:
        repo_dir = tmp / "repo"
        orchestrator.fetch_repo(request.repository_url, repo_dir)
        before = supervisor.run(request.repository_url, repo_dir)
        return supervisor.remediate_finding(request.finding_id, repo_dir, before)


@app.post("/remediate/batch", response_model=list[RemediationResult])
def remediate_batch(
    request: BatchRemediationRequest,
    ctx: AuthContext = Depends(require_scope("scan")),
) -> list[RemediationResult]:
    """Remediate several findings, each independently against the original
    repository. Hard-capped by CODEAUDIT_MAX_REMEDIATIONS_PER_REQUEST."""
    cap = settings.max_remediations_per_request
    if len(request.finding_ids) > cap:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"finding_ids exceeds the per-request limit of {cap} "
                "(CODEAUDIT_MAX_REMEDIATIONS_PER_REQUEST)"
            ),
        )
    github_service.validate_github_url(request.repository_url)
    with github_service.temporary_repo_dir() as tmp:
        repo_dir = tmp / "repo"
        orchestrator.fetch_repo(request.repository_url, repo_dir)
        before = supervisor.run(request.repository_url, repo_dir)
        return supervisor.remediate_findings(request.finding_ids, repo_dir, before)


@app.post("/scan/website", response_model=WebsiteScanResult)
def scan_website(
    request: WebsiteScanRequest,
    async_req: bool = Query(default=False, alias="async"),
    ctx: AuthContext = Depends(require_scope("scan")),
) -> WebsiteScanResult:
    """Authorized live security scan of a website.

    This is a DISTINCT capability from repository analysis: it makes
    outbound HTTP requests to the target. A scan runs only when the
    request carries the per-host authorization token configured via
    CODEAUDIT_SCAN_TOKENS AND sets i_authorize_this_scan=true;
    anything else is rejected with 403 before any network I/O.

    Every request passes the SSRF guard (private/loopback/link-local/
    multicast/reserved addresses refused; localhost only with
    CODEAUDIT_SCAN_ALLOW_LOCALHOST=true), and the crawl stays within
    the authorized host + path prefix. Active probes are GET-only,
    rate-limited, non-destructive, and their findings are capped at
    MEDIUM confidence with a manual-verification note.

    The request body may contain credentials (authorization token,
    session cookie): they are used for this scan only, never logged,
    and never stored.
    """
    # NOTE: never log request.authorization_token / session_cookie /
    # authorization_header — they are caller credentials.
    _require_project(ctx, request.project_id)
    if async_req:
        # The worker re-authorizes the target itself (scan_config_from_settings
        # raises 403-equivalent errors on bad tokens); credentials travel in
        # memory only (_JOB_SECRETS), never in the database.
        # (Project already validated above.)
        factory = _session_factory()
        with factory() as session:
            job = job_queue.enqueue_job(
                session,
                kind=job_queue.JOB_KIND_WEBSITE_SCAN,
                request={
                    "job_id": None,  # filled in below
                    "target_url": request.target_url,
                    "include_subdomains": request.include_subdomains,
                    "path_prefix": request.path_prefix,
                    "max_pages": request.max_pages,
                    "active_probes": request.active_probes,
                    "project_id": request.project_id,
                    "user_id": ctx.user_id,
                    "api_key_id": ctx.api_key_id,
                },
                user_id=ctx.user_id,
                project_id=request.project_id,
                api_key_id=ctx.api_key_id,
            )
            session.flush()
            job_request = json.loads(job.request_json)
            job_request["job_id"] = job.id
            job.request_json = json.dumps(job_request)
            session.commit()
            job_id, state = job.id, job.state
        _JOB_SECRETS[job_id] = {
            "authorization_token": request.authorization_token,
            "session_cookie": request.session_cookie,
            "authorization_header": request.authorization_header,
        }
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED,
            content=JobAcceptedOut(job_id=job_id, state=state).model_dump(mode="json"),
        )
    config = scan_config_from_settings(
        target_url=request.target_url,
        authorization_token=request.authorization_token,
        i_authorize_this_scan=request.i_authorize_this_scan,
        include_subdomains=request.include_subdomains,
        path_prefix=request.path_prefix,
        max_pages=request.max_pages,
        active_probes=request.active_probes,
        session_cookie=request.session_cookie,
        authorization_header=request.authorization_header,
        settings=settings,
    )
    result = WebsiteScanner(config).run()
    _record_completed_website_scan(ctx, request.project_id, result)
    return result


# ---------------------------------------------------------------------------
# Phase 7 — projects, scan history, jobs, usage, API keys
# ---------------------------------------------------------------------------


def _project_out(project) -> ProjectOut:
    return ProjectOut(
        id=project.id,
        name=project.name,
        created_at=project.created_at.isoformat(),
    )


def _job_out(job) -> JobOut:
    result = None
    if job.result_json:
        try:
            result = json.loads(job.result_json)
        except ValueError:
            result = None
    return JobOut(
        id=job.id,
        kind=job.kind,
        state=job.state,
        project_id=job.project_id,
        created_at=job.created_at.isoformat(),
        updated_at=job.updated_at.isoformat(),
        started_at=job.started_at.isoformat() if job.started_at else None,
        finished_at=job.finished_at.isoformat() if job.finished_at else None,
        error_code=job.error_code,
        error_message=job.error_message,
        result=result,
    )


@app.post("/projects", response_model=ProjectOut)
def create_project(
    body: ProjectCreate,
    ctx: AuthContext = Depends(require_scope("read")),
) -> ProjectOut:
    """Create a project (tenant root for scan history)."""
    factory = _session_factory()
    with factory() as session:
        project = persistence_repo.create_project(session, ctx.user_id, body.name)
        session.commit()
        return _project_out(project)


@app.get("/projects", response_model=list[ProjectOut])
def list_projects(
    ctx: AuthContext = Depends(require_scope("read")),
) -> list[ProjectOut]:
    """List the caller's projects (tenant-scoped)."""
    factory = _session_factory()
    with factory() as session:
        return [
            _project_out(p)
            for p in persistence_repo.list_projects(session, ctx.user_id)
        ]


@app.get("/projects/{project_id}", response_model=ProjectOut)
def get_project(
    project_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> ProjectOut:
    factory = _session_factory()
    with factory() as session:
        project = persistence_repo.get_project(session, ctx.user_id, project_id)
        if project is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "PROJECT_NOT_FOUND", "Project not found."
            )
        return _project_out(project)


@app.get("/projects/{project_id}/scans", response_model=ProjectHistoryOut)
def project_scan_history(
    project_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> ProjectHistoryOut:
    """Scan history for one project: repo analyses + website scans."""
    factory = _session_factory()
    with factory() as session:
        try:
            analyses, scans = persistence_repo.list_project_history(
                session, ctx.user_id, project_id
            )
        except LookupError:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "PROJECT_NOT_FOUND", "Project not found."
            )
        return ProjectHistoryOut(
            project_id=project_id,
            repo_analyses=[
                RepoAnalysisHistoryOut(
                    id=a.id,
                    project_id=a.project_id,
                    repository_url=a.repository_url,
                    status=a.status,
                    findings_count=a.findings_count,
                    risk_score=a.risk_score,
                    created_at=a.created_at.isoformat(),
                    finished_at=a.finished_at.isoformat() if a.finished_at else None,
                )
                for a in analyses
            ],
            website_scans=[
                WebsiteScanHistoryOut(
                    id=s.id,
                    project_id=s.project_id,
                    target_url=s.target_url,
                    status=s.status,
                    findings_count=s.findings_count,
                    urls_scanned=s.urls_scanned,
                    truncated=s.truncated,
                    created_at=s.created_at.isoformat(),
                    finished_at=s.finished_at.isoformat() if s.finished_at else None,
                )
                for s in scans
            ],
        )


@app.get("/analyses/{analysis_id}", response_model=AnalysisDetailOut)
def get_analysis_detail(
    analysis_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> AnalysisDetailOut:
    """One persisted repo analysis with its immutable finding snapshots."""
    from models.schemas import Finding

    factory = _session_factory()
    with factory() as session:
        analysis = persistence_repo.get_repo_analysis(session, ctx.user_id, analysis_id)
        if analysis is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "ANALYSIS_NOT_FOUND", "Analysis not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "repo_analysis", analysis.id
        )
        findings = [Finding(**s) for s in snapshots]
        return AnalysisDetailOut(
            id=analysis.id,
            project_id=analysis.project_id,
            repository_url=analysis.repository_url,
            status=analysis.status,
            findings_count=analysis.findings_count,
            risk_score=analysis.risk_score,
            created_at=analysis.created_at.isoformat(),
            finished_at=analysis.finished_at.isoformat()
            if analysis.finished_at
            else None,
            findings=findings,
        )


@app.get("/website-scans/{scan_id}", response_model=WebsiteScanDetailOut)
def get_website_scan_detail(
    scan_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> WebsiteScanDetailOut:
    """One persisted website scan with its immutable finding snapshots."""
    from models.schemas import Finding

    factory = _session_factory()
    with factory() as session:
        scan = persistence_repo.get_website_scan(session, ctx.user_id, scan_id)
        if scan is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "SCAN_NOT_FOUND", "Website scan not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "website_scan", scan.id
        )
        findings = [Finding(**s) for s in snapshots]
        return WebsiteScanDetailOut(
            id=scan.id,
            project_id=scan.project_id,
            target_url=scan.target_url,
            status=scan.status,
            findings_count=scan.findings_count,
            urls_scanned=scan.urls_scanned,
            truncated=scan.truncated,
            created_at=scan.created_at.isoformat(),
            finished_at=scan.finished_at.isoformat() if scan.finished_at else None,
            findings=findings,
        )


@app.get("/jobs/{job_id}", response_model=JobOut)
def get_job(
    job_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> JobOut:
    """Durable job status (tenant-scoped)."""
    factory = _session_factory()
    with factory() as session:
        job = persistence_repo.get_job(session, ctx.user_id, job_id)
        if job is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "JOB_NOT_FOUND", "Job not found."
            )
        return _job_out(job)


@app.delete("/jobs/{job_id}", response_model=JobOut)
def cancel_job(
    job_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> JobOut:
    """Cancel a queued job. Running jobs cannot be cancelled (409)."""
    factory = _session_factory()
    with factory() as session:
        job = persistence_repo.get_job(session, ctx.user_id, job_id)
        if job is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "JOB_NOT_FOUND", "Job not found."
            )
        if not job_queue.cancel_job(session, job):
            raise _api_error(
                status.HTTP_409_CONFLICT,
                "JOB_NOT_CANCELLABLE",
                f"Job is {job.state}; only queued jobs can be cancelled.",
            )
        session.commit()
        # Drop any in-memory scan credentials for this job: they are
        # single-use and must not linger after cancellation.
        _JOB_SECRETS.pop(job_id, None)
        return _job_out(job)


@app.get("/usage", response_model=UsageOut)
def get_usage(
    ctx: AuthContext = Depends(require_scope("read")),
) -> UsageOut:
    """Usage counters for the caller's API key (billing input, Phase 11)."""
    if ctx.anonymous or ctx.api_key_id is None:
        raise _api_error(
            status.HTTP_401_UNAUTHORIZED,
            "API_KEY_REQUIRED",
            "Usage is metered per API key; call with X-API-Key.",
        )
    factory = _session_factory()
    with factory() as session:
        counters = metering.get_counters(session, ctx.api_key_id)
        return UsageOut(api_key_prefix=ctx.key_prefix, counters=counters)


@app.post("/keys", response_model=ApiKeyCreatedOut)
def create_api_key(
    body: ApiKeyCreate,
    ctx: AuthContext = Depends(get_auth_context),
) -> ApiKeyCreatedOut:
    """Issue a new API key for the caller. The plaintext is shown once."""
    if ctx.anonymous or ctx.user_id is None:
        raise _api_error(
            status.HTTP_401_UNAUTHORIZED,
            "AUTH_REQUIRED",
            "API key issuance requires an authenticated user.",
        )
    try:
        scopes = persistence_auth.normalize_scopes(body.scopes)
    except ValueError as exc:
        raise _api_error(status.HTTP_400_BAD_REQUEST, "INVALID_SCOPE", str(exc))
    factory = _session_factory()
    with factory() as session:
        record, plaintext = persistence_repo.create_api_key(
            session, ctx.user_id, name=body.name, scopes=scopes
        )
        session.commit()
        return ApiKeyCreatedOut(
            id=record.id,
            key_prefix=record.key_prefix,
            name=record.name,
            scopes=scopes,
            api_key=plaintext,
        )


@app.get("/keys", response_model=list[ApiKeyOut])
def list_api_keys(
    ctx: AuthContext = Depends(get_auth_context),
) -> list[ApiKeyOut]:
    """List the caller's API keys (hashes never leave the server)."""
    if ctx.anonymous or ctx.user_id is None:
        raise _api_error(
            status.HTTP_401_UNAUTHORIZED, "AUTH_REQUIRED", "Authentication required."
        )
    factory = _session_factory()
    with factory() as session:
        keys = persistence_repo.list_api_keys(session, ctx.user_id)
        return [
            ApiKeyOut(
                id=k.id,
                key_prefix=k.key_prefix,
                name=k.name,
                scopes=persistence_auth.decode_scopes(k.scopes),
                revoked=k.revoked,
                created_at=k.created_at.isoformat(),
                last_used_at=k.last_used_at.isoformat() if k.last_used_at else None,
            )
            for k in keys
        ]


@app.delete("/keys/{key_id}", response_model=dict)
def revoke_api_key(
    key_id: str,
    ctx: AuthContext = Depends(get_auth_context),
) -> dict:
    """Revoke one of the caller's own API keys."""
    if ctx.anonymous or ctx.user_id is None:
        raise _api_error(
            status.HTTP_401_UNAUTHORIZED, "AUTH_REQUIRED", "Authentication required."
        )
    factory = _session_factory()
    with factory() as session:
        if not persistence_repo.revoke_api_key(session, ctx.user_id, key_id):
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "KEY_NOT_FOUND", "API key not found."
            )
        session.commit()
        return {"revoked": True, "key_id": key_id}


# ---------------------------------------------------------------------------
# Phase 8 — finding lifecycle, retest, report exports
# ---------------------------------------------------------------------------


def _retest_finding_out(
    finding: dict, fingerprint: str, lifecycle: str | None
) -> RetestFindingOut:
    return RetestFindingOut(
        fingerprint=fingerprint,
        rule_id=finding.get("rule_id"),
        title=finding.get("title") or "",
        severity=str(finding.get("severity") or ""),
        file=finding.get("file"),
        url=finding.get("url"),
        line=finding.get("line"),
        lifecycle=lifecycle,
    )


@app.post("/projects/{project_id}/findings/status", response_model=FindingStatusOut)
def set_project_finding_status(
    project_id: str,
    request: FindingStatusIn,
    ctx: AuthContext = Depends(require_scope("scan")),
) -> FindingStatusOut:
    """Set a lifecycle status (acknowledged/fixed) for one finding fingerprint.

    Absence of a row means "new". Tenant-scoped: cross-user projects 404.
    """
    _require_project(ctx, project_id)
    factory = _session_factory()
    with factory() as session:
        row = persistence_repo.set_finding_status(
            session,
            user_id=ctx.user_id,
            project_id=project_id,
            fingerprint=request.fingerprint,
            status=request.status,
            note=request.note,
        )
        session.commit()
        return FindingStatusOut(
            fingerprint=row.fingerprint,
            status=row.status,
            note=row.note,
            updated_at=row.updated_at.isoformat(),
        )


@app.get("/projects/{project_id}/findings/status", response_model=list[FindingStatusOut])
def list_project_finding_statuses(
    project_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> list[FindingStatusOut]:
    """List lifecycle statuses for a project (rows only; no row = new)."""
    _require_project(ctx, project_id)
    factory = _session_factory()
    with factory() as session:
        rows = persistence_repo.get_finding_statuses(
            session, user_id=ctx.user_id, project_id=project_id
        )
        return [
            FindingStatusOut(
                fingerprint=r.fingerprint,
                status=r.status,
                note=r.note,
                updated_at=r.updated_at.isoformat(),
            )
            for r in rows
        ]


def _run_repo_analysis_sync(repository_url: str) -> AnalysisResult:
    """Shared sync analysis used by /analyze and retest."""
    github_service.validate_github_url(repository_url)
    with github_service.temporary_repo_dir() as tmp:
        repo_dir = tmp / "repo"
        orchestrator.fetch_repo(repository_url, repo_dir)
        return supervisor.run(repository_url, repo_dir)


def _run_website_scan_sync(
    target_url: str,
    authorization_token: str,
    include_subdomains: bool = False,
) -> WebsiteScanResult:
    """Shared sync website scan used by /scan/website and retest.

    Retest always uses default probe settings against the same target;
    the caller must supply FRESH authorization (never reused).
    """
    config = scan_config_from_settings(
        target_url=target_url,
        authorization_token=authorization_token,
        i_authorize_this_scan=True,
        include_subdomains=include_subdomains,
        settings=settings,
    )
    return WebsiteScanner(config).run()


@app.post("/projects/{project_id}/retest", response_model=RetestResultOut)
def retest_project(
    project_id: str,
    request: RetestRequest,
    ctx: AuthContext = Depends(require_scope("scan")),
) -> RetestResultOut:
    """Re-run a project's latest analysis/scan and diff the findings.

    Compares finding fingerprints between the previous run's snapshots
    and the new run: new / persisting / resolved. Findings previously
    marked "fixed" that still persist are flagged "regressed"; marked
    "fixed" and now resolved are flagged "verified".

    Website retests require fresh per-request authorization
    (authorization_token + i_authorize_this_scan=true); stored scans
    never reuse caller credentials.
    """
    _require_project(ctx, project_id)
    factory = _session_factory()

    if request.kind == "repo_analysis":
        with factory() as session:
            previous = persistence_repo.get_latest_repo_analysis(
                session, user_id=ctx.user_id, project_id=project_id
            )
            if previous is None:
                raise _api_error(
                    status.HTTP_404_NOT_FOUND,
                    "NO_PREVIOUS_RUN",
                    "No repo analysis found for this project.",
                )
            prev_id, target, risk_before = (
                previous.id,
                previous.repository_url,
                previous.risk_score,
            )
            old_findings = persistence_repo.get_finding_snapshots(
                session, "repo_analysis", prev_id
            )
            statuses = {
                r.fingerprint: r.status
                for r in persistence_repo.get_finding_statuses(
                    session, user_id=ctx.user_id, project_id=project_id
                )
            }
        result = _run_repo_analysis_sync(target)
        new_findings = [f.model_dump(mode="json") for f in result.findings]
        _record_completed_analysis(ctx, project_id, target, result)
        with factory() as session:
            new_run = persistence_repo.get_latest_repo_analysis(
                session, user_id=ctx.user_id, project_id=project_id
            )
            new_run_id = new_run.id if new_run else ""
        risk_after = result.risk.score
    else:
        if not request.i_authorize_this_scan or not request.authorization_token:
            raise _api_error(
                status.HTTP_403_FORBIDDEN,
                "SCAN_NOT_AUTHORIZED",
                "Website retest requires a fresh authorization_token and "
                "i_authorize_this_scan=true.",
            )
        with factory() as session:
            previous = persistence_repo.get_latest_website_scan(
                session, user_id=ctx.user_id, project_id=project_id
            )
            if previous is None:
                raise _api_error(
                    status.HTTP_404_NOT_FOUND,
                    "NO_PREVIOUS_RUN",
                    "No website scan found for this project.",
                )
            prev_id, target = previous.id, previous.target_url
            old_findings = persistence_repo.get_finding_snapshots(
                session, "website_scan", prev_id
            )
            statuses = {
                r.fingerprint: r.status
                for r in persistence_repo.get_finding_statuses(
                    session, user_id=ctx.user_id, project_id=project_id
                )
            }
        # NOTE: never log request.authorization_token — caller credential.
        result = _run_website_scan_sync(target, request.authorization_token)
        new_findings = [f.model_dump(mode="json") for f in result.findings]
        _record_completed_website_scan(ctx, project_id, result)
        with factory() as session:
            new_run = persistence_repo.get_latest_website_scan(
                session, user_id=ctx.user_id, project_id=project_id
            )
            new_run_id = new_run.id if new_run else ""
        risk_after = None

    diff = retest_lib.diff_findings(old_findings, new_findings)

    def annotate(finding: dict, bucket: str) -> RetestFindingOut:
        fp = retest_lib.finding_fingerprint(finding)
        lifecycle = None
        if statuses.get(fp) == "fixed":
            lifecycle = "regressed" if bucket == "persisting" else (
                "verified" if bucket == "resolved" else None
            )
        elif statuses.get(fp) == "acknowledged" and bucket == "persisting":
            lifecycle = "acknowledged"
        return _retest_finding_out(finding, fp, lifecycle)

    return RetestResultOut(
        project_id=project_id,
        kind=request.kind,
        previous_run_id=prev_id,
        new_run_id=new_run_id,
        new=[annotate(f, "new") for f in diff["new"]],
        persisting=[annotate(f, "persisting") for f in diff["persisting"]],
        resolved=[annotate(f, "resolved") for f in diff["resolved"]],
        risk_before=risk_before if request.kind == "repo_analysis" else None,
        risk_after=risk_after,
    )


class RunFindingsOut(BaseModel):
    fingerprint: str
    finding: dict


@app.get("/analyses/{analysis_id}/findings", response_model=list[RunFindingsOut])
def analysis_findings(
    analysis_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> list[RunFindingsOut]:
    """Findings of one analysis, each with its stable retest fingerprint."""
    factory = _session_factory()
    with factory() as session:
        if persistence_repo.get_repo_analysis(session, ctx.user_id, analysis_id) is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "ANALYSIS_NOT_FOUND", "Analysis not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "repo_analysis", analysis_id
        )
    return [
        RunFindingsOut(
            fingerprint=retest_lib.finding_fingerprint(s), finding=s
        )
        for s in snapshots
    ]


@app.get("/website-scans/{scan_id}/findings", response_model=list[RunFindingsOut])
def website_scan_findings(
    scan_id: str,
    ctx: AuthContext = Depends(require_scope("read")),
) -> list[RunFindingsOut]:
    """Findings of one website scan, each with its stable retest fingerprint."""
    factory = _session_factory()
    with factory() as session:
        if persistence_repo.get_website_scan(session, ctx.user_id, scan_id) is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "SCAN_NOT_FOUND", "Website scan not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "website_scan", scan_id
        )
    return [
        RunFindingsOut(
            fingerprint=retest_lib.finding_fingerprint(s), finding=s
        )
        for s in snapshots
    ]


@app.get("/analyses/{analysis_id}/report")
def analysis_report(
    analysis_id: str,
    format: str = Query(default="markdown", pattern="^(markdown|html)$"),
    ctx: AuthContext = Depends(require_scope("read")),
):
    """Export a repo analysis report as Markdown or self-contained HTML."""
    factory = _session_factory()
    with factory() as session:
        analysis = persistence_repo.get_repo_analysis(session, ctx.user_id, analysis_id)
        if analysis is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "ANALYSIS_NOT_FOUND", "Analysis not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "repo_analysis", analysis_id
        )
    lines = [
        f"# CodeAudit Report — {analysis.repository_url}",
        "",
        f"Findings: {analysis.findings_count} | Risk: {analysis.risk_score}/10",
        "",
        "## Findings",
    ]
    for s in snapshots:
        lines.extend(
            [
                "",
                f"### [{str(s.get('severity', '')).upper()}] {s.get('title', '')}",
                f"Rule: `{s.get('rule_id', '')}` | File: `{s.get('file', '')}` "
                f"line {s.get('line', '')} (confidence: {s.get('confidence', '')}, "
                f"source: {s.get('source', '')})",
                "",
                "```",
                str(s.get("evidence", "")),
                "```",
                "",
                str(s.get("description", "")),
            ]
        )
        if s.get("suggested_fix"):
            lines.extend(["", f"Suggested fix: {s.get('suggested_fix')}"])
    lines.extend(
        [
            "",
            "> Scope note: this report reflects one analysis run. Absence of "
            "findings is not proof of security.",
        ]
    )
    if format == "html":
        return HTMLResponse(content=_markdown_lines_to_html(lines, analysis.repository_url))
    return PlainTextResponse(content="\n".join(lines) + "\n")


def _markdown_lines_to_html(lines: list[str], title: str) -> str:
    """Minimal markdown-ish to self-contained HTML (escaped, no external assets)."""
    import html as _html

    out = []
    in_code = False
    for line in lines:
        if line.strip() == "```":
            out.append("</pre>" if in_code else "<pre>")
            in_code = not in_code
            continue
        if in_code:
            out.append(_html.escape(line))
            continue
        if line.startswith("### "):
            out.append(f"<h3>{_html.escape(line[4:])}</h3>")
        elif line.startswith("## "):
            out.append(f"<h2>{_html.escape(line[3:])}</h2>")
        elif line.startswith("# "):
            out.append(f"<h1>{_html.escape(line[2:])}</h1>")
        elif line.startswith("> "):
            out.append(f"<blockquote>{_html.escape(line[2:])}</blockquote>")
        elif line:
            out.append(f"<p>{_html.escape(line)}</p>")
    body = "\n".join(out)
    return (
        "<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>"
        f"<title>CodeAudit Report — {_html.escape(title)}</title>"
        "<style>body{font-family:system-ui,sans-serif;max-width:960px;margin:2rem auto;"
        "padding:0 1rem;color:#111827}pre{background:#f3f4f6;padding:.75rem;"
        "border-radius:6px;overflow-x:auto;font-size:.85rem}"
        "blockquote{background:#fef3c7;border:1px solid #f59e0b;border-radius:8px;"
        "padding:1rem}</style></head><body>" + body + "</body></html>"
    )


@app.get("/website-scans/{scan_id}/report")
def website_scan_report(
    scan_id: str,
    format: str = Query(default="markdown", pattern="^(markdown|html)$"),
    ctx: AuthContext = Depends(require_scope("read")),
):
    """Export a website scan report as Markdown or self-contained HTML."""
    factory = _session_factory()
    with factory() as session:
        scan = persistence_repo.get_website_scan(session, ctx.user_id, scan_id)
        if scan is None:
            raise _api_error(
                status.HTTP_404_NOT_FOUND, "SCAN_NOT_FOUND", "Website scan not found."
            )
        snapshots = persistence_repo.get_finding_snapshots(
            session, "website_scan", scan_id
        )
        summary = json.loads(scan.summary_json or "{}")
    lines = [
        f"# CodeAudit Website Scan Report — {scan.target_url}",
        "",
        f"URLs scanned: {scan.urls_scanned} | Findings: {scan.findings_count} | "
        f"Truncated: {scan.truncated}",
        "",
        summary.get("disclaimer", ""),
        "",
        "## Findings",
    ]
    for s in snapshots:
        lines.extend(
            [
                "",
                f"### [{str(s.get('severity', '')).upper()}] {s.get('title', '')}",
                f"Rule: `{s.get('rule_id', '')}` | URL: `{s.get('url', '')}` "
                f"(confidence: {s.get('confidence', '')}, "
                f"source: {s.get('source', '')})",
                "",
                "```",
                str(s.get("evidence", "")),
                "```",
                "",
                str(s.get("description", "")),
            ]
        )
    lines.extend(
        [
            "",
            "> Scope note: this report reflects one scan. Absence of findings "
            "is not proof of security.",
        ]
    )
    if format == "html":
        return HTMLResponse(
            content=_markdown_lines_to_html(lines, f"Website scan — {scan.target_url}")
        )
    return PlainTextResponse(content="\n".join(lines) + "\n")
