"""Phase 8 tests: finding lifecycle, retest diffing, report exports,
webhook notifications. All hermetic (tmp SQLite; no network — analysis
and scan runners are monkeypatched, webhook HTTP is stubbed).
"""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app import main as app_main
from services import notifications
from services import retest as retest_lib
from services.persistence import database as persistence_db
from services.persistence import repository as persistence_repo


# ---------------------------------------------------------------------------
# Fingerprint + diff (pure unit tests, no DB)
# ---------------------------------------------------------------------------


def _finding(rule="PY-SEC-001", file="a.py", line=10, evidence="eval(x)"):
    return {
        "rule_id": rule,
        "file": file,
        "line": line,
        "evidence": evidence,
        "title": "t",
        "severity": "high",
    }


def test_fingerprint_stable_and_ignores_line_shift():
    f1 = _finding(line=10)
    f2 = _finding(line=42)  # line numbers shift; identity must not
    assert retest_lib.finding_fingerprint(f1) == retest_lib.finding_fingerprint(f2)


def test_fingerprint_differs_on_evidence_or_rule():
    f1 = _finding()
    assert retest_lib.finding_fingerprint(f1) != retest_lib.finding_fingerprint(
        _finding(evidence="exec(y)")
    )
    assert retest_lib.finding_fingerprint(f1) != retest_lib.finding_fingerprint(
        _finding(rule="PY-SEC-002")
    )
    assert len(retest_lib.finding_fingerprint(f1)) == 32


def test_diff_findings_buckets():
    old = [_finding(rule="R1"), _finding(rule="R2"), _finding(rule="R3")]
    new = [_finding(rule="R2"), _finding(rule="R3"), _finding(rule="R4")]
    diff = retest_lib.diff_findings(old, new)
    assert [f["rule_id"] for f in diff["new"]] == ["R4"]
    assert sorted(f["rule_id"] for f in diff["persisting"]) == ["R2", "R3"]
    assert [f["rule_id"] for f in diff["resolved"]] == ["R1"]


def test_diff_empty_old_is_all_new():
    diff = retest_lib.diff_findings([], [_finding()])
    assert len(diff["new"]) == 1 and not diff["persisting"] and not diff["resolved"]


# ---------------------------------------------------------------------------
# Webhook signing / delivery (stubbed HTTP, no network)
# ---------------------------------------------------------------------------


class _FakeResponse:
    def __init__(self, status_code=200):
        self.status_code = status_code


class _FakeClient:
    instances = []

    def __init__(self, *args, **kwargs):
        self.requests = []
        _FakeClient.instances.append(self)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def post(self, url, content=None, headers=None):
        self.requests.append((url, content, headers))
        return _FakeResponse(200)


@pytest.fixture()
def stub_http(monkeypatch):
    _FakeClient.instances.clear()
    monkeypatch.setattr(notifications.httpx, "Client", _FakeClient)
    return _FakeClient


def test_webhook_signs_and_posts(stub_http):
    ok = notifications.send_webhook(
        "https://hooks.example.test/x", "s3cret", "scan.completed", {"kind": "repo_analysis"}
    )
    assert ok is True
    assert len(stub_http.instances) == 1
    url, content, headers = stub_http.instances[0].requests[0]
    assert url == "https://hooks.example.test/x"
    body = json.loads(content)
    assert body["event"] == "scan.completed" and body["kind"] == "repo_analysis"
    assert headers["X-CodeAudit-Event"] == "scan.completed"
    sig = headers["X-CodeAudit-Signature"]
    assert sig.startswith("sha256=")
    assert sig == "sha256=" + notifications.sign_payload("s3cret", content)


def test_webhook_failure_returns_false_not_raise(monkeypatch):
    class _BoomClient(_FakeClient):
        def post(self, *a, **k):
            raise ConnectionError("down")

    monkeypatch.setattr(notifications.httpx, "Client", _BoomClient)
    assert (
        notifications.send_webhook("https://x.test", "s", "e", {}) is False
    )


def test_webhook_non_2xx_returns_false(monkeypatch):
    class _500Client(_FakeClient):
        def post(self, *a, **k):
            return _FakeResponse(500)

    monkeypatch.setattr(notifications.httpx, "Client", _500Client)
    assert notifications.send_webhook("https://x.test", "s", "e", {}) is False


# ---------------------------------------------------------------------------
# DB-backed: lifecycle, migration, reports, retest (via API)
# ---------------------------------------------------------------------------


@pytest.fixture()
def db_url(tmp_path: Path) -> str:
    return f"sqlite:///{tmp_path}/test.db"


@pytest.fixture()
def app_settings(monkeypatch, db_url: str):
    from dataclasses import fields

    real = app_main.settings
    ns = SimpleNamespace(**{f.name: getattr(real, f.name) for f in fields(real)})
    ns.database_url = db_url
    monkeypatch.setattr(app_main, "settings", ns)
    persistence_db.reset_engine_cache()
    persistence_db.init_db(db_url)
    yield ns
    persistence_db.reset_engine_cache()
    app_main._JOB_SECRETS.clear()


@pytest.fixture()
def factory(app_settings, db_url: str):
    return persistence_db.get_session_factory(db_url)


@pytest.fixture()
def client() -> TestClient:
    return TestClient(app_main.app)


def _make_user(factory, name="u", scopes=("admin",)):
    with factory() as session:
        user = persistence_repo.create_user(session, name)
        record, plaintext = persistence_repo.create_api_key(
            session, user.id, name=f"{name}-key", scopes=list(scopes)
        )
        session.commit()
        return user.id, record.id, plaintext


def _auth(plaintext: str) -> dict:
    return {"X-API-Key": plaintext}


def _make_project(client, plaintext, name="p"):
    r = client.post("/projects", json={"name": name}, headers=_auth(plaintext))
    assert r.status_code == 200, r.text
    return r.json()["id"]


def _seed_analysis(factory, user_id, project_id, findings):
    with factory() as session:
        analysis = persistence_repo.record_repo_analysis(
            session,
            user_id=user_id,
            project_id=project_id,
            repository_url="https://github.com/o/r",
            findings=findings,
            risk_score=7.5,
            summary={},
        )
        session.commit()
        return analysis.id


def test_migration_v2_creates_finding_statuses(factory):
    with factory() as session:
        row = persistence_repo.set_finding_status(
            session,
            user_id=None,
            project_id=None,
            fingerprint="abc123",
            status="acknowledged",
            note="looking",
        )
        session.commit()
        assert row.status == "acknowledged"
        rows = persistence_repo.get_finding_statuses(
            session, user_id=None, project_id=None
        )
        assert len(rows) == 1 and rows[0].fingerprint == "abc123"


def test_migration_v1_upgrades_to_v2(tmp_path):
    """A v1 database (no finding_statuses) upgrades cleanly to v2."""
    from sqlalchemy import create_engine, inspect

    url = f"sqlite:///{tmp_path}/v1.db"
    engine = create_engine(url)
    # Simulate v1: stamp version 1 without creating finding_statuses.
    persistence_db.MIGRATIONS[1](engine)
    # Remove the finding_statuses table to simulate a real v1 DB, then
    # re-stamp as version 1.
    with engine.begin() as conn:
        conn.exec_driver_sql("DROP TABLE IF EXISTS finding_statuses")
    persistence_db._stamp_version(engine, 1)
    assert "finding_statuses" not in inspect(engine).get_table_names()
    version = persistence_db.upgrade_database(engine)
    assert version == 2
    assert "finding_statuses" in inspect(engine).get_table_names()


def test_lifecycle_api_roundtrip(client, factory, app_settings):
    _, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    fp = "deadbeef" * 4

    r = client.post(
        f"/projects/{project_id}/findings/status",
        json={"fingerprint": fp, "status": "acknowledged", "note": "triaging"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 200, r.text
    assert r.json()["status"] == "acknowledged"

    r = client.get(
        f"/projects/{project_id}/findings/status", headers=_auth(plaintext)
    )
    assert r.status_code == 200
    rows = r.json()
    assert len(rows) == 1 and rows[0]["fingerprint"] == fp

    # Update to fixed.
    r = client.post(
        f"/projects/{project_id}/findings/status",
        json={"fingerprint": fp, "status": "fixed"},
        headers=_auth(plaintext),
    )
    assert r.json()["status"] == "fixed"
    r = client.get(
        f"/projects/{project_id}/findings/status", headers=_auth(plaintext)
    )
    assert len(r.json()) == 1  # upsert, not duplicate


def test_lifecycle_rejects_bad_status(client, factory, app_settings):
    _, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    r = client.post(
        f"/projects/{project_id}/findings/status",
        json={"fingerprint": "x", "status": "new"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 422


def test_lifecycle_cross_user_404(client, factory, app_settings):
    _, _, alice = _make_user(factory, name="alice")
    _, _, bob = _make_user(factory, name="bob")
    project_id = _make_project(client, alice, name="alice-proj")
    r = client.get(
        f"/projects/{project_id}/findings/status", headers=_auth(bob)
    )
    assert r.status_code == 404
    r = client.post(
        f"/projects/{project_id}/findings/status",
        json={"fingerprint": "x", "status": "fixed"},
        headers=_auth(bob),
    )
    assert r.status_code == 404


def _fake_result(findings):
    """Minimal AnalysisResult stand-in for retest (no network)."""
    ns_findings = []
    for f in findings:
        d = dict(f)
        ns_findings.append(SimpleNamespace(model_dump=lambda mode="json", _d=d: dict(_d)))
    risk_d = {"score": 5.0, "level": "medium"}
    summary_d = {"findings_total": len(findings)}
    return SimpleNamespace(
        findings=ns_findings,
        risk=SimpleNamespace(score=5.0, model_dump=lambda mode="json": dict(risk_d)),
        summary=SimpleNamespace(model_dump=lambda mode="json": dict(summary_d)),
        agents=None,
        ai_budget=None,
    )


def test_retest_repo_diff_and_lifecycle(client, factory, app_settings, monkeypatch):
    user_id, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    old = [_finding(rule="R-OLD"), _finding(rule="R-KEEP")]
    analysis_id = _seed_analysis(factory, user_id, project_id, old)

    # Mark R-OLD fixed and R-KEEP acknowledged before retest.
    fp_old = retest_lib.finding_fingerprint(_finding(rule="R-OLD"))
    fp_keep = retest_lib.finding_fingerprint(_finding(rule="R-KEEP"))
    with factory() as session:
        persistence_repo.set_finding_status(
            session, user_id=user_id, project_id=project_id,
            fingerprint=fp_old, status="fixed",
        )
        persistence_repo.set_finding_status(
            session, user_id=user_id, project_id=project_id,
            fingerprint=fp_keep, status="acknowledged",
        )
        session.commit()

    new = [_finding(rule="R-KEEP"), _finding(rule="R-NEW")]
    monkeypatch.setattr(
        app_main, "_run_repo_analysis_sync", lambda url: _fake_result(new)
    )
    r = client.post(
        f"/projects/{project_id}/retest",
        json={"kind": "repo_analysis"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["previous_run_id"] == analysis_id
    assert body["new_run_id"] != analysis_id
    assert [f["rule_id"] for f in body["new"]] == ["R-NEW"]
    assert [f["rule_id"] for f in body["persisting"]] == ["R-KEEP"]
    assert [f["rule_id"] for f in body["resolved"]] == ["R-OLD"]
    # Lifecycle annotations: fixed+resolved=verified, acknowledged+persisting stays.
    resolved = {f["rule_id"]: f for f in body["resolved"]}
    persisting = {f["rule_id"]: f for f in body["persisting"]}
    assert resolved["R-OLD"]["lifecycle"] == "verified"
    assert persisting["R-KEEP"]["lifecycle"] == "acknowledged"


def test_retest_repo_regressed(client, factory, app_settings, monkeypatch):
    user_id, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    old = [_finding(rule="R-STILL")]
    _seed_analysis(factory, user_id, project_id, old)
    fp = retest_lib.finding_fingerprint(_finding(rule="R-STILL"))
    with factory() as session:
        persistence_repo.set_finding_status(
            session, user_id=user_id, project_id=project_id,
            fingerprint=fp, status="fixed",
        )
        session.commit()
    monkeypatch.setattr(
        app_main, "_run_repo_analysis_sync", lambda url: _fake_result([_finding(rule="R-STILL")])
    )
    r = client.post(
        f"/projects/{project_id}/retest",
        json={"kind": "repo_analysis"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 200, r.text
    persisting = {f["rule_id"]: f for f in r.json()["persisting"]}
    assert persisting["R-STILL"]["lifecycle"] == "regressed"


def test_retest_no_previous_run_404(client, factory, app_settings):
    _, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    r = client.post(
        f"/projects/{project_id}/retest",
        json={"kind": "repo_analysis"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 404


def test_retest_website_requires_fresh_auth(client, factory, app_settings):
    user_id, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    with factory() as session:
        persistence_repo.record_website_scan(
            session, user_id=user_id, project_id=project_id,
            target_url="https://example.test", findings=[],
            urls_scanned=1, truncated=False, summary={},
        )
        session.commit()
    r = client.post(
        f"/projects/{project_id}/retest",
        json={"kind": "website_scan"},
        headers=_auth(plaintext),
    )
    assert r.status_code == 403


def test_report_endpoints(client, factory, app_settings):
    user_id, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    findings = [_finding(rule="R1", evidence="eval(x) <b>")]
    analysis_id = _seed_analysis(factory, user_id, project_id, findings)

    r = client.get(f"/analyses/{analysis_id}/report", headers=_auth(plaintext))
    assert r.status_code == 200
    assert "R1" in r.text and "eval(x)" in r.text

    r = client.get(
        f"/analyses/{analysis_id}/report?format=html", headers=_auth(plaintext)
    )
    assert r.status_code == 200
    assert "<html" in r.text
    # Evidence is escaped, not raw HTML.
    assert "eval(x) &lt;b&gt;" in r.text

    r = client.get("/analyses/does-not-exist/report", headers=_auth(plaintext))
    assert r.status_code == 404


def test_website_report_endpoints(client, factory, app_settings):
    user_id, _, plaintext = _make_user(factory)
    project_id = _make_project(client, plaintext)
    with factory() as session:
        scan = persistence_repo.record_website_scan(
            session, user_id=user_id, project_id=project_id,
            target_url="https://example.test",
            findings=[{**_finding(rule="LIVE-001"), "url": "https://example.test/"}],
            urls_scanned=1, truncated=False, summary={"disclaimer": "d"},
        )
        session.commit()
        scan_id = scan.id
    r = client.get(f"/website-scans/{scan_id}/report", headers=_auth(plaintext))
    assert r.status_code == 200 and "LIVE-001" in r.text
    r = client.get(
        f"/website-scans/{scan_id}/report?format=html", headers=_auth(plaintext)
    )
    assert r.status_code == 200 and "<html" in r.text
