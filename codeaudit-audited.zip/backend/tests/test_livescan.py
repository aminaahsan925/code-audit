"""Tests for Phase 6: authorized live website scanning (hermetic).

No test touches the public internet. The SSRF guard matrix monkeypatches
``socket.getaddrinfo``; end-to-end scanning runs against a threaded
fixture HTTP server on 127.0.0.1 (allowed only via explicit
``allow_localhost=True`` in the test config — the production default
refuses loopback).
"""

from __future__ import annotations

import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

import httpx
import pytest
from fastapi.testclient import TestClient

from models.schemas import Confidence, FindingSource

from services.livescan import checks
from services.livescan.auth import parse_scan_tokens, verify_scan_authorization
from services.livescan.crawl import extract_links
from services.livescan.errors import ScanScopeError
from services.livescan.errors import (
    ScanAuthorizationError,
    ScanBudgetError,
    ScanScopeError,
    SSRFBlockedError,
)
from services.livescan.http import GuardedHTTPClient, GuardedResponse, ScanLimits
from services.livescan.scanner import ScanConfig, WebsiteScanner
from services.livescan.scope import in_scope, normalize_scope
from services.livescan.ssrf import validate_url


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_getaddrinfo(ip: str):
    def fake(host, port, *args, **kwargs):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port))]

    return fake


def _fake_getaddrinfo_fail(host, port, *args, **kwargs):
    raise socket.gaierror("mocked DNS failure")


def _guarded_response(
    url: str = "http://example.com/",
    status: int = 200,
    headers: dict | None = None,
    body: bytes = b"<html></html>",
) -> GuardedResponse:
    return GuardedResponse(
        url=url,
        status_code=status,
        headers=httpx.Headers(headers or {}),
        content=body,
        elapsed_ms=1,
    )


# ---------------------------------------------------------------------------
# SSRF guard matrix
# ---------------------------------------------------------------------------


class TestSSRFGuard:
    @pytest.mark.parametrize(
        "url",
        [
            "http://10.0.0.1/",
            "http://10.255.255.255/",
            "http://192.168.1.1/",
            "http://172.16.0.1/",
            "http://172.31.255.255/",
            "http://169.254.169.254/",  # cloud metadata
            "http://169.254.10.20/",
            "http://224.0.0.1/",  # multicast
            "http://0.0.0.0/",
            "http://[::1]/",
            "http://[::ffff:127.0.0.1]/",
        ],
    )
    def test_non_routable_ips_blocked(self, url, monkeypatch):
        monkeypatch.setattr(
            socket, "getaddrinfo", _fake_getaddrinfo(urlsplit(url).hostname or "")
        )
        # The fake above resolves the literal host to itself; for bracketed
        # IPv6 the hostname keeps brackets — normalize for the fake.
        with pytest.raises(SSRFBlockedError):
            validate_url(url)

    def test_loopback_blocked_by_default(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://127.0.0.1/")

    def test_loopback_allowed_with_explicit_opt_in(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        guarded = validate_url("http://127.0.0.1:8080/", allow_localhost=True)
        assert guarded.host == "127.0.0.1"
        assert guarded.port == 8080

    def test_localhost_name_blocked_by_default(self, monkeypatch):
        # "localhost" typically resolves to 127.0.0.1 — the guard checks
        # the resolved address, not the name.
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://localhost/")

    def test_decimal_ip_spelling_blocked(self, monkeypatch):
        # http://2130706433/ == http://127.0.0.1/ — resolution defeats it.
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://2130706433/")

    def test_hex_ip_spelling_blocked(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("127.0.0.1"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://0x7f.0.0.1/")

    def test_dns_resolving_to_private_blocked(self, monkeypatch):
        # An internal hostname resolving to RFC1918 space is refused:
        # resolve-then-check, not string matching.
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("10.9.9.9"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://internal.corp.example/")

    def test_dns_failure_is_fail_closed(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo_fail)
        with pytest.raises(SSRFBlockedError):
            validate_url("http://nonexistent.invalid/")

    @pytest.mark.parametrize(
        "url",
        [
            "file:///etc/passwd",
            "ftp://example.com/file",
            "gopher://example.com/",
            "dict://example.com/",
        ],
    )
    def test_non_http_schemes_blocked(self, url):
        with pytest.raises(SSRFBlockedError):
            validate_url(url)

    def test_userinfo_blocked(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        with pytest.raises(SSRFBlockedError):
            validate_url("http://user:pass@example.com/")

    def test_public_ip_allowed(self, monkeypatch):
        monkeypatch.setattr(socket, "getaddrinfo", _fake_getaddrinfo("93.184.216.34"))
        guarded = validate_url("https://example.com:8443/path")
        assert guarded.scheme == "https"
        assert guarded.host == "example.com"
        assert guarded.port == 8443
        assert guarded.resolved_ips == ("93.184.216.34",)

    def test_empty_and_garbage_rejected(self):
        with pytest.raises(SSRFBlockedError):
            validate_url("")
        with pytest.raises(SSRFBlockedError):
            validate_url("not a url")


# ---------------------------------------------------------------------------
# Authorization
# ---------------------------------------------------------------------------


class TestScanTokens:
    def test_parse_scan_tokens(self):
        tokens = parse_scan_tokens("example.com:tok123, shop.example.com:tok456 ")
        assert tokens == {"example.com": "tok123", "shop.example.com": "tok456"}

    def test_parse_ignores_malformed_entries(self):
        assert parse_scan_tokens("example.com:tok,no-colon-here,:empty-host") == {
            "example.com": "tok"
        }
        assert parse_scan_tokens("") == {}

    def test_parse_lowercases_hosts(self):
        assert parse_scan_tokens("Example.COM:tok") == {"example.com": "tok"}


class TestAuthorization:
    TOKENS = {"example.com": "s3cret-token"}

    def test_valid_authorization(self):
        host = verify_scan_authorization(
            "https://example.com/page", "s3cret-token", True, self.TOKENS
        )
        assert host == "example.com"

    def test_missing_explicit_confirmation_rejected(self):
        with pytest.raises(ScanAuthorizationError):
            verify_scan_authorization(
                "https://example.com/", "s3cret-token", False, self.TOKENS
            )

    def test_wrong_token_rejected(self):
        with pytest.raises(ScanAuthorizationError):
            verify_scan_authorization(
                "https://example.com/", "wrong-token", True, self.TOKENS
            )

    def test_unknown_host_rejected(self):
        with pytest.raises(ScanAuthorizationError):
            verify_scan_authorization(
                "https://other.com/", "s3cret-token", True, self.TOKENS
            )

    def test_no_tokens_configured_rejects_everything(self):
        with pytest.raises(ScanAuthorizationError):
            verify_scan_authorization("https://example.com/", "anything", True, {})

    def test_empty_token_rejected_for_unconfigured_host(self):
        """Regression: compare_digest("", "") must never authorize."""
        for token in ("", None):
            with pytest.raises(ScanAuthorizationError):
                verify_scan_authorization(
                    "https://other.com/", token, True, self.TOKENS
                )

    def test_empty_token_rejected_when_no_tokens_configured(self):
        for token in ("", None):
            with pytest.raises(ScanAuthorizationError):
                verify_scan_authorization(
                    "https://example.com/", token, True, {}
                )

    def test_empty_token_rejected_for_configured_host(self):
        with pytest.raises(ScanAuthorizationError):
            verify_scan_authorization(
                "https://example.com/", "", True, self.TOKENS
            )

    def test_error_does_not_leak_token(self):
        try:
            verify_scan_authorization(
                "https://example.com/", "wrong", True, self.TOKENS
            )
        except ScanAuthorizationError as exc:
            assert "s3cret-token" not in str(exc)
        else:
            pytest.fail("expected ScanAuthorizationError")


# ---------------------------------------------------------------------------
# Scope
# ---------------------------------------------------------------------------


class TestScope:
    def test_exact_host_in_scope(self):
        scope = normalize_scope("https://example.com/blog/")
        assert in_scope(scope, "https://example.com/blog/post-1")
        assert not in_scope(scope, "https://example.com/other")

    def test_default_prefix_is_target_path(self):
        scope = normalize_scope("https://example.com/")
        assert in_scope(scope, "https://example.com/anything")

    def test_subdomain_opt_in(self):
        scope = normalize_scope("https://example.com/", include_subdomains=True)
        assert in_scope(scope, "https://shop.example.com/")
        assert not in_scope(scope, "https://example.com.evil.com/")

    def test_subdomain_opt_out(self):
        scope = normalize_scope("https://example.com/")
        assert not in_scope(scope, "https://shop.example.com/")

    def test_scheme_mismatch_out_of_scope(self):
        scope = normalize_scope("https://example.com/")
        assert not in_scope(scope, "http://example.com/")

    def test_bad_prefix_rejected(self):
        with pytest.raises(ScanScopeError):
            normalize_scope("https://example.com/", path_prefix="no-slash")

    def test_prefix_requires_segment_boundary(self):
        scope = normalize_scope("https://example.com/blog")
        assert in_scope(scope, "https://example.com/blog")
        assert in_scope(scope, "https://example.com/blog/post")
        assert not in_scope(scope, "https://example.com/blogroll")
        scope2 = normalize_scope("https://example.com/blog/")
        assert in_scope(scope2, "https://example.com/blog/post")
        assert not in_scope(scope2, "https://example.com/blogroll")


# ---------------------------------------------------------------------------
# Link extraction
# ---------------------------------------------------------------------------


class TestExtractLinks:
    def test_extracts_and_resolves(self):
        html = (
            '<a href="/page2">x</a><a href="https://example.com/abs">y</a>'
            '<a href="#frag">z</a><a href="mailto:a@b.c">m</a>'
            '<a href="javascript:void(0)">j</a>'
        )
        links = extract_links(html, "https://example.com/start")
        assert links == ["https://example.com/page2", "https://example.com/abs"]

    def test_malformed_html_does_not_raise(self):
        assert extract_links("<a href='/x'><div><a", "https://example.com/") == [
            "https://example.com/x"
        ]


# ---------------------------------------------------------------------------
# Passive checks (unit)
# ---------------------------------------------------------------------------


class TestPassiveChecks:
    def test_missing_security_headers(self):
        resp = _guarded_response("https://example.com/")
        findings = checks.check_security_headers("https://example.com/", resp)
        ids = {f.rule_id for f in findings}
        assert {"LIVE-001", "LIVE-002", "LIVE-003", "LIVE-004", "LIVE-005"} <= ids
        assert all(f.source == FindingSource.LIVE_SCAN for f in findings)
        assert all(f.cwe_ids for f in findings)

    def test_hsts_not_checked_on_plain_http(self):
        resp = _guarded_response("http://example.com/")
        findings = checks.check_security_headers("http://example.com/", resp)
        assert "LIVE-002" not in {f.rule_id for f in findings}

    def test_present_headers_are_silent(self):
        resp = _guarded_response(
            "https://example.com/",
            headers={
                "Content-Security-Policy": "default-src 'self'",
                "Strict-Transport-Security": "max-age=31536000",
                "X-Frame-Options": "DENY",
                "X-Content-Type-Options": "nosniff",
                "Referrer-Policy": "strict-origin-when-cross-origin",
            },
        )
        assert checks.check_security_headers("https://example.com/", resp) == []

    def test_http_transport_finding(self):
        findings = checks.check_transport("http://example.com/")
        assert len(findings) == 1
        assert findings[0].rule_id == "LIVE-007"
        assert checks.check_transport("https://example.com/") == []

    def test_cookie_flags_redact_values(self):
        resp = _guarded_response(
            "https://example.com/",
            headers=[
                ("Set-Cookie", "sessionid=supersecret123; Path=/"),
                ("Set-Cookie", "prefs=dark; Path=/; Secure; HttpOnly; SameSite=Lax"),
            ],
        )
        findings = checks.check_cookie_flags("https://example.com/", resp)
        ids = {f.rule_id for f in findings}
        assert "LIVE-006" in ids
        for f in findings:
            assert "supersecret123" not in f.evidence
            assert "sessionid" in f.evidence  # names are fine, values are not

    def test_secure_cookies_are_silent(self):
        resp = _guarded_response(
            "https://example.com/",
            headers=[
                ("Set-Cookie", "a=1; Secure; HttpOnly; SameSite=Lax"),
            ],
        )
        assert checks.check_cookie_flags("https://example.com/", resp) == []

    def test_server_banner_disclosure(self):
        resp = _guarded_response(
            "https://example.com/", headers={"Server": "nginx/1.24.0"}
        )
        findings = checks.check_server_disclosure("https://example.com/", resp)
        assert len(findings) == 1
        assert findings[0].rule_id == "LIVE-008"

    def test_plain_server_banner_silent(self):
        resp = _guarded_response("https://example.com/", headers={"Server": "nginx"})
        assert checks.check_server_disclosure("https://example.com/", resp) == []


class TestTLSCertEvaluation:
    def _cert(self, **overrides):
        cert = {
            "subject": ((("commonName", "example.com"),),),
            "issuer": ((("commonName", "Test CA"),),),
            "notBefore": "Jan  1 00:00:00 2024 GMT",
            "notAfter": "Jan  1 00:00:00 2030 GMT",
            "subjectAltName": (("DNS", "example.com"),),
        }
        cert.update(overrides)
        return cert

    def test_valid_cert_silent(self):
        assert checks.evaluate_tls_certificate(self._cert(), "example.com") == []

    def test_expired_cert_flagged(self):
        cert = self._cert(notAfter="Jan  1 00:00:00 2020 GMT")
        findings = checks.evaluate_tls_certificate(cert, "example.com")
        assert any(f.rule_id == "LIVE-010" and "expired" in f.title for f in findings)

    def test_hostname_mismatch_flagged(self):
        findings = checks.evaluate_tls_certificate(self._cert(), "other.com")
        assert any(f.rule_id == "LIVE-010" and "mismatch" in f.title for f in findings)

    def test_missing_cert_flagged(self):
        findings = checks.evaluate_tls_certificate({}, "example.com")
        assert any(f.rule_id == "LIVE-010" for f in findings)


# ---------------------------------------------------------------------------
# Fixture HTTP server (hermetic end-to-end)
# ---------------------------------------------------------------------------


class _FixtureHandler(BaseHTTPRequestHandler):
    """Deliberately misconfigured site for scanner tests."""

    requested_paths: list[str] = []

    def log_message(self, *args):  # silence stderr noise
        pass

    def _record(self):
        type(self).requested_paths.append(urlsplit(self.path).path)

    def do_GET(self):
        self._record()
        parts = urlsplit(self.path)
        path = parts.path
        query = parse_qs(parts.query)

        if path == "/":
            body = (
                b"<html><body>"
                b'<a href="/page2">page2</a>'
                b'<a href="/search?q=hello">search</a>'
                b'<a href="/item?id=1">item</a>'
                b'<a href="http://external.invalid/">external</a>'
                b"</body></html>"
            )
            self._send(200, body, {"Server": "TestServer/1.2.3"})
        elif path == "/page2":
            self._send(
                200,
                b"<html><body>page2</body></html>",
                {"Set-Cookie": "sessionid=abc123; Path=/"},
            )
        elif path == "/search":
            q = query.get("q", [""])[0]
            # Reflect the query parameter unencoded (XSS probe target).
            # Also reflect the probe canary when present.
            probe = query.get("codeaudit_probe", [""])[0]
            body = f"<html><body>results for {q} {probe}</body></html>".encode()
            self._send(200, body)
        elif path == "/item":
            item_id = query.get("id", [""])[0]
            if "'" in item_id:
                self._send(
                    200, b"Database error: You have an error in your SQL syntax near '''"
                )
            else:
                self._send(200, b"<html><body>item</body></html>")
        elif path == "/.git/HEAD":
            self._send(200, b"ref: refs/heads/main\n")
        elif path == "/redirect-evil":
            self._send(302, b"", {"Location": "http://169.254.169.254/"})
        elif path == "/redirect-out":
            self._send(302, b"", {"Location": "http://external.invalid/"})
        else:
            self._send(404, b"not found")

    def _send(self, status, body, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra_headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)


@pytest.fixture()
def fixture_server():
    _FixtureHandler.requested_paths = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), _FixtureHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    thread.join(timeout=5)


def _test_config(base_url: str, **overrides) -> ScanConfig:
    limits = ScanLimits(
        max_requests=overrides.pop("max_requests", 100),
        request_delay_seconds=0.01,
        timeout_seconds=5.0,
        max_redirects=5,
        max_response_bytes=1_000_000,
        max_scan_seconds=60.0,
    )
    return ScanConfig(
        target_url=base_url + "/",
        authorization_token="test-token",
        i_authorize_this_scan=True,
        configured_tokens={"127.0.0.1": "test-token"},
        allow_localhost=True,
        limits=limits,
        **overrides,
    )


class TestScannerEndToEnd:
    def test_full_scan_finds_expected_issues(self, fixture_server):
        result = WebsiteScanner(_test_config(fixture_server)).run()
        by_rule: dict[str, list] = {}
        for f in result.findings:
            by_rule.setdefault(f.rule_id, []).append(f)

        for expected in (
            "LIVE-001",  # no CSP
            "LIVE-003",  # no X-Frame-Options
            "LIVE-004",  # no X-Content-Type-Options
            "LIVE-005",  # no Referrer-Policy
            "LIVE-006",  # cookie without HttpOnly
            "LIVE-007",  # plain HTTP
            "LIVE-008",  # server banner version
            "LIVE-009",  # /.git/HEAD exposed
            "LIVE-020",  # reflected canary
            "LIVE-021",  # SQL error signature
        ):
            assert expected in by_rule, f"missing {expected}; got {sorted(by_rule)}"

        assert all(f.source == FindingSource.LIVE_SCAN for f in result.findings)
        assert all(f.rule_id and f.cwe_ids for f in result.findings)
        assert all(f.url for f in result.findings)

    def test_active_findings_capped_and_marked(self, fixture_server):
        result = WebsiteScanner(_test_config(fixture_server)).run()
        active = [
            f for f in result.findings if f.rule_id in ("LIVE-020", "LIVE-021")
        ]
        assert active, "expected active-probe findings"
        for f in active:
            assert f.confidence in (Confidence.MEDIUM, Confidence.LOW)
            assert "manual verification" in f.description.lower()

    def test_out_of_scope_links_never_fetched(self, fixture_server):
        _FixtureHandler.requested_paths = []
        WebsiteScanner(_test_config(fixture_server)).run()
        assert "/external" not in " ".join(_FixtureHandler.requested_paths)
        # external.invalid never resolved/fetched by the test process either:
        # it only appears in the skipped list.
        result = WebsiteScanner(_test_config(fixture_server)).run()
        assert any("external.invalid" in u for u in result.urls_skipped_out_of_scope)

    def test_no_csp_fp_when_header_present(self, fixture_server):
        # The fixture never sends CSP; sanity check the negative path via
        # the unit tests instead — this asserts scan determinism instead.
        r1 = WebsiteScanner(_test_config(fixture_server)).run()
        r2 = WebsiteScanner(_test_config(fixture_server)).run()
        assert sorted(f.rule_id for f in r1.findings) == sorted(
            f.rule_id for f in r2.findings
        )

    def test_disclaimer_present(self, fixture_server):
        result = WebsiteScanner(_test_config(fixture_server)).run()
        assert "NOT proof of security" in result.disclaimer
        assert str(len(result.urls_scanned)) in result.disclaimer

    def test_request_budget_respected(self, fixture_server):
        result = WebsiteScanner(_test_config(fixture_server, max_requests=5)).run()
        assert result.requests_made <= 5
        assert result.truncated is True

    def test_unauthorized_scan_raises_before_network(self, fixture_server):
        config = _test_config(fixture_server)
        config.authorization_token = "wrong"
        with pytest.raises(ScanAuthorizationError):
            WebsiteScanner(config).run()

    def test_redirect_to_internal_blocked(self, fixture_server):
        client = GuardedHTTPClient(
            ScanLimits(request_delay_seconds=0), allow_localhost=True
        )
        try:
            with pytest.raises(SSRFBlockedError):
                client.get(fixture_server + "/redirect-evil")
        finally:
            client.close()

    def test_redirect_out_of_scope_blocked(self, fixture_server):
        scope = normalize_scope(fixture_server + "/")
        client = GuardedHTTPClient(
            ScanLimits(request_delay_seconds=0),
            allow_localhost=True,
            scope_check=lambda url: in_scope(scope, url),
        )
        try:
            with pytest.raises(ScanScopeError):
                client.get(fixture_server + "/redirect-out")
        finally:
            client.close()


# ---------------------------------------------------------------------------
# API endpoint
# ---------------------------------------------------------------------------


def _scan_settings(**overrides):
    from types import SimpleNamespace

    base = dict(
        scan_tokens="",
        scan_allow_localhost=False,
        scan_max_pages=50,
        scan_max_requests=100,
        scan_request_delay_ms=10,
        scan_timeout_seconds=5.0,
        scan_max_redirects=5,
        scan_max_response_bytes=1_000_000,
        scan_max_seconds=60,
        # Phase 7: the auth layer reads these; the double mirrors Settings.
        require_auth=False,
        database_url="sqlite:///:memory:",
        persistence_enabled=False,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def _scan_body(target_url: str, **overrides):
    body = {
        "target_url": target_url,
        "authorization_token": "test-token",
        "i_authorize_this_scan": True,
    }
    body.update(overrides)
    return body


class TestScanAPI:
    def test_rejects_when_no_tokens_configured(self, client: TestClient, monkeypatch):
        import app.main as app_main

        monkeypatch.setattr(app_main, "settings", _scan_settings(scan_tokens=""))
        resp = client.post(
            "/scan/website", json=_scan_body("http://127.0.0.1:9/")
        )
        assert resp.status_code == 403
        assert resp.json()["error"]["code"] == "SCAN_UNAUTHORIZED"

    def test_rejects_missing_confirmation(self, client: TestClient, monkeypatch):
        import app.main as app_main

        monkeypatch.setattr(
            app_main, "settings", _scan_settings(scan_tokens="127.0.0.1:test-token")
        )
        resp = client.post(
            "/scan/website",
            json=_scan_body("http://127.0.0.1:9/", i_authorize_this_scan=False),
        )
        assert resp.status_code == 403

    def test_rejects_wrong_token(self, client: TestClient, monkeypatch):
        import app.main as app_main

        monkeypatch.setattr(
            app_main, "settings", _scan_settings(scan_tokens="127.0.0.1:test-token")
        )
        resp = client.post(
            "/scan/website",
            json=_scan_body("http://127.0.0.1:9/", authorization_token="nope"),
        )
        assert resp.status_code == 403

    def test_ssrf_blocked_before_connect(self, client: TestClient, monkeypatch):
        import app.main as app_main

        # 10.0.0.1 is unroutable; the guard refuses before any socket opens.
        monkeypatch.setattr(
            app_main, "settings", _scan_settings(scan_tokens="10.0.0.1:test-token")
        )
        resp = client.post("/scan/website", json=_scan_body("http://10.0.0.1/"))
        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "SCAN_SSRF_BLOCKED"

    def test_loopback_refused_by_default(self, client: TestClient, monkeypatch):
        import app.main as app_main

        monkeypatch.setattr(
            app_main,
            "settings",
            _scan_settings(
                scan_tokens="127.0.0.1:test-token", scan_allow_localhost=False
            ),
        )
        resp = client.post("/scan/website", json=_scan_body("http://127.0.0.1:9/"))
        assert resp.status_code == 400
        assert resp.json()["error"]["code"] == "SCAN_SSRF_BLOCKED"

    def test_authorized_localhost_scan_runs(
        self, client: TestClient, monkeypatch, fixture_server
    ):
        import app.main as app_main

        monkeypatch.setattr(
            app_main,
            "settings",
            _scan_settings(
                scan_tokens="127.0.0.1:test-token", scan_allow_localhost=True
            ),
        )
        resp = client.post("/scan/website", json=_scan_body(fixture_server + "/"))
        assert resp.status_code == 200, resp.text[:500]
        body = resp.json()
        assert body["target_url"] == fixture_server + "/"
        assert body["findings"], "expected findings from the fixture site"
        assert all(f["source"] == "live-scan" for f in body["findings"])
        assert "NOT proof of security" in body["disclaimer"]
        # Credentials must not be echoed anywhere in the response.
        assert "test-token" not in resp.text
