"""Tests for the rule registry (Phase 3, §7.1/§7.2).

Guards: every detector the analyzers can emit has a registry entry with a
stable rule ID and well-formed CWE IDs; IDs are unique and follow the
naming convention; unknown producers resolve to None (no invented mappings).
"""

from __future__ import annotations

import re
from pathlib import Path

from services.languages.registry import get_analyzer
from services.languages.rule_registry import all_rules, get_rule, get_rule_by_id

RULE_ID_RE = re.compile(r"^(PY|JS)-(SEC|QLT)-\d{3}$|^(DEP|SECRET|CFG|LIVE)-\d{3}$")
CWE_RE = re.compile(r"^CWE-\d+$")

BENCH = Path(__file__).parent / "benchmarks"


def test_every_registered_rule_is_well_formed():
    seen_ids: set[str] = set()
    seen_detectors: set[str] = set()
    for rule in all_rules():
        assert RULE_ID_RE.match(rule.rule_id), f"bad rule id: {rule.rule_id}"
        assert rule.rule_id not in seen_ids, f"duplicate rule id: {rule.rule_id}"
        assert rule.detector not in seen_detectors, f"duplicate detector: {rule.detector}"
        seen_ids.add(rule.rule_id)
        seen_detectors.add(rule.detector)
        for cwe in rule.cwe_ids:
            assert CWE_RE.match(cwe), f"bad CWE id: {cwe}"
        assert rule.severity_rationale and rule.confidence_rules
        assert rule.known_limitations and rule.remediation_reference
        assert rule.languages, f"{rule.rule_id} has no languages"
    assert len(seen_ids) == 51  # 10 Python + 9 JS + 20 supply-chain + 12 live-scan detectors


def test_quality_rules_carry_no_cwe():
    for rule in all_rules():
        if "-QLT-" in rule.rule_id:
            assert rule.cwe_ids == (), f"{rule.rule_id} should not force a CWE mapping"


def test_all_python_detectors_resolve():
    # Resolve via actual findings over the benchmark corpus: every detector
    # name the analyzer can emit must have a registry entry.
    analyzer = get_analyzer("python")
    emitted: set[str] = set()
    for path in (BENCH / "python").glob("*.py"):
        for f in analyzer.analyze_file(path.name, path.read_text(encoding="utf-8")):
            emitted.add(f.detector)
    assert emitted, "no detectors fired on the benchmark corpus"
    for detector in emitted:
        rule = get_rule(detector)
        assert rule is not None, f"no registry entry for detector {detector!r}"
        assert rule.languages == ("python",) or "python" in rule.languages


def test_all_js_detectors_resolve():
    analyzer = get_analyzer("javascript")
    emitted: set[str] = set()
    for path in list((BENCH / "javascript").glob("*.js")) + list(
        (BENCH / "javascript").glob("*.jsx")
    ):
        for f in analyzer.analyze_file(path.name, path.read_text(encoding="utf-8")):
            emitted.add(f.detector)
    assert emitted, "no detectors fired on the JS benchmark corpus"
    for detector in emitted:
        rule = get_rule(detector)
        assert rule is not None, f"no registry entry for detector {detector!r}"
        assert "javascript" in rule.languages


def test_unknown_detector_resolves_to_none():
    assert get_rule("nemotron_security_v1") is None
    assert get_rule("definitely_not_a_detector") is None
    assert get_rule_by_id("PY-SEC-999") is None


def test_findings_carry_registry_attribution():
    analyzer = get_analyzer("python")
    findings = analyzer.analyze_file(
        "x.py", 'api_key = "<redacted>"\n'
    )
    assert findings, "expected a hardcoded_secret finding"
    f = findings[0]
    assert f.rule_id == "PY-SEC-001"
    assert f.cwe_ids == ["CWE-798"]
    # AI-discovered findings must not invent a mapping (checked at construction).
    from models.schemas import (
        Category,
        Confidence,
        Finding,
        FindingSource,
        Severity,
    )

    ai = Finding(
        id="ai:x:1:deadbeef",
        category=Category.SECURITY,
        severity=Severity.HIGH,
        title="t",
        description="d",
        file="x.py",
        line=1,
        evidence="e",
        confidence=Confidence.MEDIUM,
        source=FindingSource.AI,
        detector="nemotron_security_v1",
    )
    assert ai.rule_id is None
    assert ai.cwe_ids == []
