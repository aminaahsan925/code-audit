"""Benchmark: os.system with concatenation (vulnerable)."""
import os
def greet(name):
    os.system("echo hello " + name)
