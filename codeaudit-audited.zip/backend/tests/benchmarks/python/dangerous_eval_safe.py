"""Benchmark: literal_eval for data (safe)."""
import ast
def calculate(data):
    return ast.literal_eval(data)
