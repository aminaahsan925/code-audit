"""Benchmark: explicit shell=False (near-miss)."""
import subprocess
def list_dir():
    return subprocess.run("ls", shell=False, capture_output=True)
