"""Benchmark: KNOWN FALSE POSITIVE — .system() on a non-os object still fires.

The detector matches any .system()/.popen() attribute call without import
tracking. Documented in rule PY-SEC-007 known_limitations.
"""
class Mixer:
    def system(self, cmd):
        print("mixing", cmd)
def run(mixer):
    mixer.system("start")
