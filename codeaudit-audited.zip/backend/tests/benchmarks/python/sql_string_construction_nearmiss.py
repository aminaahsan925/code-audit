"""Benchmark: constant-only concatenation is not dynamic (near-miss)."""
def get_all(cursor):
    cursor.execute("SELECT * " + "FROM users")
    return cursor.fetchall()
