"""Benchmark: weak hashes (vulnerable)."""
import hashlib
def digest(data):
    return hashlib.md5(data).hexdigest()
def digest2(data):
    return hashlib.new("sha1", data).hexdigest()
