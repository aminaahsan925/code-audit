"""Benchmark: static template string (near-miss)."""
from flask import render_template_string
def hello():
    return render_template_string("<p>Hello, world!</p>")
