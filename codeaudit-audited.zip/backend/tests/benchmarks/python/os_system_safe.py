"""Benchmark: subprocess argv list (safe)."""
import subprocess
def greet(name):
    subprocess.run(["echo", "hello", name])
