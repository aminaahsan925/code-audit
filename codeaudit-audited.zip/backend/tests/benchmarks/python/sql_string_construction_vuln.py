"""Benchmark: SQL string construction (vulnerable)."""
def get_user(user_id, cursor):
    cursor.execute("SELECT * FROM users WHERE id = " + user_id)
    return cursor.fetchall()
