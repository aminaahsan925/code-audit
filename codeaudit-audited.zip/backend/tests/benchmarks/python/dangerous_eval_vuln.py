"""Benchmark: eval on a parameter (vulnerable)."""
def calculate(expression):
    return eval(expression)
