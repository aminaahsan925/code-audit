"""Benchmark: function length boundary."""
def big():
    x_0 = 0
    x_1 = 1
    x_2 = 2
    x_3 = 3
    x_4 = 4
    x_5 = 5
    x_6 = 6
    x_7 = 7
