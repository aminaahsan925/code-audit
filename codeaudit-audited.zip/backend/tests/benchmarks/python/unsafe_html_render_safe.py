"""Benchmark: constant mark_safe (safe)."""
from markupsafe import mark_safe
BANNER = mark_safe("<b>Welcome</b>")
