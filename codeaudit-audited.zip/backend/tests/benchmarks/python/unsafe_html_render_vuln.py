"""Benchmark: unsafe HTML rendering (vulnerable)."""
from markupsafe import mark_safe
from flask import render_template_string
def greeting(name):
    return mark_safe("<b>Hello, " + name + "</b>")
def page(body):
    return render_template_string("<p>" + body + "</p>")
