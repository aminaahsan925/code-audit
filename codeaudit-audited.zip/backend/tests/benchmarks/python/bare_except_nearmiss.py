"""Benchmark: except Exception is not bare (near-miss)."""
def load(path):
    try:
        return open(path).read()
    except Exception:
        return ""
