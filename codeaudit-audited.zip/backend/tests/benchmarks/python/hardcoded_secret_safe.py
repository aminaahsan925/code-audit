"""Benchmark: secrets from the environment (safe)."""
import os
password = os.environ["DB_PASSWORD"]
api_key = os.getenv("API_KEY")
