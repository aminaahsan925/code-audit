"""Benchmark: placeholders are not secrets (near-miss)."""
api_key = "changeme"
token = "xxx"
username = "admin"
