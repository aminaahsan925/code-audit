"""Benchmark: hardcoded secrets (vulnerable)."""
api_key = "<redacted>"
db_password: str = "s3cr3t-p@ssw0rd!"
