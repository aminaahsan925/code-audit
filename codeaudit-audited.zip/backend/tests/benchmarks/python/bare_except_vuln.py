"""Benchmark: bare except (vulnerable)."""
def load(path):
    try:
        return open(path).read()
    except:
        return ""
