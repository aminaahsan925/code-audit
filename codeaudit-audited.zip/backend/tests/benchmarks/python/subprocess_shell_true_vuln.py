"""Benchmark: subprocess with shell=True (vulnerable)."""
import subprocess
def list_dir(path):
    return subprocess.run("ls " + path, shell=True, capture_output=True)
