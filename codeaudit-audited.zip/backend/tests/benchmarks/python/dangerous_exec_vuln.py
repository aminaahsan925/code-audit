"""Benchmark: exec on a parameter (vulnerable)."""
def run_plugin(code):
    exec(code)
