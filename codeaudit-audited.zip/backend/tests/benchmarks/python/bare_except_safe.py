"""Benchmark: specific except (safe)."""
def load(path):
    try:
        return open(path).read()
    except OSError:
        return ""
