"""Benchmark: argv list, no shell (safe)."""
import subprocess
def list_dir(path):
    return subprocess.run(["ls", path], capture_output=True)
