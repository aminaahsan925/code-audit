"""Benchmark: hashlib.new with sha256 (near-miss)."""
import hashlib
def digest(data):
    return hashlib.new("sha256", data).hexdigest()
