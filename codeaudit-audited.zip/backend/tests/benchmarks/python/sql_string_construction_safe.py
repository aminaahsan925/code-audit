"""Benchmark: parameterized query (safe)."""
def get_user(user_id, cursor):
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    return cursor.fetchall()
