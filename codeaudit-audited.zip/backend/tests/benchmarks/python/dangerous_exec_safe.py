"""Benchmark: dispatch dict instead of exec (safe)."""
def run_plugin(name):
    plugins = {"a": lambda: 1}
    return plugins[name]()
