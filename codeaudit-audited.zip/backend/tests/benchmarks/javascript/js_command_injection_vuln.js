// Benchmark: child_process exec with shell:true (vulnerable).
const cp = require("child_process");
function listDir(dir, cb) {
  cp.exec("ls " + dir, { shell: true }, cb);
}
module.exports = { listDir };
