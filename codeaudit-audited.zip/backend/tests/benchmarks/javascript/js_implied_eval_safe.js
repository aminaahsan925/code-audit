// Benchmark: function reference (safe).
function later() {
  setTimeout(refreshData, 1000);
}
module.exports = { later };
