// Benchmark: Function constructor (vulnerable).
function make(body) {
  return new Function("x", "return " + body);
}
module.exports = { make };
