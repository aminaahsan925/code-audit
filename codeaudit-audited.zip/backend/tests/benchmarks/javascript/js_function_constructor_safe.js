// Benchmark: static class (safe).
class Adder {
  add(a, b) { return a + b; }
}
module.exports = { Adder };
