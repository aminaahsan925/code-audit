// Benchmark: normal children (safe).
function Widget({ text }) {
  return <div>{text}</div>;
}
module.exports = { Widget };
