// Benchmark: db.exec is not child_process (near-miss).
function vacuum(db) {
  db.exec("VACUUM");
}
module.exports = { vacuum };
