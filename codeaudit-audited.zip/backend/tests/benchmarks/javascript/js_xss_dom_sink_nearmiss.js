// Benchmark: literal HTML assignment (near-miss).
function render(el) {
  el.innerHTML = "<b>static</b>";
}
module.exports = { render };
