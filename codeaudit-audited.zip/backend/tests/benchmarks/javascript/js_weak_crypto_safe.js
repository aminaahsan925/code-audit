// Benchmark: sha256 (safe).
const crypto = require("crypto");
function digest(data) {
  return crypto.createHash("sha256").update(data).digest("hex");
}
module.exports = { digest };
