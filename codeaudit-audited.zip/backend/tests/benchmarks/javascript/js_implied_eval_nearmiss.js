// Benchmark: arrow function (near-miss).
function later() {
  setTimeout(() => refreshData(), 1000);
}
module.exports = { later };
