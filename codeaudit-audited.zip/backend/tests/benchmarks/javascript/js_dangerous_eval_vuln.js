// Benchmark: eval on a parameter (vulnerable).
function run(query) {
  return eval(query);
}
module.exports = { run };
