// Benchmark: static template literal (near-miss).
function getAll(db) {
  return db.query(`SELECT * FROM users`);
}
module.exports = { getAll };
