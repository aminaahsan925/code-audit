// Benchmark: JSON.parse for data (safe).
function run(data) {
  return JSON.parse(data);
}
module.exports = { run };
