// Benchmark: DOM XSS sinks (vulnerable).
function render(el, name) {
  el.innerHTML = name;
}
function welcome(userName) {
  document.write("<p>Welcome, " + userName + "</p>");
}
module.exports = { render, welcome };
