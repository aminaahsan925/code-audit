// Benchmark: secret from environment (safe).
const apiKey = process.env.API_KEY;
module.exports = { apiKey };
