// Benchmark: parameterized query (safe).
function getUser(id, db) {
  return db.query("SELECT * FROM users WHERE id = ?", [id]);
}
module.exports = { getUser };
