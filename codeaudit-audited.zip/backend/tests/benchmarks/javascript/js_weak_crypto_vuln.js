// Benchmark: md5 (vulnerable).
const crypto = require("crypto");
function digest(data) {
  return crypto.createHash("md5").update(data).digest("hex");
}
module.exports = { digest };
