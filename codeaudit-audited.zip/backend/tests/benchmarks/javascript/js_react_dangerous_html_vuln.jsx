// Benchmark: dangerouslySetInnerHTML (vulnerable).
function Widget({ html }) {
  return <div dangerouslySetInnerHTML={{ __html: html }} />;
}
module.exports = { Widget };
