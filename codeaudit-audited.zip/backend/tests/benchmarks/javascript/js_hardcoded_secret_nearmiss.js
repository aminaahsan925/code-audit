// Benchmark: placeholder value (near-miss).
const apiKey = "xxx";
module.exports = { apiKey };
