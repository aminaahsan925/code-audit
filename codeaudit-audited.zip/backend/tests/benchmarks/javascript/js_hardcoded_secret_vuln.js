// Benchmark: hardcoded secret (vulnerable).
const apiKey = "<redacted>";
module.exports = { apiKey };
