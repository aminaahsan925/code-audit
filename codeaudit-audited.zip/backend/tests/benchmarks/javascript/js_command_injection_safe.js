// Benchmark: spawn with argv array, no shell (safe).
const cp = require("child_process");
function listDir(dir, cb) {
  cp.spawn("ls", [dir], cb);
}
module.exports = { listDir };
