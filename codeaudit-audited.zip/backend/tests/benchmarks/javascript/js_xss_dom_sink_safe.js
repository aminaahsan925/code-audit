// Benchmark: textContent (safe).
function render(el, name) {
  el.textContent = name;
}
module.exports = { render };
