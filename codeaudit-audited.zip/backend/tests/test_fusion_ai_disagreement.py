"""Phase 3 (§7.5): deterministic findings are never downgraded or suppressed
by AI disagreement.

The fusion agent starts from the validated deterministic anchors and only
attaches AI reasoning/provenance. Even if an AI verdict says "unlikely"
(possibly with a demoted confidence on the enriched copy), the fused
finding keeps its deterministic confidence, severity, and anchor fields.
The disagreement stays visible in ai_reasoning — transparent, not applied.
"""

from __future__ import annotations

from agents.contracts import AgentContext, AgentExecutionMetadata, AgentStatus
from agents.evidence_agent import EvidenceAgentResult
from agents.finding_fusion_agent import FindingFusionAgent
from models.schemas import (
    Category,
    Confidence,
    Finding,
    FindingSource,
    RepositoryMetadata,
    Severity,
    ValidatedFinding,
)
from services.repository_scanner import ScanResult


def _anchor() -> ValidatedFinding:
    return ValidatedFinding(
        id="sql_string_construction:app.py:10",
        category=Category.SECURITY,
        severity=Severity.HIGH,
        title="Potential SQL injection",
        description="Dynamic SQL passed to execute().",
        file="app.py",
        line=10,
        evidence="    cursor.execute('SELECT ' + uid)",
        confidence=Confidence.HIGH,
        source=FindingSource.DETERMINISTIC,
        detector="sql_string_construction",
        rule_id="PY-SEC-002",
        cwe_ids=["CWE-89"],
        taint_trace="taint: 'uid' is a parameter of function 'get' — untrusted input may reach this sink",
    )


def _ctx(finding: ValidatedFinding) -> AgentContext:
    return AgentContext(
        execution_id="test-fusion-disagreement",
        repository=RepositoryMetadata(owner="demo", name="demo", url="file://demo"),
        mode="full",
        scan=ScanResult(),
        validated_findings=[finding],
    )


def test_ai_unlikely_verdict_does_not_downgrade_or_suppress():
    anchor = _anchor()
    # Simulate a hostile AI verdict: "unlikely" with a demoted confidence on
    # the enriched copy (as an untrusted model output could carry).
    hostile = Finding(**anchor.model_dump())
    hostile = hostile.model_copy(
        update={
            "confidence": Confidence.LOW,
            "ai_reasoning": "The model believes this is sanitized elsewhere.",
            "enriched_by": "nemotron",
            "prompt_version": "codeaudit-security-v1",
        }
    )
    evidence = EvidenceAgentResult(
        status="enabled",
        enriched=[hostile],
        execution_metadata=AgentExecutionMetadata(
            agent_name="evidence_agent",
            status=AgentStatus.COMPLETED,
            duration_ms=1,
            findings_count=1,
        ),
    )
    result = FindingFusionAgent().fuse(_ctx(anchor), [], evidence)

    assert len(result.findings) == 1
    fused = result.findings[0]
    # Anchor fields are byte-identical to the deterministic finding.
    assert (fused.id, fused.file, fused.line, fused.evidence, fused.detector) == (
        anchor.id,
        anchor.file,
        anchor.line,
        anchor.evidence,
        anchor.detector,
    )
    # No downgrade: deterministic confidence and severity survive.
    assert fused.confidence == Confidence.HIGH
    assert fused.severity == Severity.HIGH
    # The disagreement is transparent, not applied.
    assert fused.ai_reasoning == "The model believes this is sanitized elsewhere."
    assert fused.rule_id == "PY-SEC-002"
    assert fused.cwe_ids == ["CWE-89"]
    assert fused.taint_trace == anchor.taint_trace


def test_fusion_without_evidence_keeps_deterministic_findings_untouched():
    anchor = _anchor()
    result = FindingFusionAgent().fuse(_ctx(anchor), [], None)
    assert len(result.findings) == 1
    fused = result.findings[0]
    assert fused.confidence == Confidence.HIGH
    assert fused.ai_reasoning is None
    assert result.deterministic_count == 1
    assert result.ai_accepted_count == 0
