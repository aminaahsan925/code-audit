"""Precision/recall benchmark corpus (Phase 3, §7.6).

Methodology (honest, narrow):
  * Each rule has labeled fixtures: vulnerable (expected to fire N times),
    safe (expected 0), and near-miss traps where meaningful (expected 0).
  * The REAL language analyzer runs over each fixture (parse + all
    detectors); findings are filtered to the rule's detector. This measures
    shipped behavior, not isolated detector functions.
  * Per rule: TP = Σ min(actual, expected); FP = Σ max(0, actual−expected)
    (+ all firings on known_fp files, which are labeled false positives);
    FN = Σ max(0, expected−actual).
  * precision = TP/(TP+FP) (1.0 when nothing fired); recall = TP/(TP+FN)
    (1.0 when ground truth has no positives); fp_rate = FP / (# files with
    expected == 0).
  * known_fp files document genuine detector limitations. Their firings are
    real false positives, shown in the table, but excluded from the
    regression assertion so the suite tracks the limitation without going
    red. The limitation is also in the rule registry.

This corpus measures the CURRENT detectors on hand-written examples. It
does not represent all real-world vulnerabilities, frameworks, or
obfuscation techniques.
"""

from __future__ import annotations

import json
from pathlib import Path

from services.languages.registry import get_analyzer
from services.languages.rule_registry import all_rules

BENCH = Path(__file__).parent / "benchmarks"
MANIFEST = json.loads((BENCH / "manifest.json").read_text())
SUPPLYCHAIN_DB = BENCH / "supplychain" / "advisories.json"


def _supplychain_db():
    # Imported lazily: the corpus runner should not import the
    # supply-chain package for the language rules.
    from services.supplychain.advisories import LocalAdvisoryDB

    # max_age_days is huge on purpose: the fixture DB's generated_at is
    # fixed, and the corpus measures detector behavior, not staleness.
    # DEP-003 (stale/unavailable DB) is covered by unit tests instead.
    return LocalAdvisoryDB(str(SUPPLYCHAIN_DB), max_age_days=36500)


def _run_rule(detector: str, language: str, files: list[dict]):
    if language == "supplychain":
        from services.supplychain.dispatch import analyze_supplychain_file

        db = _supplychain_db()
        rows = []
        for entry in files:
            content = (BENCH / entry["path"]).read_text(encoding="utf-8")
            findings = analyze_supplychain_file(entry["path"], content, db)
            actual = sum(1 for f in findings if f.detector == detector)
            rows.append((entry, actual))
        return rows
    analyzer = get_analyzer(language)
    assert analyzer is not None, f"no analyzer for language {language!r}"
    rows = []
    for entry in files:
        content = (BENCH / entry["path"]).read_text(encoding="utf-8")
        findings = analyzer.analyze_file(entry["path"], content)
        actual = sum(1 for f in findings if f.detector == detector)
        rows.append((entry, actual))
    return rows


def _score(rows: list[tuple[dict, int]]) -> dict:
    tp = fp = fn = 0
    neg_files = 0
    for entry, actual in rows:
        expected = entry["expected"]
        if entry.get("known_fp"):
            fp += actual  # labeled false positive by construction
            if expected == 0:
                neg_files += 1
            continue
        tp += min(actual, expected)
        fp += max(0, actual - expected)
        fn += max(0, expected - actual)
        if expected == 0:
            neg_files += 1
    precision = tp / (tp + fp) if (tp + fp) else 1.0
    recall = tp / (tp + fn) if (tp + fn) else 1.0
    fp_rate = fp / neg_files if neg_files else 0.0
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision": precision,
        "recall": recall,
        "fp_rate": fp_rate,
    }


def test_registry_and_corpus_cover_the_same_rules():
    manifest_detectors = set(MANIFEST["rules"])
    # The benchmark corpus covers file-based static-analyzer rules only.
    # Live website-scan rules (language "website") are exercised against a
    # fixture HTTP server in tests/test_livescan.py instead of file
    # fixtures, so they are excluded from this comparison by design.
    registry_detectors = {
        r.detector for r in all_rules() if "website" not in r.languages
    }
    assert manifest_detectors == registry_detectors, (
        "corpus/registry drift: "
        f"missing from corpus={sorted(registry_detectors - manifest_detectors)}, "
        f"missing from registry={sorted(manifest_detectors - registry_detectors)}"
    )
    for detector, entry in MANIFEST["rules"].items():
        rule = next(r for r in all_rules() if r.detector == detector)
        assert entry["rule_id"] == rule.rule_id
        assert entry["language"] in rule.languages


def test_benchmark_no_regressions_and_report():
    failures: list[str] = []
    table: list[tuple] = []
    for detector, entry in sorted(MANIFEST["rules"].items()):
        rows = _run_rule(detector, entry["language"], entry["files"])
        for file_entry, actual in rows:
            if file_entry.get("known_fp"):
                continue  # tracked limitation, not a regression gate
            if actual != file_entry["expected"]:
                failures.append(
                    f"{detector} on {file_entry['path']}: "
                    f"expected {file_entry['expected']}, got {actual}"
                )
        score = _score(rows)
        table.append((entry["rule_id"], detector, score))

    assert not failures, "benchmark regressions:\n" + "\n".join(failures)

    # Measured summary (printed; also recorded in docs/IMPLEMENTATION_LOG.md).
    lines = [
        "",
        "=== CodeAudit detector benchmark (measured, hermetic) ===",
        f"{'rule':<12}{'detector':<28}{'P':>6}{'R':>6}{'FP_rate':>8}  (TP/FP/FN)",
    ]
    for rule_id, detector, s in table:
        lines.append(
            f"{rule_id:<12}{detector:<28}{s['precision']:>6.2f}{s['recall']:>6.2f}"
            f"{s['fp_rate']:>8.2f}  ({s['tp']}/{s['fp']}/{s['fn']})"
        )
    lines.append("P=precision R=recall FP_rate=false positives per negative fixture")
    print("\n".join(lines))
