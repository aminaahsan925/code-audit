"""Performance regression tests (Phase Two).

These tests guard the parse-reuse optimization:

1. Findings equivalence: analyzing via a reused parse tree must produce
   byte-identical findings (IDs, evidence, severity, confidence) to the
   legacy re-parse path, on every fixture file.
2. Timing: the tree-reuse path must be materially faster than re-parsing,
   with generous margins so CI doesn't flake (min-of-N runs, large corpus).
3. Budgets: full scans complete inside documented wall-clock budgets.
4. Parser reuse: one tree-sitter Parser instance per thread per language.

All hermetic. Timing assertions use min-of-3 and wide margins; they assert
a large, structural speedup (~2-3x from eliminating re-parses), not a
precise number.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from agents.contracts import AgentContext
from agents.performance_agent import PerformanceAgent
from agents.quality_agent import QualityAgent
from models.schemas import RepositoryMetadata
from services.ai_provider import StubAIProvider
from services.languages.base import ParsedSource
from services.languages.javascript_analyzer import JavaScriptAnalyzer
from services.languages.python_analyzer import PythonAnalyzer
from services.languages.registry import get_analyzer
from services.orchestrator import AnalysisOrchestrator
from services.static_analyzer import analyze_content as legacy_python_analyze

BACKEND_DIR = Path(__file__).resolve().parent.parent
FIXTURES_DIR = BACKEND_DIR / "tests" / "fixtures"

# Timing margins: deliberately generous. The optimization removes one full
# parse+symbols pass per file; the rest of analyze_static (the detectors
# themselves) is identical in both paths, so the ratio converges to
# ~(detectors)/(detectors + parse) — well under 0.85 on this corpus.
# Min-of-N and a large file count keep CI noise far from the threshold.
REUSE_SPEEDUP_THRESHOLD = 0.85
TIMING_RUNS = 5
SELF_TREE_BUDGET_S = 10.0


def _fixture_sources() -> list[tuple[str, str, str]]:
    """All (relative_path, language, content) fixture files for deep analysis."""
    items = []
    for path in sorted(FIXTURES_DIR.rglob("*")):
        if not path.is_file() or path.suffix not in (
            ".py",
            ".js",
            ".jsx",
            ".ts",
            ".tsx",
        ):
            continue
        # Skip files inside ignored directories (node_modules, venv, ...):
        # the scanner never analyzes them, so neither should this test.
        rel = path.relative_to(FIXTURES_DIR).as_posix()
        if any(part in ("node_modules", "venv", ".venv") for part in path.parts):
            continue
        language = (
            "python"
            if path.suffix == ".py"
            else ("typescript" if path.suffix in (".ts", ".tsx") else "javascript")
        )
        items.append((rel, language, path.read_text(encoding="utf-8")))
    assert items, "no fixture files found"
    return items


def _finding_key(f) -> tuple:
    return (
        f.id,
        f.detector,
        f.file,
        f.line,
        f.evidence,
        f.severity.value,
        f.confidence.value,
        f.category.value,
    )


def test_parse_reuse_findings_identical_all_fixtures():
    """analyze_parsed(tree from parse_source) == legacy re-parse path."""
    for rel, language, content in _fixture_sources():
        if language == "python":
            # Truly independent legacy implementation: static_analyzer still
            # parses internally. Stamp language like the adapter does.
            legacy = legacy_python_analyze(rel, content)
            for f in legacy:
                f.language = "python"
            analyzer = PythonAnalyzer()
        else:
            analyzer = JavaScriptAnalyzer(language)
            # Independent legacy path: fresh tree-sitter parse outside the
            # analyzer, then the same detector entry point.
            from tree_sitter import Language, Parser

            import tree_sitter_javascript
            import tree_sitter_typescript

            grammar = (
                Language(tree_sitter_typescript.language_tsx())
                if language == "typescript"
                else Language(tree_sitter_javascript.language())
            )
            tree = Parser(grammar).parse(content.encode("utf-8"))
            legacy_source = ParsedSource(
                relative_path=rel, language=language, tree=tree
            )
            legacy = analyzer.analyze_parsed(rel, content, legacy_source)
        reused = analyzer.analyze_parsed(
            rel, content, analyzer.parse_source(content, rel)
        )
        assert [_finding_key(f) for f in reused] == [
            _finding_key(f) for f in legacy
        ], f"findings differ for {rel}"


def test_analyze_file_contract_unchanged():
    """The public analyze_file entry point still matches the reuse path."""
    for rel, language, content in _fixture_sources():
        analyzer = get_analyzer(language)
        assert analyzer is not None
        via_file = analyzer.analyze_file(rel, content)
        via_reuse = analyzer.analyze_parsed(
            rel, content, analyzer.parse_source(content, rel)
        )
        assert [f.id for f in via_file] == [f.id for f in via_reuse], rel


def _min_time(fn, runs: int = TIMING_RUNS) -> float:
    best = float("inf")
    for _ in range(runs):
        start = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - start)
    return best


def test_analyze_static_reuse_faster_than_legacy_on_self_tree():
    """On ~100 files, tree reuse must beat re-parsing by a wide margin."""
    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(BACKEND_DIR)
    assert len(scan.files) > 50, "self-tree probe needs a real corpus"
    _, sources, _ = orch.parse(scan)

    legacy_s = _min_time(lambda: orch.analyze_static(scan))
    reuse_s = _min_time(lambda: orch.analyze_static(scan, sources))

    assert reuse_s < legacy_s * REUSE_SPEEDUP_THRESHOLD, (
        f"parse reuse not faster enough: reuse={reuse_s:.1f}ms "
        f"legacy={legacy_s:.1f}ms (threshold {REUSE_SPEEDUP_THRESHOLD})"
    )


def test_analyze_static_reuse_same_findings_on_self_tree():
    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(BACKEND_DIR)
    _, sources, _ = orch.parse(scan)
    reused = orch.analyze_static(scan, sources)
    legacy = orch.analyze_static(scan)
    assert [f.id for f in reused] == [f.id for f in legacy]


def test_full_self_tree_scan_within_budget():
    """End-to-end free-mode scan of the ~100-file backend tree."""
    from agents.supervisor_agent import SupervisorAgent

    supervisor = SupervisorAgent(
        orchestrator=AnalysisOrchestrator(ai_provider=StubAIProvider()),
        default_mode="free",
    )
    started = time.perf_counter()
    result = supervisor.run_on_local_path(BACKEND_DIR, owner="local", name="self-tree")
    elapsed = time.perf_counter() - started
    assert elapsed < SELF_TREE_BUDGET_S, f"full scan took {elapsed:.1f}s"
    assert result.summary.files_scanned > 50


def test_fixture_scans_complete():
    """Every analysis fixture still scans end-to-end without error."""
    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    for fixture in ("js_vulnerable", "ts_vulnerable", "sql_injection_example"):
        result = orch.run_on_local_path(FIXTURES_DIR / fixture)
        assert result.summary.files_scanned >= 1
        assert result.summary.findings_total >= 1


def test_parser_instances_reused_per_thread():
    """One cached tree-sitter Parser per language per thread."""
    import services.languages.javascript_analyzer as js_mod

    analyzer = JavaScriptAnalyzer("javascript")
    analyzer.parse_source("const a = 1;", "a.js")
    first = js_mod._thread_state.parsers["javascript"]
    analyzer.parse_source("const b = 2;", "b.js")
    analyzer.parse_source("const c = 3;", "c.js")
    assert js_mod._thread_state.parsers["javascript"] is first
    # A different language gets its own instance, not a shared one.
    ts_analyzer = JavaScriptAnalyzer("typescript")
    ts_analyzer.parse_source("const a: number = 1;", "a.ts")
    assert js_mod._thread_state.parsers["typescript"] is not first


def test_specialist_agents_reuse_trees_identically():
    """Performance/Quality detect() with shared trees == legacy per-file parse."""
    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(FIXTURES_DIR / "sql_injection_example")
    parsed, sources, _ = orch.parse(scan)
    repo = RepositoryMetadata(owner="local", name="fixture", url="file://x")

    def make_ctx(with_trees: bool) -> AgentContext:
        return AgentContext(
            execution_id="perf-test",
            repository=repo,
            mode="free",
            scan=scan,
            parsed=parsed,
            parse_trees=(
                {p: s.tree for p, s in sources.items() if s.tree is not None}
                if with_trees
                else {}
            ),
        )

    for agent_cls in (PerformanceAgent, QualityAgent):
        reused = agent_cls().detect(make_ctx(True))
        legacy = agent_cls().detect(make_ctx(False))
        assert [f.id for f in reused] == [f.id for f in legacy]


def test_broken_fixtures_yield_no_findings_either_path():
    """Invalid-syntax fixtures: no crash, no findings, both paths."""
    cases = [
        ("python", "broken.py", "def broken(:\n"),
        ("javascript", "broken.js", "function broken( {"),
    ]
    for language, name, content in cases:
        analyzer = get_analyzer(language)
        assert analyzer is not None
        assert analyzer.analyze_file(name, content) == []
        assert (
            analyzer.analyze_parsed(name, content, analyzer.parse_source(content, name))
            == []
        )


def test_analyze_parsed_consumes_the_tree_not_the_content():
    """Deterministic proof of tree reuse: findings follow the parsed tree,
    not the content string passed alongside it."""
    analyzer = PythonAnalyzer()
    parsed = analyzer.parse_source("result = eval(user_input)\n", "evil.py")
    assert parsed.tree is not None
    # Content is clean, but the tree is dirty: findings must reflect the tree.
    # (Evidence text itself is read from the content lines — in production
    # tree and content always agree, so this only matters for this synthetic
    # mismatch.)
    findings = analyzer.analyze_parsed("clean.py", "x = 1\n", parsed)
    assert [f.detector for f in findings] == ["dangerous_eval"]

    js = JavaScriptAnalyzer("javascript")
    js_parsed = js.parse_source("const r = eval(userInput);", "evil.js")
    assert js_parsed.tree is not None
    # Same content the tree was built from: detectors must fire via the
    # analyze_parsed entry point (no re-parse; proven separately by the
    # counting test below).
    js_findings = js.analyze_parsed(
        "evil.js", "const r = eval(userInput);", js_parsed
    )
    assert [f.detector for f in js_findings] == ["js_dangerous_eval"]


def test_no_reparse_when_sources_shared():
    """analyze_static(sources) must not invoke any parser again.

    Counts underlying parse operations across both languages: the parse
    stage parses each deep-analysis file once; the analyze stage with
    shared sources must add zero.
    """
    import ast as ast_module

    import services.languages.javascript_analyzer as js_mod

    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(FIXTURES_DIR)
    deep = [
        a for a in scan.files if get_analyzer(a.language) is not None
    ]
    assert any(a.language == "python" for a in deep)
    assert any(a.language in ("javascript", "typescript") for a in deep)

    real_ast_parse = ast_module.parse
    real_get_parser = js_mod._get_parser
    calls = {"ast": 0, "ts": 0}

    def counting_ast_parse(*args, **kwargs):
        calls["ast"] += 1
        return real_ast_parse(*args, **kwargs)

    def counting_get_parser(language):
        # _get_parser is the only path to a tree-sitter parse; the cached
        # Parser instance itself is never re-created per file anymore.
        calls["ts"] += 1
        return real_get_parser(language)

    ast_module.parse = counting_ast_parse
    js_mod._get_parser = counting_get_parser
    try:
        _, sources, _ = orch.parse(scan)
        parse_calls = dict(calls)
        orch.analyze_static(scan, sources)
        analyze_calls = {k: calls[k] - parse_calls[k] for k in calls}
    finally:
        ast_module.parse = real_ast_parse
        js_mod._get_parser = real_get_parser

    assert parse_calls["ast"] + parse_calls["ts"] == len(deep), (
        f"parse stage should parse each deep file once: {parse_calls} vs "
        f"{len(deep)} files"
    )
    assert analyze_calls == {"ast": 0, "ts": 0}, (
        f"analyze stage parsed again despite shared trees: {analyze_calls}"
    )
