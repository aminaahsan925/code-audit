"""Phase 7 tests: persistence, API-key auth, tenant isolation, durable
jobs, scan history, metering. All hermetic (tmp SQLite files; the worker
is exercised with stub handlers, never the network).
"""

from __future__ import annotations

import json
import os
import stat
import threading
import time
from dataclasses import fields
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app import main as app_main
from services.persistence import auth as auth_lib
from services.persistence import database as persistence_db
from services.persistence import jobs as job_queue
from services.persistence import metering
from services.persistence import repository as persistence_repo
from services.persistence.models import ScanJob


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def db_url(tmp_path: Path) -> str:
    return f"sqlite:///{tmp_path}/test.db"


@pytest.fixture()
def app_settings(monkeypatch, db_url: str):
    """Point the app at a tmp database, mirroring every real Setting."""

    real = app_main.settings
    ns = SimpleNamespace(
        **{f.name: getattr(real, f.name) for f in fields(real)}
    )
    ns.database_url = db_url
    monkeypatch.setattr(app_main, "settings", ns)
    persistence_db.reset_engine_cache()
    persistence_db.init_db(db_url)
    yield ns
    persistence_db.reset_engine_cache()
    app_main._JOB_SECRETS.clear()


@pytest.fixture()
def factory(app_settings, db_url: str):
    return persistence_db.get_session_factory(db_url)


@pytest.fixture()
def client() -> TestClient:
    # Plain TestClient: lifespan is NOT run (no worker thread, no bootstrap).
    return TestClient(app_main.app)


def _make_user(factory, name="u", scopes=("admin",)):
    with factory() as session:
        user = persistence_repo.create_user(session, name)
        record, plaintext = persistence_repo.create_api_key(
            session, user.id, name=f"{name}-key", scopes=list(scopes)
        )
        session.commit()
        return user.id, record.id, plaintext, record.key_prefix


def _auth_headers(plaintext: str) -> dict:
    return {"X-API-Key": plaintext}


# ---------------------------------------------------------------------------
# Auth unit tests (no DB)
# ---------------------------------------------------------------------------


def test_generate_key_format():
    plaintext, prefix = auth_lib.generate_api_key()
    assert plaintext.startswith("ca_")
    assert len(plaintext) > 40
    assert prefix == plaintext[:12]


def test_hash_verify_roundtrip():
    plaintext, _ = auth_lib.generate_api_key()
    stored = auth_lib.hash_api_key(plaintext)
    assert auth_lib.verify_api_key(plaintext, stored)
    # Same key, fresh salt -> different hash, still verifies.
    assert auth_lib.hash_api_key(plaintext) != stored
    assert auth_lib.verify_api_key(plaintext, auth_lib.hash_api_key(plaintext))


def test_verify_wrong_key_fails():
    p1, _ = auth_lib.generate_api_key()
    p2, _ = auth_lib.generate_api_key()
    assert not auth_lib.verify_api_key(p2, auth_lib.hash_api_key(p1))


def test_verify_malformed_hash_fails():
    plaintext, _ = auth_lib.generate_api_key()
    assert not auth_lib.verify_api_key(plaintext, "not-a-hash")
    assert not auth_lib.verify_api_key(plaintext, "a$b$c")  # wrong arity
    assert not auth_lib.verify_api_key(
        plaintext, "md5$600000$" + "00" * 16 + "$" + "00" * 32
    )  # wrong algo


def test_plaintext_never_in_stored_hash():
    plaintext, _ = auth_lib.generate_api_key()
    stored = auth_lib.hash_api_key(plaintext)
    assert plaintext not in stored
    assert plaintext[3:] not in stored  # token part absent too


def test_scope_implications():
    assert auth_lib.scopes_grant(["scan"], "read")
    assert auth_lib.scopes_grant(["scan"], "scan")
    assert not auth_lib.scopes_grant(["scan"], "admin")
    assert auth_lib.scopes_grant(["admin"], "read")
    assert auth_lib.scopes_grant(["admin"], "scan")
    assert not auth_lib.scopes_grant(["read"], "scan")


def test_normalize_scopes_rejects_unknown():
    with pytest.raises(ValueError):
        auth_lib.normalize_scopes(["read", "root"])


# ---------------------------------------------------------------------------
# Database lifecycle
# ---------------------------------------------------------------------------


def test_schema_version_stamped(factory, db_url):
    engine = persistence_db.get_engine(db_url)
    assert persistence_db.upgrade_database(engine) == persistence_db.SCHEMA_VERSION
    # Idempotent: second run changes nothing.
    assert persistence_db.upgrade_database(engine) == persistence_db.SCHEMA_VERSION


def test_sqlite_file_permissions_0600(db_url, tmp_path):
    persistence_db.init_db(db_url)
    db_file = tmp_path / "test.db"
    assert db_file.exists()
    mode = stat.S_IMODE(os.stat(db_file).st_mode)
    assert mode == 0o600, f"expected 0600, got {oct(mode)}"


# ---------------------------------------------------------------------------
# API-key authentication (repository layer)
# ---------------------------------------------------------------------------


def test_authenticate_api_key_roundtrip(factory):
    _, _, plaintext, _ = _make_user(factory)
    with factory() as session:
        record = persistence_repo.authenticate_api_key(session, plaintext)
        assert record is not None
        assert record.last_used_at is not None
        session.commit()


def test_authenticate_wrong_key_fails(factory):
    _make_user(factory)
    with factory() as session:
        assert persistence_repo.authenticate_api_key(session, "ca_" + "x" * 43) is None
        assert persistence_repo.authenticate_api_key(session, "") is None
        assert persistence_repo.authenticate_api_key(session, "garbage") is None


def test_authenticate_revoked_key_fails(factory):
    user_id, key_id, plaintext, _ = _make_user(factory)
    with factory() as session:
        assert persistence_repo.revoke_api_key(session, user_id, key_id)
        session.commit()
    with factory() as session:
        assert persistence_repo.authenticate_api_key(session, plaintext) is None


def test_revoke_other_users_key_fails(factory):
    _, key_id_a, _, _ = _make_user(factory, name="a")
    user_b, _, _, _ = _make_user(factory, name="b")
    with factory() as session:
        # B cannot revoke A's key.
        assert not persistence_repo.revoke_api_key(session, user_b, key_id_a)
        session.commit()


# ---------------------------------------------------------------------------
# Tenant isolation (repository layer — the mandatory tests)
# ---------------------------------------------------------------------------


def test_user_cannot_read_other_users_project(factory):
    user_a, _, _, _ = _make_user(factory, name="a")
    user_b, _, _, _ = _make_user(factory, name="b")
    with factory() as session:
        project = persistence_repo.create_project(session, user_a, "a-project")
        session.commit()
        pid = project.id
    with factory() as session:
        assert persistence_repo.get_project(session, user_b, pid) is None
        assert persistence_repo.list_projects(session, user_b) == []


def test_user_cannot_read_other_users_analysis(factory):
    user_a, _, _, _ = _make_user(factory, name="a")
    user_b, _, _, _ = _make_user(factory, name="b")
    with factory() as session:
        project = persistence_repo.create_project(session, user_a, "a-project")
        analysis = persistence_repo.record_repo_analysis(
            session,
            user_id=user_a,
            project_id=project.id,
            repository_url="https://github.com/o/r",
            findings=[{"id": "F1"}],
            risk_score=5,
            summary={},
        )
        session.commit()
        aid = analysis.id
    with factory() as session:
        assert persistence_repo.get_repo_analysis(session, user_b, aid) is None
        # NOTE: get_finding_snapshots is keyed by owner id only by design —
        # callers must verify ownership via get_repo_analysis /
        # get_website_scan first (the HTTP layer does; covered by
        # test_analysis_detail_api_returns_snapshots).


def test_anonymous_sees_only_unowned_rows(factory):
    user_a, _, _, _ = _make_user(factory, name="a")
    with factory() as session:
        persistence_repo.create_project(session, user_a, "owned")
        persistence_repo.create_project(session, None, "unowned")
        session.commit()
    with factory() as session:
        projects = persistence_repo.list_projects(session, None)
        assert [p.name for p in projects] == ["unowned"]


def test_cross_user_job_invisible(factory):
    user_a, _, _, _ = _make_user(factory, name="a")
    user_b, _, _, _ = _make_user(factory, name="b")
    with factory() as session:
        job = job_queue.enqueue_job(
            session, kind="repo_analysis", request={}, user_id=user_a
        )
        session.commit()
        jid = job.id
    with factory() as session:
        assert persistence_repo.get_job(session, user_b, jid) is None
        assert persistence_repo.get_job(session, user_a, jid) is not None


# ---------------------------------------------------------------------------
# Projects API
# ---------------------------------------------------------------------------


def test_create_and_list_projects(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    r = client.post("/projects", json={"name": "web"}, headers=headers)
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    r = client.get("/projects", headers=headers)
    assert r.status_code == 200
    assert [p["id"] for p in r.json()] == [pid]
    r = client.get(f"/projects/{pid}", headers=headers)
    assert r.status_code == 200
    assert r.json()["name"] == "web"


def test_project_cross_user_returns_404(client, factory, app_settings):
    _, _, plaintext_a, _ = _make_user(factory, name="a")
    _, _, plaintext_b, _ = _make_user(factory, name="b")
    pid = client.post(
        "/projects", json={"name": "a-proj"}, headers=_auth_headers(plaintext_a)
    ).json()["id"]
    # B gets 404, not 403 — no existence oracle for other tenants.
    r = client.get(f"/projects/{pid}", headers=_auth_headers(plaintext_b))
    assert r.status_code == 404
    r = client.get(
        f"/projects/{pid}/scans", headers=_auth_headers(plaintext_b)
    )
    assert r.status_code == 404
    # B's own history is empty.
    r = client.get("/projects", headers=_auth_headers(plaintext_b))
    assert r.json() == []


def test_projects_require_auth_when_enabled(client, factory, app_settings):
    app_settings.require_auth = True
    r = client.get("/projects")
    assert r.status_code == 401
    assert r.json()["detail"]["error"]["code"] == "AUTH_REQUIRED"
    _, _, plaintext, _ = _make_user(factory)
    r = client.get("/projects", headers=_auth_headers(plaintext))
    assert r.status_code == 200


def test_invalid_and_revoked_keys_rejected(client, factory, app_settings):
    app_settings.require_auth = True
    r = client.get("/projects", headers=_auth_headers("ca_" + "z" * 43))
    assert r.status_code == 401
    user_id, key_id, plaintext, _ = _make_user(factory)
    with factory() as session:
        persistence_repo.revoke_api_key(session, user_id, key_id)
        session.commit()
    r = client.get("/projects", headers=_auth_headers(plaintext))
    assert r.status_code == 401


def test_read_scope_cannot_scan(client, factory, app_settings, fixtures_dir, monkeypatch):
    _, _, plaintext, _ = _make_user(factory, scopes=("read",))
    headers = _auth_headers(plaintext)
    r = client.get("/projects", headers=headers)
    assert r.status_code == 200
    # read-only key may not start analyses.
    r = client.post(
        "/analyze", json={"repository_url": "https://github.com/o/r"}, headers=headers
    )
    assert r.status_code == 403
    assert r.json()["detail"]["error"]["code"] == "INSUFFICIENT_SCOPE"


def test_analyze_requires_auth_when_enabled(client, factory, app_settings):
    app_settings.require_auth = True
    r = client.post("/analyze", json={"repository_url": "https://github.com/o/r"})
    assert r.status_code == 401


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


def test_job_lifecycle_enqueue_claim_complete(factory):
    with factory() as session:
        job = job_queue.enqueue_job(
            session, kind="repo_analysis", request={"a": 1}, user_id="u1"
        )
        session.commit()
        jid = job.id
        assert job.state == "queued"
    with factory() as session:
        claimed = job_queue.claim_next_job(session)
        assert claimed is not None and claimed.id == jid
        assert claimed.state == "running"
        session.commit()
    with factory() as session:
        job_queue.complete_job(session, jid, {"ok": True})
        session.commit()
    with factory() as session:
        job = session.get(ScanJob, jid)
        assert job.state == "done"
        assert json.loads(job.result_json) == {"ok": True}
        assert job.finished_at is not None


def test_claim_is_atomic_no_double_claim(factory):
    with factory() as session:
        job_queue.enqueue_job(session, kind="repo_analysis", request={})
        session.commit()
    with factory() as session:
        assert job_queue.claim_next_job(session) is not None
        session.commit()
    with factory() as session:
        assert job_queue.claim_next_job(session) is None
        session.rollback()


def test_process_one_job_success(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="repo_analysis", request={"x": 1})
        session.commit()
        jid = job.id
    handlers = {"repo_analysis": lambda req: {"echo": req["x"]}}
    assert job_queue.process_one_job(factory, handlers) is True
    with factory() as session:
        job = session.get(ScanJob, jid)
        assert job.state == "done"
        assert json.loads(job.result_json) == {"echo": 1}


def test_process_one_job_failure_marks_failed(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="repo_analysis", request={})
        session.commit()
        jid = job.id

    def boom(req):
        raise RuntimeError("kaput")

    assert job_queue.process_one_job(factory, {"repo_analysis": boom}) is True
    with factory() as session:
        job = session.get(ScanJob, jid)
        assert job.state == "failed"
        assert job.error_code == "RuntimeError"
        assert "kaput" in job.error_message


def test_process_one_job_empty_queue(factory):
    assert job_queue.process_one_job(factory, {}) is False


def test_process_one_job_unknown_kind_fails(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="website_scan", request={})
        session.commit()
        jid = job.id
    # No handler registered for website_scan -> failed, worker survives.
    assert job_queue.process_one_job(factory, {}) is True
    with factory() as session:
        assert session.get(ScanJob, jid).state == "failed"


def test_cancel_queued_job(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="repo_analysis", request={})
        session.flush()
        assert job_queue.cancel_job(session, job) is True
        session.commit()
        assert job.state == "cancelled"


def test_cancel_job_drops_in_memory_scan_secrets(client, factory):
    """DELETE /jobs/{id} must drop _JOB_SECRETS so cancelled scan
    credentials don't linger in memory."""
    user_id, _, plaintext, _ = _make_user(factory)
    with factory() as session:
        job = job_queue.enqueue_job(
            session, kind="website_scan", request={}, user_id=user_id
        )
        session.commit()
        jid = job.id
    app_main._JOB_SECRETS[jid] = {
        "authorization_token": "tok",
        "session_cookie": None,
        "authorization_header": None,
    }
    try:
        r = client.delete(f"/jobs/{jid}", headers=_auth_headers(plaintext))
        assert r.status_code == 200, r.text
        assert jid not in app_main._JOB_SECRETS
    finally:
        app_main._JOB_SECRETS.pop(jid, None)


def test_cancel_running_job_fails(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="repo_analysis", request={})
        session.commit()
        jid = job.id
    with factory() as session:
        claimed = job_queue.claim_next_job(session)
        session.commit()
        assert job_queue.cancel_job(session, claimed) is False


def test_enqueue_unknown_kind_raises(factory):
    with factory() as session:
        with pytest.raises(ValueError):
            job_queue.enqueue_job(session, kind="nope", request={})


def test_worker_thread_processes_job(factory):
    with factory() as session:
        job = job_queue.enqueue_job(session, kind="repo_analysis", request={})
        session.commit()
        jid = job.id
    stop = threading.Event()
    thread = threading.Thread(
        target=job_queue.run_worker_forever,
        args=(factory, stop),
        kwargs={"handlers": {"repo_analysis": lambda req: {"ok": True}},
                "poll_interval": 0.01},
        daemon=True,
    )
    thread.start()
    try:
        deadline = time.time() + 10
        while time.time() < deadline:
            with factory() as session:
                state = session.get(ScanJob, jid).state
            if state == "done":
                break
            time.sleep(0.05)
        assert state == "done"
    finally:
        stop.set()
        thread.join(timeout=10)


# ---------------------------------------------------------------------------
# Async API
# ---------------------------------------------------------------------------


def test_analyze_async_returns_202_and_job_completes(
    client, factory, app_settings
):
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    r = client.post(
        "/analyze?async=true",
        json={"repository_url": "https://github.com/o/r"},
        headers=headers,
    )
    assert r.status_code == 202, r.text
    job_id = r.json()["job_id"]
    r = client.get(f"/jobs/{job_id}", headers=headers)
    assert r.status_code == 200
    assert r.json()["state"] == "queued"
    # Worker (stub handler) completes it.
    assert (
        job_queue.process_one_job(factory, {"repo_analysis": lambda req: {"ok": 1}})
        is True
    )
    r = client.get(f"/jobs/{job_id}", headers=headers)
    body = r.json()
    assert body["state"] == "done"
    assert body["result"] == {"ok": 1}


def test_async_job_tenant_isolation(client, factory, app_settings):
    _, _, plaintext_a, _ = _make_user(factory, name="a")
    _, _, plaintext_b, _ = _make_user(factory, name="b")
    job_id = (
        client.post(
            "/analyze?async=true",
            json={"repository_url": "https://github.com/o/r"},
            headers=_auth_headers(plaintext_a),
        ).json()["job_id"]
    )
    r = client.get(f"/jobs/{job_id}", headers=_auth_headers(plaintext_b))
    assert r.status_code == 404


def test_cancel_job_via_api(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    job_id = (
        client.post(
            "/analyze?async=true",
            json={"repository_url": "https://github.com/o/r"},
            headers=headers,
        ).json()["job_id"]
    )
    r = client.delete(f"/jobs/{job_id}", headers=headers)
    assert r.status_code == 200
    assert r.json()["state"] == "cancelled"
    # Cancelling twice -> 409 (no longer queued).
    r = client.delete(f"/jobs/{job_id}", headers=headers)
    assert r.status_code == 409


def test_website_scan_async_keeps_credentials_out_of_db(
    client, factory, app_settings
):
    app_settings.scan_tokens = "example.com:super-secret-scan-token"
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    r = client.post(
        "/scan/website?async=true",
        json={
            "target_url": "https://example.com/",
            "authorization_token": "super-secret-scan-token",
            "i_authorize_this_scan": True,
        },
        headers=headers,
    )
    assert r.status_code == 202, r.text
    job_id = r.json()["job_id"]
    try:
        with factory() as session:
            job = session.get(ScanJob, job_id)
            assert "super-secret-scan-token" not in job.request_json
        # In-memory handoff holds the credential for the worker.
        assert (
            app_main._JOB_SECRETS[job_id]["authorization_token"]
            == "super-secret-scan-token"
        )
    finally:
        app_main._JOB_SECRETS.pop(job_id, None)


def test_async_analyze_rejects_unknown_project(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    r = client.post(
        "/analyze?async=true",
        json={
            "repository_url": "https://github.com/o/r",
            "project_id": "does-not-exist",
        },
        headers=_auth_headers(plaintext),
    )
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# Scan history
# ---------------------------------------------------------------------------


def test_project_history_lists_both_kinds(factory):
    user_id, _, _, _ = _make_user(factory)
    with factory() as session:
        project = persistence_repo.create_project(session, user_id, "p")
        persistence_repo.record_repo_analysis(
            session,
            user_id=user_id,
            project_id=project.id,
            repository_url="https://github.com/o/r",
            findings=[{"id": "F1", "title": "t"}],
            risk_score=7,
            summary={"risk": {"score": 7}},
        )
        persistence_repo.record_website_scan(
            session,
            user_id=user_id,
            project_id=project.id,
            target_url="https://example.com/",
            findings=[{"id": "L1", "title": "lt"}],
            urls_scanned=3,
            truncated=False,
            summary={"scope": "example.com"},
        )
        session.commit()
        pid = project.id
    with factory() as session:
        analyses, scans = persistence_repo.list_project_history(session, user_id, pid)
        assert len(analyses) == 1 and analyses[0].findings_count == 1
        assert len(scans) == 1 and scans[0].urls_scanned == 3
        assert persistence_repo.get_finding_snapshots(
            session, "repo_analysis", analyses[0].id
        ) == [{"id": "F1", "title": "t"}]


def test_project_history_api(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    pid = client.post("/projects", json={"name": "p"}, headers=headers).json()["id"]
    with factory() as session:
        # Resolve the user id for the repository layer.
        from sqlalchemy import select as sa_select

        user_id = persistence_repo.authenticate_api_key(
            session, plaintext
        ).user_id
        persistence_repo.record_repo_analysis(
            session,
            user_id=user_id,
            project_id=pid,
            repository_url="https://github.com/o/r",
            findings=[],
            risk_score=2,
            summary={},
        )
        session.commit()
    r = client.get(f"/projects/{pid}/scans", headers=headers)
    assert r.status_code == 200
    body = r.json()
    assert len(body["repo_analyses"]) == 1
    assert body["repo_analyses"][0]["repository_url"] == "https://github.com/o/r"
    assert body["website_scans"] == []


def test_analysis_detail_api_returns_snapshots(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    pid = client.post("/projects", json={"name": "p"}, headers=headers).json()["id"]
    finding = {
        "id": "F1",
        "category": "security",
        "severity": "high",
        "title": "t",
        "description": "d",
        "file": "a.py",
        "line": 1,
        "evidence": "x",
        "confidence": "high",
        "source": "deterministic",
        "detector": "d1",
    }
    with factory() as session:
        user_id = persistence_repo.authenticate_api_key(session, plaintext).user_id
        analysis = persistence_repo.record_repo_analysis(
            session,
            user_id=user_id,
            project_id=pid,
            repository_url="https://github.com/o/r",
            findings=[finding],
            risk_score=8,
            summary={},
        )
        session.commit()
        aid = analysis.id
    r = client.get(f"/analyses/{aid}", headers=headers)
    assert r.status_code == 200
    assert r.json()["findings"][0]["id"] == "F1"
    # Cross-user: 404.
    _, _, plaintext_b, _ = _make_user(factory, name="b")
    r = client.get(f"/analyses/{aid}", headers=_auth_headers(plaintext_b))
    assert r.status_code == 404


def test_sync_analyze_persists_history(
    client, factory, app_settings, fixtures_dir, monkeypatch
):
    import shutil

    from services import github_service

    def fake_clone(ref, dest):
        shutil.copytree(fixtures_dir / "sql_injection_example", dest)
        return dest

    monkeypatch.setattr(
        app_main.orchestrator,
        "fetch_repo",
        lambda url, dest: fake_clone(github_service.validate_github_url(url), dest),
    )
    monkeypatch.setattr(
        github_service, "fetch_metadata", lambda ref: {"default_branch": "main"}
    )
    _, _, plaintext, _ = _make_user(factory)
    headers = _auth_headers(plaintext)
    pid = client.post("/projects", json={"name": "p"}, headers=headers).json()["id"]
    r = client.post(
        "/analyze",
        json={
            "repository_url": "https://github.com/o/r",
            "project_id": pid,
        },
        headers=headers,
    )
    assert r.status_code == 200, r.text
    n_findings = len(r.json()["findings"])
    assert n_findings > 0
    with factory() as session:
        analyses, _ = persistence_repo.list_project_history(
            session, persistence_repo.authenticate_api_key(session, plaintext).user_id,
            pid,
        )
        assert len(analyses) == 1
        assert analyses[0].findings_count == n_findings
        snapshots = persistence_repo.get_finding_snapshots(
            session, "repo_analysis", analyses[0].id
        )
        assert len(snapshots) == n_findings


# ---------------------------------------------------------------------------
# Metering
# ---------------------------------------------------------------------------


def test_metering_increment_and_get(factory):
    _, key_id, _, _ = _make_user(factory)
    with factory() as session:
        metering.increment(session, key_id, "analyses")
        metering.increment(session, key_id, "analyses")
        metering.increment(session, key_id, "ai_calls", amount=3)
        session.commit()
    with factory() as session:
        counters = metering.get_counters(session, key_id)
        assert counters["analyses"] == 2
        assert counters["ai_calls"] == 3
        assert counters["scans"] == 0
        assert counters["ai_tokens"] == 0


def test_metering_anonymous_is_noop(factory):
    with factory() as session:
        metering.increment(session, None, "analyses")  # must not raise
        session.commit()


def test_metering_unknown_counter_raises(factory):
    _, key_id, _, _ = _make_user(factory)
    with factory() as session:
        with pytest.raises(ValueError):
            metering.increment(session, key_id, "bogus")


def test_usage_api(client, factory, app_settings):
    _, key_id, plaintext, prefix = _make_user(factory)
    headers = _auth_headers(plaintext)
    with factory() as session:
        metering.increment(session, key_id, "scans", amount=4)
        session.commit()
    r = client.get("/usage", headers=headers)
    assert r.status_code == 200
    body = r.json()
    assert body["api_key_prefix"] == prefix
    assert body["counters"]["scans"] == 4
    # Anonymous usage query -> 401.
    r = client.get("/usage")
    assert r.status_code == 401


# ---------------------------------------------------------------------------
# API key management
# ---------------------------------------------------------------------------


def test_key_lifecycle_via_api(client, factory, app_settings):
    _, _, admin_plaintext, _ = _make_user(factory, scopes=("admin",))
    headers = _auth_headers(admin_plaintext)
    # Issue a read-only key.
    r = client.post(
        "/keys", json={"name": "ro", "scopes": ["read"]}, headers=headers
    )
    assert r.status_code == 200, r.text
    created = r.json()
    assert created["api_key"].startswith("ca_")
    assert created["scopes"] == ["read"]
    new_key = created["api_key"]
    key_id = created["id"]
    # The new key authenticates.
    r = client.get("/projects", headers=_auth_headers(new_key))
    assert r.status_code == 200
    # Plaintext is shown once: listing never reveals it.
    r = client.get("/keys", headers=headers)
    assert r.status_code == 200
    assert all("api_key" not in k for k in r.json())
    # Revoke it: it stops working.
    r = client.delete(f"/keys/{key_id}", headers=headers)
    assert r.status_code == 200
    r = client.get("/projects", headers=_auth_headers(new_key))
    assert r.status_code == 401


def test_key_issuance_requires_authentication(client, factory, app_settings):
    r = client.post("/keys", json={"name": "x"})
    assert r.status_code == 401


def test_key_issuance_rejects_unknown_scope(client, factory, app_settings):
    _, _, plaintext, _ = _make_user(factory)
    r = client.post(
        "/keys",
        json={"name": "x", "scopes": ["root"]},
        headers=_auth_headers(plaintext),
    )
    assert r.status_code == 400
