"""Phase One hardening tests: correlation IDs, input bounds, analysis timeout.

All hermetic: no network, no AI keys, no timing flakiness (deadlines are
passed explicitly as already-past timestamps rather than slept toward).
"""

import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import main as app_main
from services import repository_scanner
from services.repository_scanner import (
    AnalysisTimeoutError,
    analysis_deadline,
    check_deadline,
)


# -- correlation IDs -----------------------------------------------------


def test_health_returns_request_id(client: TestClient):
    response = client.get("/health")
    assert response.status_code == 200
    request_id = response.headers.get("X-Request-ID")
    assert request_id and len(request_id) > 0


def test_request_ids_are_unique_per_request(client: TestClient):
    first = client.get("/health").headers["X-Request-ID"]
    second = client.get("/health").headers["X-Request-ID"]
    assert first != second


def test_valid_client_request_id_is_echoed(client: TestClient):
    response = client.get("/health", headers={"X-Request-ID": "demo-123_abc"})
    assert response.headers["X-Request-ID"] == "demo-123_abc"


def test_oversized_client_request_id_is_replaced(client: TestClient):
    bad = "x" * 200
    response = client.get("/health", headers={"X-Request-ID": bad})
    echoed = response.headers["X-Request-ID"]
    assert echoed != bad
    assert len(echoed) > 0


def test_malformed_client_request_id_is_replaced(client: TestClient):
    response = client.get("/health", headers={"X-Request-ID": "has spaces!"})
    assert response.headers["X-Request-ID"] != "has spaces!"


def test_error_responses_carry_request_id(client: TestClient):
    response = client.post("/analyze", json={"repository_url": "not-a-url"})
    assert response.status_code == 422
    assert response.headers.get("X-Request-ID")


# -- input bounds --------------------------------------------------------


def test_analyze_rejects_oversized_url(client: TestClient):
    long_url = "https://github.com/" + "a" * 3000
    response = client.post("/analyze", json={"repository_url": long_url})
    assert response.status_code == 422


def test_remediate_rejects_oversized_url(client: TestClient):
    long_url = "https://github.com/" + "a" * 3000
    response = client.post(
        "/remediate", json={"repository_url": long_url, "finding_id": "x"}
    )
    assert response.status_code == 422


def test_remediate_batch_rejects_oversized_url(client: TestClient):
    long_url = "https://github.com/" + "a" * 3000
    response = client.post(
        "/remediate/batch",
        json={"repository_url": long_url, "finding_ids": ["x"]},
    )
    assert response.status_code == 422


# -- analysis wall-clock budget ------------------------------------------


def test_check_deadline_raises_on_past_deadline():
    with pytest.raises(AnalysisTimeoutError) as exc_info:
        check_deadline(time.monotonic() - 1)
    assert exc_info.value.code == "ANALYSIS_TIMEOUT"


def test_check_deadline_passes_on_future_deadline():
    check_deadline(time.monotonic() + 60)
    check_deadline(None)


def test_analysis_deadline_disabled_when_limit_nonpositive(monkeypatch):
    import dataclasses

    from app.config import settings as real_settings

    monkeypatch.setattr(
        repository_scanner,
        "settings",
        dataclasses.replace(real_settings, max_analysis_seconds=0),
    )
    assert analysis_deadline() is None


def test_analysis_deadline_is_in_the_future_by_default():
    deadline = analysis_deadline()
    assert deadline is not None
    assert deadline > time.monotonic()


def test_scan_repository_respects_deadline(tmp_path: Path):
    (tmp_path / "a.py").write_text("x = 1\n")
    with pytest.raises(AnalysisTimeoutError):
        repository_scanner.scan_repository(tmp_path, deadline=time.monotonic() - 1)


def test_scan_repository_works_without_deadline_pressure(tmp_path: Path):
    (tmp_path / "a.py").write_text("x = 1\n")
    result = repository_scanner.scan_repository(tmp_path)
    assert len(result.files) == 1


def test_orchestrator_parse_respects_deadline(fixtures_dir: Path):
    from services.ai_provider import StubAIProvider
    from services.orchestrator import AnalysisOrchestrator

    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(fixtures_dir / "sql_injection_example")
    with pytest.raises(AnalysisTimeoutError):
        orch.parse(scan, deadline=time.monotonic() - 1)


def test_orchestrator_analyze_static_respects_deadline(fixtures_dir: Path):
    from services.ai_provider import StubAIProvider
    from services.orchestrator import AnalysisOrchestrator

    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    scan = orch.scan_files(fixtures_dir / "sql_injection_example")
    with pytest.raises(AnalysisTimeoutError):
        orch.analyze_static(scan, deadline=time.monotonic() - 1)


def test_analyze_timeout_maps_to_504(client: TestClient, monkeypatch):
    def boom(url, dest):
        raise AnalysisTimeoutError("budget exceeded in tests")

    monkeypatch.setattr(app_main.orchestrator, "fetch_repo", boom)
    response = client.post(
        "/analyze", json={"repository_url": "https://github.com/demo/slow-repo"}
    )
    assert response.status_code == 504
    assert response.json()["error"]["code"] == "ANALYSIS_TIMEOUT"
