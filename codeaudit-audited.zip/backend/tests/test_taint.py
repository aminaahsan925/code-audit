"""Tests for lightweight source-to-sink tracing (Phase 3, §7.3).

Taint analysis never creates or suppresses findings: it only attaches a
``taint_trace`` note and raises confidence to HIGH when the untrusted
origin is concrete (TAINTED). UNKNOWN origins are reported as explicit
uncertainty with confidence unchanged; CLEAN (literal) arguments get no note.
"""

from __future__ import annotations

from models.schemas import Confidence, Severity
from services.languages.registry import get_analyzer
from services.languages.taint import (
    TaintStatus,
    apply_taint,
    trace_js_sink,
    trace_python_sink,
)
from services.static_analyzer import analyze_content

PY = get_analyzer("python")
JS = get_analyzer("javascript")


def _py_finding(source: str, detector: str):
    findings = analyze_content("t.py", source)
    matches = [f for f in findings if f.detector == detector]
    assert len(matches) == 1, f"expected 1 {detector}, got {len(matches)}"
    return matches[0]


def _js_finding(source: str, detector: str):
    findings = JS.analyze_file("t.js", source)
    matches = [f for f in findings if f.detector == detector]
    assert len(matches) == 1, f"expected 1 {detector}, got {len(matches)}"
    return matches[0]


# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------

def test_python_param_to_sql_is_tainted_and_raises_confidence():
    f = _py_finding(
        "def get(uid, cur):\n    cur.execute('SELECT ' + uid)\n",
        "sql_string_construction",
    )
    assert f.confidence == Confidence.HIGH  # raised from MEDIUM
    assert f.taint_trace is not None
    assert "'uid'" in f.taint_trace and "parameter" in f.taint_trace


def test_python_request_attr_to_sql_is_tainted():
    f = _py_finding(
        "from flask import request\n"
        "def get(cur):\n"
        "    cur.execute('SELECT ' + request.args.get('q'))\n",
        "sql_string_construction",
    )
    assert f.confidence == Confidence.HIGH
    assert f.taint_trace is not None and "request" in f.taint_trace


def test_python_param_to_os_system_is_tainted():
    f = _py_finding(
        "import os\ndef greet(name):\n    os.system('echo ' + name)\n",
        "os_system",
    )
    assert f.taint_trace is not None and "'name'" in f.taint_trace
    assert f.confidence == Confidence.HIGH  # already HIGH: unchanged


def test_python_param_to_eval_is_tainted():
    f = _py_finding("def calc(e):\n    return eval(e)\n", "dangerous_eval")
    assert f.taint_trace is not None and "'e'" in f.taint_trace


def test_python_module_level_name_is_uncertain_not_tainted():
    f = _py_finding("cur.execute('SELECT ' + table)\n", "sql_string_construction")
    # 'table' has no literal value or recognized source: uncertainty, no raise.
    assert f.taint_trace is not None and "uncertain" in f.taint_trace
    assert f.confidence == Confidence.MEDIUM


def test_python_constant_eval_gets_no_taint_note():
    f = _py_finding("x = eval('1 + 2')\n", "dangerous_eval")
    assert f.taint_trace is None
    assert f.confidence == Confidence.MEDIUM


def test_python_subprocess_shell_taint():
    f = _py_finding(
        "import subprocess\ndef ls(d):\n    subprocess.run('ls ' + d, shell=True)\n",
        "subprocess_shell_true",
    )
    assert f.taint_trace is not None and "'d'" in f.taint_trace


# ---------------------------------------------------------------------------
# JavaScript
# ---------------------------------------------------------------------------

def test_js_req_query_to_sql_is_tainted_and_raises_confidence():
    f = _js_finding(
        "function get(req, db) {\n"
        "  return db.query(`SELECT * FROM t WHERE id = ${req.query.id}`);\n"
        "}\n",
        "js_sql_string_construction",
    )
    assert f.confidence == Confidence.HIGH  # raised from MEDIUM
    assert f.taint_trace is not None and "req." in f.taint_trace


def test_js_param_to_exec_is_tainted():
    f = _js_finding(
        "const cp = require('child_process');\n"
        "function ls(dir, cb) {\n"
        "  cp.exec('ls ' + dir, { shell: true }, cb);\n"
        "}\n",
        "js_command_injection",
    )
    assert f.taint_trace is not None and "'dir'" in f.taint_trace


def test_js_process_argv_is_tainted():
    f = _js_finding(
        "const cp = require('child_process');\n"
        "cp.exec('ls ' + process.argv[2], { shell: true }, () => {});\n",
        "js_command_injection",
    )
    assert f.taint_trace is not None and "process.argv" in f.taint_trace


def test_js_top_level_name_is_uncertain():
    f = _js_finding(
        "db.query(`SELECT * FROM t WHERE a = ${x}`);\n",
        "js_sql_string_construction",
    )
    assert f.taint_trace is not None and "uncertain" in f.taint_trace
    assert f.confidence == Confidence.MEDIUM  # unchanged


# ---------------------------------------------------------------------------
# apply_taint invariants
# ---------------------------------------------------------------------------

def test_apply_taint_never_changes_severity_or_downgrades():
    f = _py_finding(
        "def get(uid, cur):\n    cur.execute('SELECT ' + uid)\n",
        "sql_string_construction",
    )
    assert f.severity == Severity.HIGH  # untouched by taint
    # Idempotent: applying again does not escalate further or duplicate notes.
    again = apply_taint(f, _trace_again(f))
    assert again.confidence == Confidence.HIGH
    assert again.taint_trace == f.taint_trace


def _trace_again(f):
    import ast

    tree = ast.parse("def get(uid, cur):\n    cur.execute('SELECT ' + uid)\n")
    node = next(
        n
        for n in ast.walk(tree)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Attribute)
        and n.func.attr == "execute"
    )
    from services.languages.taint import trace_python_sink

    return trace_python_sink(tree, node, node.args[0])


def test_taint_result_statuses_are_stable():
    import ast

    tree = ast.parse("def f(a):\n    eval(a)\n")
    node = next(n for n in ast.walk(tree) if isinstance(n, ast.Call))
    r = trace_python_sink(tree, node, node.args[0])
    assert r.status == TaintStatus.TAINTED
    r2 = trace_python_sink(tree, node, ast.Constant(value="x"))
    assert r2.status == TaintStatus.CLEAN and r2.note is None
