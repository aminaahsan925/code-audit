"""Tests for Phase 5: knowledge-only RAG + bounded multi-agent reasoning.

Guards:
  * the curated KB loads deterministically (45 entries, all 39 registry
    rules covered, sorted by id)
  * retrieval is tag-first (rule > cwe > language > text), deterministic,
    and bounded (max chunks, max chars)
  * sensitive findings get NO retrieval (Phase 4 guarantee preserved)
  * retrieval is knowledge-ONLY: it never creates/suppresses findings;
    the evidence hard gate still decides existence
  * evidence agent: knowledge shown in the prompt is stamped as
    knowledge_used on enriched findings; sensitive findings get no section
  * fix agent: knowledge in fix context, knowledge_used stamped,
    knowledge_cited validated against what was shown (invented ids dropped)
  * reasoning budgets: caps trip with a logged warning; no provider call
    happens past the cap
  * reports attribute knowledge citations
"""

from __future__ import annotations

import logging

from agents.contracts import AgentContext
from agents.evidence_agent import EvidenceAgent
from agents.fix_agent import FixAgent
from agents.reasoning_bounds import (
    REASONING_STEPS_EXHAUSTED,
    ReasoningBudget,
)
from app.config import Settings
from models.schemas import (
    Category,
    Confidence,
    Finding,
    FindingSource,
    FixDecision,
    FixProposal,
    RepositoryMetadata,
    Severity,
    ValidatedFinding,
)
from services.knowledge import (
    format_knowledge_block,
    load_knowledge_base,
    reset_cache,
    reset_index_cache,
    retrieve_for_finding,
)
from services.knowledge.entries import KnowledgeEntry
from services.languages.rule_registry import all_rules
from services.prompts.evidence_review import build_evidence_review_messages
from services.prompts.fix_prompt import build_fix_messages
from services.fix_context_builder import build_fix_context
from services.report_generator import ReportGenerator
from services.repository_scanner import ScanResult
from tests.fakes import FakeAIProvider

REPO = RepositoryMetadata(owner="demo", name="kb_demo", url="file://demo")

SQLI_LINE = 'cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")'


def _finding(**overrides) -> Finding:
    params = dict(
        id="sql_string_construction:app.py:23",
        detector="sql_string_construction",
        title="SQL string construction",
        description="query built with f-string",
        category=Category.SECURITY,
        severity=Severity.HIGH,
        confidence=Confidence.MEDIUM,
        file="app.py",
        line=23,
        evidence=SQLI_LINE,
        source=FindingSource.DETERMINISTIC,
        rule_id="PY-SEC-002",
        cwe_ids=["CWE-89"],
        language="python",
    )
    params.update(overrides)
    return Finding(**params)


def _validated(**overrides) -> ValidatedFinding:
    return ValidatedFinding(**_finding(**overrides).model_dump())


def _scan() -> ScanResult:
    return ScanResult(contents={"app.py": "\n".join(["# line"] * 22 + [SQLI_LINE])})


def _ctx(**overrides) -> AgentContext:
    ctx = AgentContext(
        execution_id="kb-test",
        repository=REPO,
        mode="economy",
        scan=_scan(),
        validated_findings=[],
    )
    for key, value in overrides.items():
        setattr(ctx, key, value)
    return ctx


# ---------------------------------------------------------------------------
# 1. Knowledge base loading
# ---------------------------------------------------------------------------


def test_kb_loads_with_expected_size_and_order():
    reset_cache()
    kb = load_knowledge_base()
    assert kb.version == "kb-v2"
    assert len(kb.entries) == 57  # 45 (kb-v1) + 12 live-scan rules
    ids = [e.id for e in kb.entries]
    assert ids == sorted(ids), "KB entries must be deterministically ordered"
    assert len(set(ids)) == len(ids), "KB entry ids must be unique"
    for entry in kb.entries:
        assert entry.id and entry.title and entry.body
        assert entry.source == "curated"
    # Deterministic across loads (cached path).
    assert [e.id for e in load_knowledge_base().entries] == ids


def test_kb_covers_every_registry_rule():
    kb = load_knowledge_base()
    covered = {r for e in kb.entries for r in e.rule_ids}
    registry = {r.rule_id for r in all_rules()}
    assert registry <= covered, f"rules without KB guidance: {sorted(registry - covered)}"


def test_kb_entry_lookup():
    kb = load_knowledge_base()
    entry = kb.by_id("KB-PY-SEC-002")
    assert isinstance(entry, KnowledgeEntry)
    assert "PY-SEC-002" in entry.rule_ids
    assert kb.by_id("KB-DOES-NOT-EXIST") is None


# ---------------------------------------------------------------------------
# 2. Retrieval: ranking, determinism, bounds
# ---------------------------------------------------------------------------


def test_retrieval_prefers_exact_rule_match():
    hits = retrieve_for_finding(_finding())
    assert hits, "expected at least the rule's own entry"
    assert hits[0].entry.id == "KB-PY-SEC-002"
    assert hits[0].matched_on == "rule"


def test_retrieval_cwe_tier_after_rule():
    hits = retrieve_for_finding(_finding())
    tiers = [h.matched_on for h in hits]
    # rule tier first; cwe tier (KB-JS-SEC-007, KB-GEN-001 share CWE-89) next.
    assert tiers[0] == "rule"
    assert "cwe" in tiers[1:], f"tiers: {tiers}"


def test_retrieval_is_deterministic():
    reset_index_cache()
    first = [h.entry.id for h in retrieve_for_finding(_finding())]
    reset_index_cache()
    second = [h.entry.id for h in retrieve_for_finding(_finding())]
    assert first == second


def test_retrieval_respects_chunk_and_char_caps():
    from dataclasses import replace

    cfg = replace(Settings(), kb_max_chunks_per_finding=1)
    hits = retrieve_for_finding(_finding(), cfg=cfg)
    assert len(hits) == 1
    assert hits[0].entry.id == "KB-PY-SEC-002"

    cfg2 = replace(Settings(), kb_max_chars=300)
    hits2 = retrieve_for_finding(_finding(), cfg=cfg2)
    total = sum(len(h.excerpt) for h in hits2)
    assert total <= 300, f"char cap violated: {total}"


def test_retrieval_needs_text_signal_below_rule_tier():
    # No rule/cwe/language overlap and no shared vocabulary: nothing padded.
    f = _finding(
        rule_id=None,
        cwe_ids=[],
        language="cobol",
        detector="mystery",
        title="zqxw jumbled",
        description="zqxw jumbled vbnm",
    )
    assert retrieve_for_finding(f) == []


def test_pure_text_similarity_never_qualifies_without_tag_or_language():
    # Even with vocabulary overlapping KB bodies ("query", "eval"), a
    # finding with no rule_id, no CWE, and no language overlap gets no
    # guidance: pure text similarity is too weak a signal to cite.
    f = _finding(
        rule_id=None,
        cwe_ids=[],
        language="cobol",
        detector="mystery",
        title="query eval database",
        description="query eval database subprocess shell",
    )
    assert retrieve_for_finding(f) == []


def test_sensitive_findings_get_no_retrieval():
    f = _finding(sensitive=True)
    assert retrieve_for_finding(f) == []


def test_format_knowledge_block_labels_guidance_only():
    hits = retrieve_for_finding(_finding())
    block = format_knowledge_block(hits)
    assert "guidance only" in block.lower()
    assert "[KB-PY-SEC-002]" in block
    assert "Never invent entry ids" in block


# ---------------------------------------------------------------------------
# 3. Knowledge-only boundary: retrieval never decides findings
# ---------------------------------------------------------------------------


def test_retrieval_does_not_mutate_findings():
    f = _finding()
    before = f.model_dump()
    retrieve_for_finding(f)
    assert f.model_dump() == before
    assert f.knowledge_used == []


def test_evidence_agent_stamps_knowledge_used_on_enriched_findings():
    vf = _validated()
    ctx = _ctx(validated_findings=[vf])
    fake = FakeAIProvider()
    agent = EvidenceAgent(provider=fake, cache=None)
    outcome = agent.run(ctx, [])
    assert outcome.status == "enabled"
    target = next(f for f in outcome.enriched if f.id == vf.id)
    assert "KB-PY-SEC-002" in target.knowledge_used
    # The prompt the model saw carried the guidance block with citations.
    user_msg = fake.received_context.message_builder(None)[1]["content"]
    assert "CURATED REMEDIATION KNOWLEDGE" in user_msg
    assert "[KB-PY-SEC-002]" in user_msg
    # Deterministic anchors untouched by knowledge.
    assert target.evidence == SQLI_LINE
    assert target.severity == Severity.HIGH


def test_evidence_agent_gives_sensitive_findings_no_knowledge_section():
    vf = _validated(sensitive=True, evidence="AKI****MPLE")
    ctx = _ctx(validated_findings=[vf])
    fake = FakeAIProvider()
    agent = EvidenceAgent(provider=fake, cache=None)
    outcome = agent.run(ctx, [])
    assert outcome.status == "enabled"
    target = next(f for f in outcome.enriched if f.id == vf.id)
    assert target.knowledge_used == []
    user_msg = fake.received_context.message_builder(None)[1]["content"]
    assert "CURATED REMEDIATION KNOWLEDGE" not in user_msg


def test_evidence_review_message_builder_knowledge_is_optional():
    base = build_evidence_review_messages("brief", "findings", "excerpts", "v1")
    with_kb = build_evidence_review_messages(
        "brief", "findings", "excerpts", "v1", knowledge_block="KNOWLEDGE"
    )
    assert "KNOWLEDGE" not in base[1]["content"]
    assert "KNOWLEDGE" in with_kb[1]["content"]


# ---------------------------------------------------------------------------
# 4. Fix agent: knowledge in context, validated citations
# ---------------------------------------------------------------------------


def _fix_proposal(**overrides) -> FixProposal:
    params = dict(
        finding_id="sql_string_construction:app.py:23",
        decision=FixDecision.FIX,
        reasoning="parameterize the query",
        changes=[
            {
                "file": "app.py",
                "start_line": 23,
                "end_line": 23,
                "old_text": SQLI_LINE,
                "new_text": 'cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))',
            }
        ],
        expected_effect="no injection",
        verification_notes="rerun analyzer",
    )
    params.update(overrides)
    return FixProposal(**params)


def test_fix_context_carries_knowledge():
    ctx = build_fix_context(_finding(), _scan().contents)
    assert ctx.knowledge, "expected knowledge hits for a rule-tagged finding"
    assert ctx.knowledge[0].entry.id == "KB-PY-SEC-002"
    assert ctx.budget["knowledge_ids"][0] == "KB-PY-SEC-002"


def test_fix_context_has_no_knowledge_for_sensitive_findings():
    ctx = build_fix_context(_finding(sensitive=True), _scan().contents)
    assert ctx.knowledge == []


def test_fix_messages_include_knowledge_block_with_citation_rules():
    ctx = build_fix_context(_finding(), _scan().contents)
    messages = build_fix_messages(_finding(), ctx)
    user_msg = messages[1]["content"]
    assert "CURATED REMEDIATION KNOWLEDGE" in user_msg
    assert "[KB-PY-SEC-002]" in user_msg
    assert "knowledge_cited" in user_msg
    assert "never invent ids" in user_msg.lower()


def test_fix_agent_stamps_knowledge_used_and_validates_citations():
    vf = _validated()
    ctx = _ctx()
    # The model cites one genuine entry and one invented id.
    proposal = _fix_proposal(knowledge_cited=["KB-PY-SEC-002", "KB-FAKE-999"])
    fake = FakeAIProvider(fix_proposal=proposal)
    agent = FixAgent(provider=fake, cache=None)
    outcome = agent.propose(vf, ctx, contents=_scan().contents)
    assert outcome.status == "ok"
    assert outcome.proposal is not None
    # System truth: everything shown.
    assert "KB-PY-SEC-002" in outcome.proposal.knowledge_used
    # Model claim: invented ids dropped.
    assert outcome.proposal.knowledge_cited == ["KB-PY-SEC-002"]


def test_fix_agent_sensitive_finding_gets_no_knowledge():
    vf = _validated(sensitive=True, evidence="AKI****MPLE")
    ctx = _ctx()
    fake = FakeAIProvider(fix_proposal=_fix_proposal())
    agent = FixAgent(provider=fake, cache=None)
    outcome = agent.propose(vf, ctx, contents=_scan().contents)
    assert outcome.status == "ok"
    assert outcome.proposal is not None
    assert outcome.proposal.knowledge_used == []
    assert outcome.proposal.knowledge_cited == []


# ---------------------------------------------------------------------------
# 5. Bounded reasoning
# ---------------------------------------------------------------------------


def test_reasoning_budget_caps_steps_and_logs_once(caplog):
    budget = ReasoningBudget(agent_name="test_agent", max_steps=1)
    assert budget.take_step("first") is True
    with caplog.at_level(logging.WARNING, logger="agents.reasoning_bounds"):
        assert budget.take_step("second") is False
        assert budget.take_step("third") is False  # still False, logged once
    warnings = [
        r for r in caplog.records
        if "Reasoning budget exhausted" in r.getMessage()
    ]
    assert len(warnings) == 1
    assert budget.remaining() == 0


def test_evidence_agent_respects_exhausted_reasoning_budget():
    vf = _validated()
    ctx = _ctx(validated_findings=[vf])
    fake = FakeAIProvider()
    spent = ReasoningBudget(agent_name="evidence_agent", max_steps=1)
    assert spent.take_step("prior")  # exhaust it before the run
    agent = EvidenceAgent(provider=fake, cache=None, reasoning_budget=spent)
    outcome = agent.run(ctx, [])
    assert outcome.status == "budget_exhausted"
    assert fake.investigate_calls == 0, "no provider call past the step cap"
    assert REASONING_STEPS_EXHAUSTED in outcome.execution_metadata.errors


def test_evidence_agent_single_shot_cannot_double_call():
    vf = _validated()
    ctx = _ctx(validated_findings=[vf])
    fake = FakeAIProvider()
    agent = EvidenceAgent(provider=fake, cache=None)
    first = agent.run(ctx, [])
    assert first.status == "enabled"
    assert fake.investigate_calls == 1
    # Same agent instance reused with a cache-busting second finding: a
    # genuine second reasoning attempt must trip the spent step budget.
    vf2 = _validated(id="sql_string_construction:app.py:24", line=24)
    ctx2 = _ctx(validated_findings=[vf2])
    second = agent.run(ctx2, [])
    assert second.status == "budget_exhausted"
    assert second.execution_metadata.errors == [REASONING_STEPS_EXHAUSTED]
    assert fake.investigate_calls == 1


# ---------------------------------------------------------------------------
# 6. Report attribution
# ---------------------------------------------------------------------------


def _analysis_result():
    from models.schemas import (
        AnalysisResult,
        AnalysisSummary,
        RepositoryMetadata,
        RiskBreakdown,
        RiskResult,
    )

    finding = _validated(knowledge_used=["KB-PY-SEC-002", "KB-GEN-001"])
    return AnalysisResult(
        repository=REPO,
        summary=AnalysisSummary(
            files_discovered=1,
            files_scanned=1,
            files_deep_analyzed=1,
            files_unsupported=0,
            files_skipped=0,
            files_failed_parse=0,
            findings_total=1,
            findings_by_severity={"high": 1},
            findings_by_category={"security": 1},
        ),
        risk=RiskResult(
            score=5,
            level="medium",
            breakdown=RiskBreakdown(
                severity_weights={},
                confidence_factors={},
                reachability_factors={},
                findings_counted=1,
                total_weighted_points=1.0,
            ),
        ),
        findings=[finding],
    )


def test_report_attributes_knowledge_citations():
    md = ReportGenerator().to_markdown(_analysis_result())
    assert "Knowledge consulted" in md
    assert "[KB-PY-SEC-002]" in md
    assert "[KB-GEN-001]" in md
    assert "not evidence" in md


def test_report_omits_knowledge_line_when_none_used():
    result = _analysis_result()
    result.findings[0].knowledge_used = []
    md = ReportGenerator().to_markdown(result)
    assert "Knowledge consulted" not in md


def test_fusion_preserves_knowledge_used_from_evidence_enrichment():
    """Regression: fusion must carry knowledge_used onto final findings."""
    from agents.contracts import AgentExecutionMetadata
    from agents.evidence_agent import EvidenceAgentResult
    from agents.finding_fusion_agent import FindingFusionAgent

    vf = _validated()
    ctx = _ctx(validated_findings=[vf])
    enriched = vf.model_copy(
        update={
            "knowledge_used": ["KB-PY-SEC-002"],
            "ai_reasoning": "evidence shows f-string SQL",
        }
    )
    evidence = EvidenceAgentResult(
        enriched=[enriched],
        status="enabled",
        execution_metadata=AgentExecutionMetadata(agent_name="evidence_agent"),
    )
    fused = FindingFusionAgent().fuse(ctx, None, evidence)
    target = next(f for f in fused.findings if f.id == vf.id)
    assert target.knowledge_used == ["KB-PY-SEC-002"]
    # Deterministic anchor still preserved.
    assert target.evidence == SQLI_LINE
