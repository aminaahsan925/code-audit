"""Phase 9 tests: fingerprinted findings endpoints + frontend static checks.

Covers the two endpoints added for the demo frontend's lifecycle UI:
  GET /analyses/{analysis_id}/findings
  GET /website-scans/{scan_id}/findings
Each returns [{fingerprint, finding}] with the stable retest fingerprint.
"""

from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

import app.main as app_main
from services import retest as retest_lib
from services.persistence import database as persistence_db
from services.persistence import repository as persistence_repo


@pytest.fixture()
def db_url(tmp_path: Path) -> str:
    return f"sqlite:///{tmp_path}/test.db"


@pytest.fixture()
def app_settings(monkeypatch, db_url: str):
    from dataclasses import fields

    real = app_main.settings
    ns = SimpleNamespace(**{f.name: getattr(real, f.name) for f in fields(real)})
    ns.database_url = db_url
    monkeypatch.setattr(app_main, "settings", ns)
    persistence_db.reset_engine_cache()
    persistence_db.init_db(db_url)
    yield ns
    persistence_db.reset_engine_cache()
    app_main._JOB_SECRETS.clear()


@pytest.fixture()
def factory(app_settings, db_url: str):
    return persistence_db.get_session_factory(db_url)


@pytest.fixture()
def client() -> TestClient:
    return TestClient(app_main.app)


def _make_user(factory, name="u", scopes=("admin",)):
    with factory() as session:
        user = persistence_repo.create_user(session, name)
        record, plaintext = persistence_repo.create_api_key(
            session, user.id, name=f"{name}-key", scopes=list(scopes)
        )
        session.commit()
        return user.id, record.id, plaintext


def _auth(plaintext: str) -> dict:
    return {"X-API-Key": plaintext}


FINDINGS = [
    {
        "rule_id": "PY-SEC-007",
        "title": "os.system with user input",
        "severity": "high",
        "file": "app.py",
        "line": 42,
        "evidence": "os.system(user_input)",
        "description": "d",
        "confidence": "high",
        "source": "deterministic",
    },
    {
        "rule_id": "PY-SEC-001",
        "title": "hardcoded secret",
        "severity": "critical",
        "file": "config.py",
        "line": 7,
        "evidence": "API_KEY = 'x'",
        "description": "d",
        "confidence": "high",
        "source": "deterministic",
    },
]

SCAN_FINDINGS = [
    {
        "rule_id": "WS-MISSING-HSTS",
        "title": "Missing HSTS header",
        "severity": "medium",
        "url": "https://example.com/",
        "evidence": "no strict-transport-security header",
        "description": "d",
        "confidence": "high",
        "source": "deterministic",
    }
]


def _seed_analysis(factory, user_id, findings):
    with factory() as session:
        analysis = persistence_repo.record_repo_analysis(
            session,
            user_id=user_id,
            project_id=None,
            repository_url="https://github.com/o/r",
            findings=findings,
            risk_score=7.0,
            summary={},
        )
        session.commit()
        return analysis.id


def _seed_scan(factory, user_id, findings):
    with factory() as session:
        scan = persistence_repo.record_website_scan(
            session,
            user_id=user_id,
            project_id=None,
            target_url="https://example.com/",
            findings=findings,
            urls_scanned=3,
            truncated=False,
            summary={},
        )
        session.commit()
        return scan.id


def test_analysis_findings_fingerprints(client, factory):
    user_id, _, plaintext = _make_user(factory)
    aid = _seed_analysis(factory, user_id, FINDINGS)
    r = client.get(f"/analyses/{aid}/findings", headers=_auth(plaintext))
    assert r.status_code == 200, r.text
    items = r.json()
    assert len(items) == 2
    for item, finding in zip(items, FINDINGS):
        assert set(item) == {"fingerprint", "finding"}
        fp = item["fingerprint"]
        assert len(fp) == 32 and all(c in "0123456789abcdef" for c in fp)
        assert fp == retest_lib.finding_fingerprint(finding)
        assert item["finding"]["rule_id"] == finding["rule_id"]
        assert item["finding"]["evidence"] == finding["evidence"]


def test_analysis_findings_tenant_isolated(client, factory):
    owner_id, _, _ = _make_user(factory, name="owner")
    _, _, intruder_key = _make_user(factory, name="intruder")
    aid = _seed_analysis(factory, owner_id, FINDINGS)
    r = client.get(f"/analyses/{aid}/findings", headers=_auth(intruder_key))
    assert r.status_code == 404, r.text


def test_analysis_findings_404(client, factory):
    _, _, plaintext = _make_user(factory)
    r = client.get("/analyses/does-not-exist/findings", headers=_auth(plaintext))
    assert r.status_code == 404


def test_website_scan_findings_fingerprints(client, factory):
    user_id, _, plaintext = _make_user(factory)
    sid = _seed_scan(factory, user_id, SCAN_FINDINGS)
    r = client.get(f"/website-scans/{sid}/findings", headers=_auth(plaintext))
    assert r.status_code == 200, r.text
    items = r.json()
    assert len(items) == 1
    assert items[0]["fingerprint"] == retest_lib.finding_fingerprint(SCAN_FINDINGS[0])
    assert items[0]["finding"]["url"] == "https://example.com/"


def test_website_scan_findings_tenant_isolated(client, factory):
    owner_id, _, _ = _make_user(factory, name="owner2")
    _, _, intruder_key = _make_user(factory, name="intruder2")
    sid = _seed_scan(factory, owner_id, SCAN_FINDINGS)
    r = client.get(f"/website-scans/{sid}/findings", headers=_auth(intruder_key))
    assert r.status_code == 404, r.text


def test_website_scan_findings_404(client, factory):
    _, _, plaintext = _make_user(factory)
    r = client.get("/website-scans/does-not-exist/findings", headers=_auth(plaintext))
    assert r.status_code == 404


def test_fingerprint_survives_line_shift():
    """Line numbers are excluded so findings survive line shifts."""
    a = dict(FINDINGS[0], line=42)
    b = dict(FINDINGS[0], line=99)
    assert retest_lib.finding_fingerprint(a) == retest_lib.finding_fingerprint(b)
    c = dict(FINDINGS[0], evidence="os.system(other)")
    assert retest_lib.finding_fingerprint(a) != retest_lib.finding_fingerprint(c)


# ---------------------------------------------------------------------------
# Frontend static checks: the demo UI is three static files with no build.
# ---------------------------------------------------------------------------

FE = Path(__file__).resolve().parents[2] / "frontend"


def test_frontend_files_present():
    for name in ("index.html", "styles.css", "app.js", "README.md"):
        assert (FE / name).is_file(), name


def test_frontend_references_expected_endpoints():
    js = (FE / "app.js").read_text()
    for endpoint in (
        "/health",
        "/analyze",
        "/scan/website",
        "/projects",
        "/jobs/",
        "/findings/status",
        "/retest",
        "/findings",
    ):
        assert endpoint in js, endpoint


def test_frontend_escapes_dynamic_content():
    """Finding cards must HTML-escape every dynamic string (evidence is code)."""
    js = (FE / "app.js").read_text()
    # esc() is applied to title/evidence/description/file/url/severity etc.
    for needle in ("esc(f.title", "esc(f.evidence", "esc(f.description", "esc(f.file", "esc(f.url"):
        assert needle in js, needle


def test_frontend_does_not_persist_scan_token():
    """The per-host scan token must never be written to localStorage."""
    js = (FE / "app.js").read_text()
    assert "scanToken" in js
    # only backend URL + API key may be persisted
    assert "ca_backend" in js and "ca_key" in js
    assert js.count("localStorage.setItem") == 2, js.count("localStorage.setItem")


def test_frontend_js_syntax():
    import subprocess

    r = subprocess.run(
        ["node", "--check", str(FE / "app.js")], capture_output=True, text=True
    )
    assert r.returncode == 0, r.stderr


def test_ui_mount_serves_frontend(client):
    """/ui serves the demo frontend when the frontend/ directory is present."""
    r = client.get("/ui/")
    assert r.status_code == 200, r.status_code
    assert "CodeAudit Agent" in r.text
    assert "text/html" in r.headers["content-type"]
    js = client.get("/ui/app.js")
    assert js.status_code == 200
    assert "checkHealth" in js.text
    css = client.get("/ui/styles.css")
    assert css.status_code == 200
