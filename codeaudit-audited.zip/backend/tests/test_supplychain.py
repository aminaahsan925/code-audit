"""Phase 4: supply-chain scanning — dependencies, secrets, config, SBOM.

Hermetic: every test uses synthetic fixtures and tmp paths. No network.
The advisory DB fixtures are synthetic (benchpkg / benchjs); nothing here
is a real CVE and the tests assert no vulnerability is ever fabricated.
"""

from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from models.schemas import (
    Category,
    Confidence,
    Finding,
    FindingSource,
    RepositoryMetadata,
    Severity,
)
from services import finding_validator
from services.ai_context_builder import build_ai_context
from services.fix_context_builder import build_fix_context
from services.repository_scanner import ScanResult
from services.supplychain import (
    analyze_compose,
    analyze_dependencies,
    analyze_dockerfile,
    analyze_github_workflow,
    analyze_secrets,
    analyze_supplychain_file,
    build_sbom_for_scan,
    get_advisory_source,
    parse_manifest_file,
    supplychain_covered_files,
)
from services.supplychain.advisories import LocalAdvisoryDB
from services.supplychain.redaction import redact_line, redact_secret_value


# --- Synthetic advisory DB ---------------------------------------------------

SYNTHETIC_DB = {
    "source": "test-fixture",
    "generated_at": "2026-10-02T00:00:00+00:00",
    "advisories": [
        {
            "id": "CVE-2024-00001",
            "package": "benchpkg",
            "ecosystem": "pypi",
            "affected_spec": ">=0,<2.0.0",
            "fixed_version": "2.0.0",
            "published": "2024-01-01T00:00:00Z",
            "severity": "HIGH",
            "summary": "Synthetic test advisory.",
        },
        {
            "id": "GHSA-test-0001",
            "package": "benchjs",
            "ecosystem": "npm",
            "affected_spec": ">=1.0.0 <1.5.2",
            "fixed_version": "1.5.2",
            "published": "2024-01-01T00:00:00Z",
            "severity": "MEDIUM",
            "summary": "Synthetic test advisory.",
        },
    ],
}


@pytest.fixture()
def advisory_db(tmp_path: Path) -> LocalAdvisoryDB:
    path = tmp_path / "advisories.json"
    path.write_text(json.dumps(SYNTHETIC_DB), encoding="utf-8")
    return LocalAdvisoryDB(str(path), max_age_days=36500)


# --- Manifest parsers --------------------------------------------------------


def test_parse_requirements_txt():
    deps, err = parse_manifest_file(
        "requirements.txt", "benchpkg==1.0.0\nloosedep\n# comment\n"
    )
    assert err is None
    by_name = {d.name: d for d in deps}
    assert by_name["benchpkg"].pinned_version == "1.0.0"
    assert by_name["benchpkg"].ecosystem == "pypi"
    assert by_name["loosedep"].pinned_version is None
    assert all(d.direct for d in deps)


def test_parse_setup_py_uses_ast_never_executes():
    content = (
        "import os\n"
        "os.system('echo pwned')\n"  # must never execute
        "from setuptools import setup\n"
        'setup(name="demo", install_requires=["benchpkg>=1.0", "other"])\n'
    )
    deps, err = parse_manifest_file("setup.py", content)
    assert err is None
    assert {d.name for d in deps} == {"benchpkg", "other"}


def test_parse_pyproject_toml():
    content = (
        "[project]\nname = \"demo\"\ndependencies = [\"benchpkg==1.0.0\"]\n"
        "[project.optional-dependencies]\ntest = [\"pytest==8.0.0\"]\n"
    )
    deps, err = parse_manifest_file("pyproject.toml", content)
    assert err is None
    assert {d.name for d in deps} == {"benchpkg", "pytest"}


def test_parse_pipfile_and_lock():
    deps, err = parse_manifest_file(
        "Pipfile", '[packages]\nbenchpkg = "==1.0.0"\n'
    )
    assert err is None
    assert deps[0].pinned_version == "1.0.0"
    lock = json.dumps({"default": {"benchpkg": {"version": "==1.0.0"}}})
    deps, err = parse_manifest_file("Pipfile.lock", lock)
    assert err is None
    assert deps[0].pinned_version == "1.0.0"
    assert deps[0].from_lockfile


def test_parse_package_json_and_lock():
    deps, err = parse_manifest_file(
        "package.json",
        json.dumps({"dependencies": {"benchjs": "^1.2.0"}}),
    )
    assert err is None
    assert deps[0].name == "benchjs"
    assert deps[0].ecosystem == "npm"
    lock = json.dumps(
        {"packages": {"node_modules/benchjs": {"version": "1.2.3"}}}
    )
    deps, err = parse_manifest_file("package-lock.json", lock)
    assert err is None
    assert deps[0].pinned_version == "1.2.3"


def test_manifest_parse_errors_never_raise():
    for name, content in [
        ("Pipfile.lock", "{nope"),
        ("package.json", "{nope"),
        ("pyproject.toml", "[unclosed"),
        ("setup.py", "def broken(:\n"),
        ("requirements.txt", "ok==1.0\n"),
    ]:
        deps, err = parse_manifest_file(name, content)
        assert isinstance(deps, list)  # never raises


# --- Advisory DB: status and matching ----------------------------------------


def test_advisory_db_status_current_stale_unavailable(tmp_path: Path):
    fresh = tmp_path / "fresh.json"
    fresh.write_text(
        json.dumps({**SYNTHETIC_DB, "generated_at": "2026-10-02T00:00:00+00:00"}),
        encoding="utf-8",
    )
    assert LocalAdvisoryDB(str(fresh), max_age_days=36500).status == "current"

    stale = tmp_path / "stale.json"
    stale.write_text(
        json.dumps({**SYNTHETIC_DB, "generated_at": "2020-01-01T00:00:00+00:00"}),
        encoding="utf-8",
    )
    assert LocalAdvisoryDB(str(stale), max_age_days=30).status == "stale"

    assert (
        LocalAdvisoryDB(str(tmp_path / "missing.json")).status == "unavailable"
    )
    broken = tmp_path / "broken.json"
    broken.write_text("{nope", encoding="utf-8")
    assert LocalAdvisoryDB(str(broken)).status == "unavailable"


def test_advisory_matching_pypi_and_npm(advisory_db: LocalAdvisoryDB):
    assert advisory_db.lookup("benchpkg", "1.0.0", "pypi")
    assert advisory_db.lookup("benchpkg", "2.0.0", "pypi") == []  # fixed
    assert advisory_db.lookup("benchjs", "1.2.0", "npm")
    assert advisory_db.lookup("benchjs", "1.5.2", "npm") == []  # fixed
    assert advisory_db.lookup("benchjs", "0.9.0", "npm") == []  # below range
    # Unparseable versions never match (no guessing).
    assert advisory_db.lookup("benchpkg", "not-a-version", "pypi") == []


# --- Dependency findings -----------------------------------------------------


def test_dep_001_fires_on_advisory_match(advisory_db: LocalAdvisoryDB):
    findings = analyze_dependencies(
        "requirements.txt", "benchpkg==1.0.0\n", advisory_db
    )
    vuln = [f for f in findings if f.detector == "dep_vulnerable_package"]
    assert len(vuln) == 1
    assert vuln[0].rule_id == "DEP-001"
    assert "CVE-2024-00001" in vuln[0].description
    assert "2.0.0" in vuln[0].description  # fixed version from the DB
    assert "advisory database status: current" in vuln[0].description.lower()


def test_dep_001_never_fabricates(advisory_db: LocalAdvisoryDB):
    # No advisory for this package -> no vulnerability finding, ever.
    findings = analyze_dependencies(
        "requirements.txt", "unknownpkg==1.0.0\n", advisory_db
    )
    assert not [f for f in findings if f.detector == "dep_vulnerable_package"]
    # Range-only specifiers are never matched against advisories.
    findings = analyze_dependencies(
        "requirements.txt", "benchpkg>=1.0\n", advisory_db
    )
    assert not [f for f in findings if f.detector == "dep_vulnerable_package"]


def test_dep_002_unpinned_only_when_fully_unpinned(advisory_db: LocalAdvisoryDB):
    findings = analyze_dependencies(
        "requirements.txt", "loosedep\nranged>=1.0\npinned==1.0\n", advisory_db
    )
    unpinned = [f for f in findings if f.detector == "dep_unpinned"]
    assert len(unpinned) == 1
    assert unpinned[0].rule_id == "DEP-002"
    assert unpinned[0].severity == Severity.LOW
    assert "loosedep" in unpinned[0].description


def test_dep_003_stale_and_unavailable_db(tmp_path: Path):
    stale = tmp_path / "stale.json"
    stale.write_text(
        json.dumps({**SYNTHETIC_DB, "generated_at": "2020-01-01T00:00:00+00:00"}),
        encoding="utf-8",
    )
    stale_db = LocalAdvisoryDB(str(stale), max_age_days=30)
    findings = analyze_dependencies("requirements.txt", "a==1.0\n", stale_db)
    status = [f for f in findings if f.detector == "dep_advisory_db_status"]
    assert len(status) == 1
    assert status[0].severity == Severity.INFO
    assert "stale" in status[0].title.lower()

    missing_db = LocalAdvisoryDB(str(tmp_path / "missing.json"))
    findings = analyze_dependencies("requirements.txt", "a==1.0\n", missing_db)
    status = [f for f in findings if f.detector == "dep_advisory_db_status"]
    assert len(status) == 1
    assert "unavailable" in status[0].title.lower()
    # Unavailable DB -> no vulnerability findings at all.
    assert not [f for f in findings if f.detector == "dep_vulnerable_package"]


def test_dep_004_manifest_parse_error(advisory_db: LocalAdvisoryDB):
    findings = analyze_dependencies("Pipfile.lock", "{nope", advisory_db)
    errors = [f for f in findings if f.detector == "dep_manifest_parse_error"]
    assert len(errors) == 1
    assert errors[0].rule_id == "DEP-004"


# --- Secrets -----------------------------------------------------------------


def test_secret_patterns_fire():
    cases = [
        ("secret_pem_key", "-----BEGIN RSA PRIVATE KEY-----\n"),
        ("secret_aws_key", "x = AKIA4KZ9QWERTYUIOPAB\n"),
        ("secret_github_token", "t = ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcd\n"),
        ("secret_google_api_key", "k = AIzaSyDdI0hCZtE6vySjMmWEfRq3t6Y7u8i9o0X\n"),
        ("secret_stripe_key", "k = sk-live-AbC123DeF456GhI789JkL0Mn\n"),
    ]
    for detector, content in cases:
        findings = analyze_secrets("config.txt", content)
        matched = [f for f in findings if f.detector == detector]
        assert len(matched) == 1, detector
        assert matched[0].sensitive is True


def test_secret_high_entropy():
    findings = analyze_secrets(
        ".env", 'API_KEY="X7qK9mZ2vB4nP6wE8rT1uY5"\n'
    )
    matched = [f for f in findings if f.detector == "secret_high_entropy"]
    assert len(matched) == 1
    # Low-entropy / short values stay silent.
    findings = analyze_secrets(".env", 'API_KEY="development"\n')
    assert not [f for f in findings if f.detector == "secret_high_entropy"]
    # Code files are owned by the language detectors.
    findings = analyze_secrets("app.py", 'API_KEY="X7qK9mZ2vB4nP6wE8rT1uY5"\n')
    assert not [f for f in findings if f.detector == "secret_high_entropy"]


def test_secret_placeholders_and_examples_stay_silent():
    for content in [
        "k = sk-test-***EXAMPLE***\n",
        "AWS_KEY=<redacted>\n",
        "t = ghp_EXAMPLE\n",
        'API_KEY="changeme"\n',
    ]:
        assert analyze_secrets("f.txt", content) == [], content


def test_secret_evidence_is_redacted():
    raw = "sk-live-AbC123DeF456GhI789JkL0Mn"
    findings = analyze_secrets("k.txt", f"key = {raw}\n")
    assert len(findings) == 1
    assert raw not in findings[0].evidence
    assert "****" in findings[0].evidence
    assert findings[0].sensitive is True


def test_redact_secret_value_shapes():
    assert redact_secret_value("sk-live-AbC123d456") == "sk-****d456"
    assert redact_secret_value("short") == "****"
    assert redact_secret_value("  quoted  ".strip()) == "****"
    assert "****" in redact_line("token=abc123XYZ", ["abc123XYZ"])
    assert "abc123XYZ" not in redact_line("token=abc123XYZ", ["abc123XYZ"])


def test_secret_language_attribution():
    findings = analyze_secrets("app.js", "k = sk-live-AbC123DeF456GhI789JkL0Mn\n")
    assert findings and findings[0].language == "javascript"
    findings = analyze_secrets("Dockerfile", "k = sk-live-AbC123DeF456GhI789JkL0Mn\n")
    assert findings and findings[0].language is None


def _scan(files: dict[str, str]) -> ScanResult:
    scan = ScanResult()
    for path in sorted(files):
        scan.files.append(
            SimpleNamespace(
                relative_path=path, language="python", size_bytes=len(files[path])
            )
        )
        scan.contents[path] = files[path]
    return scan


def _repo() -> RepositoryMetadata:
    return RepositoryMetadata(owner="o", name="r", url="https://github.com/o/r")


def _sensitive_finding() -> Finding:
    return Finding(
        id="secret_stripe_key:k.txt:1",
        category=Category.SECURITY,
        severity=Severity.HIGH,
        title="T",
        description="D",
        file="k.txt",
        line=1,
        evidence='key = "sk-****0Mn"',
        confidence=Confidence.HIGH,
        source=FindingSource.DETERMINISTIC,
        detector="secret_stripe_key",
        sensitive=True,
    )


def test_secrets_excluded_from_ai_context():
    raw_secret = "sk-live-AbC123DeF456GhI789JkL0Mn"
    files = {
        # The secret file would leak the raw value via source blocks.
        "k.txt": f'key = "{raw_secret}"\n',
        # A non-sensitive finding in a clean file is still included.
        "app.py": "x = eval(user_input)\n",
    }
    eval_finding = Finding(
        id="d:app.py:1",
        category=Category.SECURITY,
        severity=Severity.HIGH,
        title="T",
        description="D",
        file="app.py",
        line=1,
        evidence="x = eval(user_input)",
        confidence=Confidence.HIGH,
        source=FindingSource.DETERMINISTIC,
        detector="dangerous_eval",
    )
    context = build_ai_context(
        _scan(files), [], [eval_finding, _sensitive_finding()], _repo()
    )
    assert context.budget["findings_excluded_sensitive"] == 1
    assert all(not f.sensitive for f in context.findings)
    assert "k.txt" not in {b.path for b in context.file_blocks}
    for block in context.file_blocks:
        assert raw_secret not in block.text
    for text in context.finding_context.values():
        assert raw_secret not in text
    # The raw secret appears nowhere in the built AI context.
    assert raw_secret not in repr(context)


def test_fix_context_redacts_sensitive_windows():
    raw_secret = "sk-live-AbC123DeF456GhI789JkL0Mn"
    contents = {"k.txt": f"# header\nkey = \"{raw_secret}\"\n# footer\n"}
    ctx = build_fix_context(_sensitive_finding(), contents)
    assert raw_secret not in ctx.evidence_window
    # The evidence line itself carries the finding's redacted evidence.
    assert "****" in ctx.evidence_window


def test_language_detectors_defer_known_tokens():
    # A Stripe-shaped value in Python defers to SECRET-005: no double report.
    from services.languages.python_analyzer import PythonAnalyzer

    findings = PythonAnalyzer().analyze_file(
        "app.py", 'api_key = "sk-live-AbC123DeF456GhI789JkL0Mn"\n'
    )
    assert not [f for f in findings if f.detector == "hardcoded_secret"]
    # A non-token secret still fires the language detector (redacted).
    findings = PythonAnalyzer().analyze_file(
        "app.py", 'api_key = "k9QmZ2xV7bN4pL8wE3rT6yU"\n'
    )
    secrets = [f for f in findings if f.detector == "hardcoded_secret"]
    assert len(secrets) == 1
    assert secrets[0].sensitive is True
    assert "k9QmZ2xV7bN4pL8wE3rT6yU" not in secrets[0].evidence


# --- Config analyzers --------------------------------------------------------


DOCKERFILE_VULN = """\
FROM myapp:latest
ARG API_KEY=hunter2secret
ENV DB_PASSWORD=s3cr3tp4ssw0rd!
ADD https://example.com/big.tar.gz /opt/
RUN curl -fsSL https://example.com/install.sh | sh
CMD ["app"]
"""

DOCKERFILE_SAFE = """\
FROM myapp:1.2.3
USER app
COPY . /app
CMD ["app"]
"""


def test_dockerfile_checks():
    findings = analyze_dockerfile("Dockerfile", DOCKERFILE_VULN)
    by_detector: dict[str, list[Finding]] = {}
    for f in findings:
        by_detector.setdefault(f.detector, []).append(f)
    assert len(by_detector["cfg_docker_no_user"]) == 1
    assert len(by_detector["cfg_docker_latest_tag"]) == 1
    assert len(by_detector["cfg_docker_secret_env"]) == 2
    assert len(by_detector["cfg_docker_add"]) == 1
    assert len(by_detector["cfg_docker_curl_pipe"]) == 1
    assert by_detector["cfg_docker_no_user"][0].rule_id == "CFG-001"
    assert by_detector["cfg_docker_no_user"][0].severity == Severity.HIGH
    # Secret evidence is redacted.
    for f in by_detector["cfg_docker_secret_env"]:
        assert f.sensitive is True
        assert "hunter2secret" not in f.evidence
        assert "s3cr3tp4ssw0rd!" not in f.evidence
    assert analyze_dockerfile("Dockerfile", DOCKERFILE_SAFE) == []


GHA_VULN = """\
name: ci
on: pull_request_target
permissions: write-all
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: some/action@master
        run: echo hi
"""

GHA_SAFE = """\
name: ci
on: push
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683
"""


def test_github_workflow_checks():
    findings = analyze_github_workflow(".github/workflows/ci.yml", GHA_VULN)
    by_detector: dict[str, list[Finding]] = {}
    for f in findings:
        by_detector.setdefault(f.detector, []).append(f)
    assert len(by_detector["cfg_gha_write_all"]) == 1
    assert len(by_detector["cfg_gha_pull_request_target"]) == 1
    assert len(by_detector["cfg_gha_unpinned_action"]) == 2
    assert by_detector["cfg_gha_write_all"][0].rule_id == "CFG-010"
    assert analyze_github_workflow(".github/workflows/ci.yml", GHA_SAFE) == []


COMPOSE_VULN = """\
services:
  web:
    image: myapp:1.0
    privileged: true
    environment:
      DB_PASSWORD: s3cr3tp4ssw0rd!
"""

COMPOSE_SAFE = """\
services:
  web:
    image: myapp:1.0
    environment:
      APP_ENV: production
"""


def test_compose_checks():
    findings = analyze_compose("docker-compose.yml", COMPOSE_VULN)
    by_detector = {f.detector: f for f in findings}
    assert by_detector["cfg_compose_privileged"].rule_id == "CFG-020"
    assert by_detector["cfg_compose_secret_env"].rule_id == "CFG-021"
    assert by_detector["cfg_compose_secret_env"].sensitive is True
    assert "s3cr3tp4ssw0rd!" not in by_detector["cfg_compose_secret_env"].evidence
    assert analyze_compose("docker-compose.yml", COMPOSE_SAFE) == []


# --- Dispatch, accounting, SBOM ----------------------------------------------


def test_supplychain_covered_files(advisory_db: LocalAdvisoryDB):
    paths = [
        "requirements.txt",
        "Dockerfile",
        ".github/workflows/ci.yml",
        "docker-compose.yml",
        "app.py",
        "notes.txt",
    ]
    covered = supplychain_covered_files(paths)
    assert covered == {
        "requirements.txt",
        "Dockerfile",
        ".github/workflows/ci.yml",
        "docker-compose.yml",
    }
    # Dispatch never raises and routes by file kind.
    findings = analyze_supplychain_file(
        "requirements.txt", "benchpkg==1.0.0\n", advisory_db
    )
    assert any(f.detector == "dep_vulnerable_package" for f in findings)


def test_sbom_structure(advisory_db: LocalAdvisoryDB):
    contents = {
        "requirements.txt": "benchpkg==1.0.0\nloosedep\n",
        "package.json": json.dumps({"dependencies": {"benchjs": "^1.0.0"}}),
        "app.py": "x = 1\n",
    }
    sbom = build_sbom_for_scan(
        contents,
        _repo(),
        advisory_status=advisory_db.status,
        advisory_generated_at=advisory_db.generated_at,
    )
    assert sbom["bomFormat"] == "CycloneDX"
    assert sbom["metadata"]["component"]["name"] == "o/r"
    assert sbom["metadata"]["advisory_database"]["status"] == "current"
    by_name = {c["name"]: c for c in sbom["components"]}
    assert by_name["benchpkg"]["version"] == "1.0.0"
    assert by_name["benchpkg"]["scope"] == "required"
    assert by_name["loosedep"]["version"] == "unspecified"
    assert by_name["benchjs"]["type"] == "library"
    assert "not" in sbom["metadata"]["notes"].lower()  # honesty note present


def test_orchestrator_e2e_accounting_and_sbom(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    from services.ai_provider import StubAIProvider
    from services.orchestrator import AnalysisOrchestrator
    from services.supplychain import dispatch as dispatch_module

    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "app.py").write_text("x = 1\n", encoding="utf-8")
    (repo / "requirements.txt").write_text("benchpkg==1.0.0\n", encoding="utf-8")
    (repo / "Dockerfile").write_text("FROM x:latest\n", encoding="utf-8")
    (repo / "notes.txt").write_text("hi\n", encoding="utf-8")

    db_path = tmp_path / "advisories.json"
    db_path.write_text(json.dumps(SYNTHETIC_DB), encoding="utf-8")
    monkeypatch.setattr(
        dispatch_module,
        "get_advisory_source",
        lambda cfg=None: LocalAdvisoryDB(str(db_path), max_age_days=36500),
    )

    orch = AnalysisOrchestrator(ai_provider=StubAIProvider())
    result = orch.run_on_local_path(repo)
    s = result.summary
    # 4 discovered: app.py (deep), requirements.txt + Dockerfile move from
    # unsupported to deep_analyzed, notes.txt stays unsupported.
    assert s.files_discovered == 4
    assert s.files_deep_analyzed == 3
    assert s.files_unsupported == 1
    assert s.files_discovered == (
        s.files_deep_analyzed
        + s.files_unsupported
        + s.files_skipped
        + s.files_failed_parse
    )
    assert any(f.detector == "dep_vulnerable_package" for f in result.findings)
    assert any(f.detector == "cfg_docker_latest_tag" for f in result.findings)
    # SBOM attached.
    assert result.sbom is not None
    assert result.sbom["bomFormat"] == "CycloneDX"
    assert {c["name"] for c in result.sbom["components"]} == {"benchpkg"}


def test_validator_redaction_gate_accepts_real_secret_finding(tmp_path: Path):
    raw_secret = "sk-live-AbC123DeF456GhI789JkL0Mn"
    contents = {"k.txt": f'key = "{raw_secret}"\n'}
    findings = analyze_secrets("k.txt", contents["k.txt"])
    assert len(findings) == 1 and findings[0].sensitive
    validated = finding_validator.validate_findings(findings, contents)
    assert len(validated.validated) == 1
    assert not validated.dropped


def test_validator_redaction_gate_rejects_misanchored_secret():
    finding = _sensitive_finding()
    bad = finding.model_copy(update={"file": "other.txt", "line": 99})
    contents = {"other.txt": "nothing here\n"}
    validated = finding_validator.validate_findings([bad], contents)
    assert not validated.validated
    assert validated.dropped


def test_get_advisory_source_default_is_unavailable():
    # No DB shipped: honest default, never fabricated.
    source = get_advisory_source()
    assert source.status == "unavailable"
