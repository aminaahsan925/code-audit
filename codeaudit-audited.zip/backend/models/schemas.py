"""Typed API and domain models for CodeAudit.

Enums keep category/severity/confidence/source values consistent across
the codebase. Pydantic models define the API contract.
"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Category(str, Enum):
    SECURITY = "security"
    PERFORMANCE = "performance"
    QUALITY = "quality"


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class FindingSource(str, Enum):
    DETERMINISTIC = "deterministic"
    AI = "ai"
    # Phase 6: findings observed by the authorized live website scanner.
    # They come from HTTP responses, not repository files; `file` holds the
    # URL path as the locator and `url` the full URL.
    LIVE_SCAN = "live-scan"


class AIVerdict(str, Enum):
    """Nemotron's judgment on one deterministic finding, from supplied evidence."""

    CONFIRMED = "confirmed"  # evidence supports the finding as stated
    UNCERTAIN = "uncertain"  # suspicious but evidence is insufficient
    UNLIKELY = "unlikely"  # evidence suggests a false positive


class AIStatusValue(str, Enum):
    DISABLED = "disabled"  # no provider configured (or explicitly turned off)
    ENABLED = "enabled"  # provider ran and returned a usable result
    UNAVAILABLE = "unavailable"  # provider misconfigured / model not reachable
    FAILED = "failed"  # provider call failed; deterministic results still returned


class AnalysisRequest(BaseModel):
    repository_url: str = Field(
        ...,
        min_length=1,
        max_length=2048,
        description="Public GitHub repository URL, e.g. https://github.com/owner/repo",
    )
    # Phase 7: optional project to attach the analysis (and its finding
    # snapshots) to for scan history. Must be owned by the caller.
    project_id: Optional[str] = Field(
        default=None,
        max_length=64,
        description="Project id to attach this analysis to (scan history)",
    )


class RepositoryMetadata(BaseModel):
    owner: str
    name: str
    url: str
    default_branch: Optional[str] = None
    description: Optional[str] = None


class AnalyzedFile(BaseModel):
    relative_path: str
    language: Optional[str] = None
    size_bytes: int
    # Full content is kept in memory only during analysis; never serialized
    # into API responses.


class CodeSymbol(BaseModel):
    kind: str  # "function" | "class" | "import"
    name: str
    line: int
    end_line: Optional[int] = None


class ParsedFile(BaseModel):
    relative_path: str
    language: Optional[str] = None
    symbols: list[CodeSymbol] = Field(default_factory=list)
    parse_error: Optional[str] = None


class Finding(BaseModel):
    id: str
    category: Category
    severity: Severity
    title: str
    description: str
    file: str
    line: int
    column: Optional[int] = None
    evidence: str = Field(..., description="Exact source snippet backing this finding")
    suggested_fix: Optional[str] = None
    confidence: Confidence
    source: FindingSource
    detector: str = Field(..., description="Name of the detector that produced this finding")
    language: Optional[str] = Field(
        default=None,
        description="Language the finding was detected in, e.g. 'python' or 'javascript'",
    )
    # Phase 3: rule registry attribution. Additive: detectors stamp these from
    # the registry; findings from other producers (e.g. AI candidates) leave
    # them unset rather than inventing a mapping.
    rule_id: Optional[str] = Field(
        default=None,
        description="Stable rule identifier, e.g. 'PY-SEC-001'",
    )
    cwe_ids: list[str] = Field(
        default_factory=list,
        description="CWE identifiers for this finding's rule, e.g. ['CWE-89']",
    )
    # Phase 3: lightweight source-to-sink trace. Set only when a taint analysis
    # identified a concrete untrusted origin (TAINTED) or explicitly could not
    # determine the origin (UNKNOWN). Absent means no flow analysis was
    # performed for this finding — not a claim of safety.
    taint_trace: Optional[str] = Field(
        default=None,
        description="Source-to-sink trace note for this finding, if analyzed",
    )
    # Phase 6: live website scanning. For live-scan findings `file` holds
    # the URL path as the locator, `line` is 0 (not applicable), and `url`
    # holds the full URL the finding was observed on. None for
    # repository findings.
    url: Optional[str] = Field(
        default=None,
        description="Full URL for live-scan findings; None for repository findings",
    )
    # AI traceability (Phase 2). Set only when Nemotron reasoned over this
    # finding. The deterministic fields above (id/file/line/evidence/detector)
    # are never rewritten by AI enrichment — they remain the evidence anchor.
    ai_reasoning: Optional[str] = Field(
        default=None, description="Nemotron's evidence-grounded reasoning, if any"
    )
    enriched_by: Optional[str] = Field(
        default=None, description="AI provider that enriched this finding, e.g. 'nemotron'"
    )
    prompt_version: Optional[str] = Field(
        default=None, description="Prompt version used for the AI reasoning, if any"
    )
    # Multi-agent traceability (Phase 3 upgrade). Which agents genuinely
    # participated in this finding's lifecycle. Never claims participation
    # that did not happen.
    provenance: Optional["FindingProvenance"] = Field(
        default=None, description="Agent participation trail for this finding"
    )
    # Phase 4: secret findings carry redacted evidence and must never reach
    # an AI provider. The AI context builder excludes sensitive findings
    # (and their files); the evidence validator uses a redaction-aware
    # check for them instead of a verbatim substring match.
    sensitive: bool = Field(
        default=False,
        description="True when the finding concerns secret material: its "
        "evidence is redacted and it is excluded from AI context.",
    )
    # Phase 5: knowledge-only retrieval provenance. IDs of curated KB
    # entries whose guidance was shown to the model alongside this
    # finding (evidence review or fix proposal). The entries informed the
    # explanation/fix only; they never determined the finding's existence.
    # Empty when no knowledge was consulted (or the finding is sensitive).
    knowledge_used: list[str] = Field(
        default_factory=list,
        description="Curated knowledge entry IDs consulted for this finding",
    )


class FindingProvenance(BaseModel):
    """Which agents genuinely participated in a finding's lifecycle.

    detected_by: specialist agent(s) that surfaced it (or "evidence_agent"
        for AI-discovered findings that passed the evidence hard gate).
    reviewed_by: agents that reasoned over it (e.g. "evidence_agent").
    fixed_by / verified_by: populated along the remediation trail.
    """

    detected_by: list[str] = Field(default_factory=list)
    reviewed_by: list[str] = Field(default_factory=list)
    fixed_by: list[str] = Field(default_factory=list)
    verified_by: list[str] = Field(default_factory=list)


class ValidatedFinding(Finding):
    validation: str = Field(default="passed", description="'passed' or 'unverified'")


class RiskBreakdown(BaseModel):
    """Transparent, auditable account of how the risk score was computed."""

    formula: str = Field(
        default=(
            "per_finding_score = severity_weight * confidence_factor * reachability_factor; "
            "repository_score = min(10, round(sum(per_finding_score) / 100)), "
            "an integer on a 0-10 scale. "
            "reachability_factor is 1.25 when the finding's file path suggests "
            "web-exposed code (views/routes/handlers/controllers/api), else 1.0. "
            "Weights are heuristic and not scientifically validated."
        )
    )
    severity_weights: dict[str, int]
    confidence_factors: dict[str, float]
    reachability_factors: dict[str, float]
    findings_counted: int
    total_weighted_points: float


class RiskResult(BaseModel):
    score: int = Field(..., ge=0, le=10, description="Repository risk on a 0-10 scale")
    level: str  # critical | high | medium | low
    breakdown: RiskBreakdown


class AnalysisSummary(BaseModel):
    """File accounting for one analysis run.

    Every discovered file lands in exactly one terminal bucket:
    deep-analyzed, unsupported, skipped, or parse-failed.

    Reconciliation invariant (enforced below):
        files_discovered == files_deep_analyzed + files_unsupported
                            + files_skipped + files_failed_parse
        files_scanned    == files_deep_analyzed + files_unsupported
                            + files_failed_parse
    """

    files_discovered: int = Field(
        ..., description="Every file entry the walk encountered (dirs excluded)"
    )
    files_scanned: int = Field(
        ..., description="Passed exclusion filters; read and content-sniffed"
    )
    files_deep_analyzed: int = Field(
        ..., description="Files run through a structural analyzer (language or supply-chain file-kind)"
    )
    files_unsupported: int = Field(
        ..., description="Scanned but with no structural analyzer (secret scanning still applies to every file)"
    )
    files_skipped: int = Field(
        ..., description="Excluded by ignore rules, limits, or unreadable (see skip_reasons)"
    )
    files_failed_parse: int = Field(
        ..., description="Files whose language parse failed"
    )
    findings_total: int
    findings_dropped: int = 0  # findings rejected by the evidence hard gate
    findings_by_severity: dict[str, int]
    findings_by_category: dict[str, int]
    skip_reasons: dict[str, int] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_accounting(self) -> "AnalysisSummary":
        terminal = (
            self.files_deep_analyzed
            + self.files_unsupported
            + self.files_skipped
            + self.files_failed_parse
        )
        if self.files_discovered != terminal:
            raise ValueError(
                f"files_discovered ({self.files_discovered}) != deep_analyzed "
                f"({self.files_deep_analyzed}) + unsupported ({self.files_unsupported}) "
                f"+ skipped ({self.files_skipped}) + failed_parse ({self.files_failed_parse})"
            )
        if self.files_scanned != terminal - self.files_skipped:
            raise ValueError(
                f"files_scanned ({self.files_scanned}) != deep_analyzed "
                f"({self.files_deep_analyzed}) + unsupported ({self.files_unsupported}) "
                f"+ failed_parse ({self.files_failed_parse})"
            )
        return self


class AIFindingCandidate(BaseModel):
    """One raw candidate finding parsed from Nemotron's structured output.

    Never trusted directly: candidates go through path normalization,
    Pydantic validation, the evidence hard gate (FindingValidator), and
    deduplication before they can appear in a final result.
    """

    title: str = Field(..., min_length=1)
    category: Category
    severity: Severity
    file: str = Field(..., min_length=1)
    line: int = Field(..., ge=1)
    evidence: str = Field(..., min_length=1, description="Verbatim source snippet")
    description: str = Field(..., min_length=1)
    suggested_fix: Optional[str] = None
    confidence: Confidence
    reasoning: str = Field(
        ..., min_length=1, description="Why the evidence supports this conclusion"
    )


class AIAssessment(BaseModel):
    """Nemotron's verdict on one deterministic finding."""

    finding_id: str = Field(..., min_length=1)
    verdict: AIVerdict
    confidence: Confidence = Field(
        ..., description="The model's confidence in its own verdict"
    )
    reasoning: str = Field(..., min_length=1)
    suggested_fix: Optional[str] = None


class AIInvestigationResponse(BaseModel):
    """The complete structured contract Nemotron must return.

    The model must return exactly this JSON shape (see services/prompts).
    Anything else is rejected fail-closed: no AI findings are fabricated.
    """

    assessments: list[AIAssessment] = Field(default_factory=list)
    new_findings: list[AIFindingCandidate] = Field(default_factory=list)


class AIStatus(BaseModel):
    """Response metadata describing what the AI layer did (or why it didn't)."""

    status: AIStatusValue
    provider: str = Field(default="", description="AI provider name, e.g. 'nemotron'")
    model: Optional[str] = Field(default=None, description="Model id used, if any")
    prompt_version: Optional[str] = None
    model_calls: int = 0
    context_chars: int = 0
    deterministic_findings: int = 0
    findings_enriched: int = 0
    ai_findings_accepted: int = 0
    ai_findings_dropped: int = 0
    duplicates_merged: int = 0
    duration_ms: Optional[int] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = Field(
        default=None, description="Sanitized; never contains credentials or SDK internals"
    )


def _disabled_ai_status() -> AIStatus:
    return AIStatus(status=AIStatusValue.DISABLED)


class AIBudgetReport(BaseModel):
    """Cost visibility for one bounded AI budget (analysis or remediation).

    Monetary cost is deliberately NOT estimated: only call counts against
    the configured hard limit are reported.
    """

    mode: str = Field(..., description="'free' | 'economy' | 'full'")
    purpose: str = Field(..., description="'analysis' or 'remediation'")
    limit: int = Field(..., ge=0, description="Hard cap on Nemotron calls")
    used: int = Field(..., ge=0, description="Nemotron calls actually made")
    remaining: int = Field(..., ge=0)


class AgentInfo(BaseModel):
    """Per-agent execution record for the final supervisor report."""

    agent_name: str
    status: str = Field(..., description="'completed' | 'failed' | 'skipped' | 'degraded'")
    duration_ms: int = 0
    model_used: Optional[str] = Field(default=None)
    model_calls: int = 0
    context_chars: int = 0
    prompt_version: Optional[str] = None
    findings_count: int = 0
    errors: list[str] = Field(default_factory=list)


class AgentRunSummary(BaseModel):
    """Multi-agent execution metadata attached to an analysis result."""

    execution_id: str
    mode: str = Field(..., description="AI operating mode: 'free' | 'economy' | 'full'")
    completed: int = Field(default=0, description="Agents that completed")
    ai_calls: int = Field(default=0, description="Total Nemotron calls made")
    agents: list[AgentInfo] = Field(default_factory=list)
    budget: Optional[AIBudgetReport] = Field(
        default=None, description="Analysis-budget visibility"
    )


class AnalysisResult(BaseModel):
    repository: RepositoryMetadata
    summary: AnalysisSummary
    findings: list[ValidatedFinding]
    risk: RiskResult
    ai: AIStatus = Field(default_factory=_disabled_ai_status)
    # Multi-agent upgrade (Phase 3): optional so older clients keep working.
    agents: Optional[AgentRunSummary] = Field(
        default=None, description="Per-agent execution metadata, when run via the supervisor"
    )
    ai_budget: Optional[AIBudgetReport] = Field(
        default=None, description="AI call budget visibility for this analysis"
    )
    # Phase 4: CycloneDX-inspired dependency inventory (see
    # services/supplychain/sbom.py). Only declared dependencies are listed;
    # versions are "unspecified" when not pinned. Advisory-database status
    # is recorded in the SBOM metadata.
    sbom: Optional[dict] = Field(
        default=None,
        description="Software Bill of Materials for declared dependencies",
    )


# ---------------------------------------------------------------------------
# Phase 6 — authorized live website scanning
# ---------------------------------------------------------------------------


class WebsiteScanRequest(BaseModel):
    """Request a live security scan of a website.

    Authorization is enforced server-side: the request must BOTH carry the
    per-host ``authorization_token`` configured via CODEAUDIT_SCAN_TOKENS
    AND set ``i_authorize_this_scan`` to true. Anything else → 403.

    ``session_cookie`` / ``authorization_header`` are the caller's own
    credentials for the target (used only within the authorized scope,
    never logged, never stored).
    """

    target_url: str = Field(..., min_length=1, max_length=2048)
    authorization_token: str = Field(..., min_length=1, max_length=512)
    i_authorize_this_scan: bool = Field(
        ...,
        description="Explicit per-request confirmation that the caller is "
        "permitted to security-test the target.",
    )
    include_subdomains: bool = Field(
        default=False,
        description="Also scan subdomains of the target host (default: exact host only).",
    )
    path_prefix: Optional[str] = Field(
        default=None,
        description="Restrict the crawl to this path prefix (default: the "
        "target URL's own path). Must start with '/'.",
    )
    max_pages: Optional[int] = Field(
        default=None,
        ge=1,
        le=500,
        description="Page cap for this scan; the server-side "
        "CODEAUDIT_SCAN_MAX_PAGES always wins.",
    )
    active_probes: bool = Field(
        default=True,
        description="Run the bounded GET-only active probes (reflected-XSS "
        "canary, SQL-error probe). Findings are capped at MEDIUM confidence "
        "and require manual verification.",
    )
    session_cookie: Optional[str] = Field(
        default=None,
        max_length=4096,
        description="Optional Cookie header value for authenticated scanning.",
    )
    authorization_header: Optional[str] = Field(
        default=None,
        max_length=4096,
        description="Optional Authorization header value for authenticated scanning.",
    )
    # Phase 7: optional project to attach the scan to for scan history.
    # Must be owned by the caller.
    project_id: Optional[str] = Field(
        default=None,
        max_length=64,
        description="Project id to attach this scan to (scan history)",
    )


class WebsiteScanResult(BaseModel):
    """Result of one authorized live website scan.

    Findings share the repository Finding contract but carry
    ``source="live-scan"``. ``disclaimer`` states exactly what was
    covered: a limited scan never claims the site is secure.
    """

    target_url: str
    scan_host: str
    scope: str = Field(..., description="Authorized scope, human-readable")
    urls_scanned: list[str]
    urls_skipped_out_of_scope: list[str] = Field(default_factory=list)
    findings: list[Finding]
    checks_run: dict[str, int] = Field(
        default_factory=dict,
        description="Counts by check kind, e.g. {'passive': 12, 'active': 4}",
    )
    requests_made: int
    truncated: bool = Field(
        default=False,
        description="True when a scan budget ended the crawl early; "
        "results are partial but honest.",
    )
    duration_ms: int
    disclaimer: str


class ErrorDetail(BaseModel):
    code: str
    message: str


class ErrorResponse(BaseModel):
    error: ErrorDetail


# ---------------------------------------------------------------------------
# Phase 3 — safe remediation (FIND -> FIX -> VERIFY)
# ---------------------------------------------------------------------------


class FixDecision(str, Enum):
    """The model's verdict on whether it can propose a remediation."""

    FIX = "fix"
    CANNOT_FIX = "cannot_fix"


class VerificationStatus(str, Enum):
    """Deterministic outcome of verifying a proposed patch.

    Only the verification engine assigns these — never the model. The engine
    reruns the existing deterministic analyzers on the patched workspace and
    compares BEFORE vs AFTER.
    """

    VERIFIED = "verified"
    PARTIALLY_VERIFIED = "partially_verified"
    NOT_VERIFIED = "not_verified"
    PATCH_REJECTED = "patch_rejected"
    NEW_ISSUE_INTRODUCED = "new_issue_introduced"
    CANNOT_VERIFY = "cannot_verify"


class RemediationStatus(str, Enum):
    """Overall remediation outcome, returned by the remediation engine/API.

    Extends the verification outcomes with AI-layer outcomes: the model may
    be unavailable or fail, in which case the original analysis is preserved
    and nothing is patched.
    """

    VERIFIED = "verified"
    PARTIALLY_VERIFIED = "partially_verified"
    NOT_VERIFIED = "not_verified"
    PATCH_REJECTED = "patch_rejected"
    NEW_ISSUE_INTRODUCED = "new_issue_introduced"
    CANNOT_VERIFY = "cannot_verify"
    UNAVAILABLE = "unavailable"
    FAILED = "failed"


class FixChange(BaseModel):
    """One proposed source change, anchored to exact existing content.

    Phase 3 v1 only modifies existing lines: every change must reference an
    existing repository-relative file and a valid line range, and ``old_text``
    must match the actual content at that range before anything is applied.
    Arbitrary file creation/deletion is not representable.
    """

    file: str = Field(..., min_length=1, description="Repository-relative path, case-sensitive")
    start_line: int = Field(..., ge=1)
    end_line: int = Field(..., ge=1)
    old_text: str = Field(..., min_length=1, description="Exact current text at the range")
    new_text: str = Field(..., min_length=1, description="Replacement text (never empty: no deletions in v1)")

    @field_validator("new_text")
    @classmethod
    def _new_text_must_not_be_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("new_text must not be blank (no deletions in v1)")
        return v

    @model_validator(mode="after")
    def _range_must_be_ordered(self) -> "FixChange":
        if self.end_line < self.start_line:
            raise ValueError("end_line must be >= start_line")
        return self


class FixProposal(BaseModel):
    """Structured remediation proposal. The model proposes; the system stamps
    traceability fields (finding_id/provider/model/prompt_version) — the
    model's own values for these are never trusted."""

    finding_id: str = Field(..., min_length=1)
    decision: FixDecision
    reasoning: str = Field(..., min_length=1)
    changes: list[FixChange] = Field(default_factory=list)
    expected_effect: str = ""
    verification_notes: str = ""
    provider: str = ""
    model: str = ""
    prompt_version: str = ""
    # Phase 5: knowledge provenance. knowledge_used lists the curated KB
    # entry IDs the system showed to the model with this finding (system
    # truth, stamped by the agent). knowledge_cited lists the entry IDs the
    # model claimed to rely on (model output, advisory only — validated to
    # reference only entries that were actually shown).
    knowledge_used: list[str] = Field(default_factory=list)
    knowledge_cited: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _decision_matches_changes(self) -> "FixProposal":
        if self.decision == FixDecision.CANNOT_FIX and self.changes:
            raise ValueError("decision 'cannot_fix' must not carry changes")
        if self.decision == FixDecision.FIX and not self.changes:
            raise ValueError("decision 'fix' requires at least one change")
        return self


class AppliedChange(BaseModel):
    """Record of one change the patch engine applied in the temp workspace."""

    file: str
    start_line: int
    end_line: int
    lines_changed: int
    before: str = Field(..., description="Original text (bounded excerpt)")
    after: str = Field(..., description="Patched text (bounded excerpt)")


class RejectedChange(BaseModel):
    """Record of one proposed change the patch engine refused to apply."""

    file: str
    start_line: int
    end_line: int
    reason: str = Field(..., description="Machine-readable rejection reason")


class VerificationResult(BaseModel):
    """Deterministic BEFORE/AFTER comparison for one remediated finding."""

    status: VerificationStatus
    original_finding_id: str
    finding_present_before: bool
    finding_present_after: bool
    original_evidence_present_before: bool
    original_evidence_present_after: bool
    new_findings_introduced: list[str] = Field(
        default_factory=list, description="Ids of verified findings introduced by the patch"
    )
    verified: bool = Field(..., description="True only when status == verified")
    reason: str = ""


class RemediationResult(BaseModel):
    """Complete outcome of one FIND -> FIX -> VERIFY cycle."""

    status: RemediationStatus
    finding_id: str
    proposal: Optional[FixProposal] = None
    verification: Optional[VerificationResult] = None
    changes_applied: list[AppliedChange] = Field(default_factory=list)
    changes_rejected: list[RejectedChange] = Field(default_factory=list)
    risk_before: Optional[RiskResult] = None
    risk_after: Optional[RiskResult] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    # Multi-agent upgrade: which agents genuinely participated in this
    # remediation (subset of fix_agent / patch_guard / verification_agent).
    agent_trail: list[str] = Field(default_factory=list)


class RemediationRequest(BaseModel):
    repository_url: str = Field(..., min_length=1, max_length=2048)
    finding_id: str = Field(..., min_length=1)


class BatchRemediationRequest(BaseModel):
    repository_url: str = Field(..., min_length=1, max_length=2048)
    finding_ids: List[str] = Field(..., min_length=1)


# ---------------------------------------------------------------------------
# Phase 7 — database, auth, jobs, metering (SaaS infrastructure)
# ---------------------------------------------------------------------------


class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)


class ProjectOut(BaseModel):
    id: str
    name: str
    created_at: str


class JobOut(BaseModel):
    id: str
    kind: str
    state: str
    project_id: Optional[str] = None
    created_at: str
    updated_at: str
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    # Full result (AnalysisResult / WebsiteScanResult JSON) when done.
    result: Optional[dict] = None


class JobAcceptedOut(BaseModel):
    job_id: str
    state: str = "queued"


class RepoAnalysisHistoryOut(BaseModel):
    id: str
    project_id: Optional[str] = None
    repository_url: str
    status: str
    findings_count: int
    risk_score: Optional[float] = None
    created_at: str
    finished_at: Optional[str] = None


class WebsiteScanHistoryOut(BaseModel):
    id: str
    project_id: Optional[str] = None
    target_url: str
    status: str
    findings_count: int
    urls_scanned: int
    truncated: bool
    created_at: str
    finished_at: Optional[str] = None


class ProjectHistoryOut(BaseModel):
    project_id: str
    repo_analyses: list[RepoAnalysisHistoryOut] = Field(default_factory=list)
    website_scans: list[WebsiteScanHistoryOut] = Field(default_factory=list)


class AnalysisDetailOut(RepoAnalysisHistoryOut):
    findings: list[Finding] = Field(default_factory=list)


class WebsiteScanDetailOut(WebsiteScanHistoryOut):
    findings: list[Finding] = Field(default_factory=list)


class UsageOut(BaseModel):
    # Non-secret key prefix the counters belong to.
    api_key_prefix: Optional[str] = None
    counters: dict[str, int] = Field(default_factory=dict)


class ApiKeyOut(BaseModel):
    id: str
    key_prefix: str
    name: str
    scopes: list[str] = Field(default_factory=list)
    revoked: bool
    created_at: str
    last_used_at: Optional[str] = None


class ApiKeyCreate(BaseModel):
    name: str = Field(default="", max_length=200)
    scopes: list[str] = Field(default_factory=lambda: ["read"])


class ApiKeyCreatedOut(BaseModel):
    """The plaintext key is returned exactly once — the caller must save it."""

    id: str
    key_prefix: str
    name: str
    scopes: list[str] = Field(default_factory=list)
    api_key: str = Field(
        ...,
        description="Plaintext API key — shown once, never stored or shown again",
    )


# ---------------------------------------------------------------------------
# Phase 8 — finding lifecycle, retest, reports
# ---------------------------------------------------------------------------


class FindingStatusIn(BaseModel):
    fingerprint: str = Field(min_length=1, max_length=64)
    status: str = Field(description="'acknowledged' or 'fixed' ('new' is implicit)")
    note: Optional[str] = Field(default=None, max_length=1024)

    @field_validator("status")
    @classmethod
    def _validate_status(cls, v: str) -> str:
        if v not in ("acknowledged", "fixed"):
            raise ValueError("status must be 'acknowledged' or 'fixed'")
        return v


class FindingStatusOut(BaseModel):
    fingerprint: str
    status: str
    note: Optional[str] = None
    updated_at: str


class RetestRequest(BaseModel):
    kind: str = Field(description="'repo_analysis' or 'website_scan'")
    # Website retest requires FRESH authorization every time — the stored
    # scan never reuses caller credentials.
    authorization_token: Optional[str] = Field(default=None, max_length=4096)
    i_authorize_this_scan: bool = False

    @field_validator("kind")
    @classmethod
    def _validate_kind(cls, v: str) -> str:
        if v not in ("repo_analysis", "website_scan"):
            raise ValueError("kind must be 'repo_analysis' or 'website_scan'")
        return v


class RetestFindingOut(BaseModel):
    fingerprint: str
    rule_id: Optional[str] = None
    title: str
    severity: str
    file: Optional[str] = None
    url: Optional[str] = None
    line: Optional[int] = None
    # Lifecycle annotation: for "persisting" findings that were marked
    # fixed, this is "regressed"; for "resolved" findings that were marked
    # fixed, this is "verified".
    lifecycle: Optional[str] = None


class RetestResultOut(BaseModel):
    project_id: str
    kind: str
    previous_run_id: str
    new_run_id: str
    new: List[RetestFindingOut] = Field(default_factory=list)
    persisting: List[RetestFindingOut] = Field(default_factory=list)
    resolved: List[RetestFindingOut] = Field(default_factory=list)
    risk_before: Optional[float] = None
    risk_after: Optional[float] = None
