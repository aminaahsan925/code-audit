"""Phase 7 — API-key authentication.

Security properties:
- Keys are ``ca_``-prefixed unguessable tokens (256 bits of entropy).
- Only a salted PBKDF2-SHA256 hash is ever stored; the plaintext is shown
  exactly once at issuance and is never written to the database, logs, or
  error messages.
- Verification recomputes the hash and compares with
  ``hmac.compare_digest`` (constant time).
- ``key_prefix`` (first 12 chars, e.g. ``ca_ab12cd34``) is non-secret and
  narrows the DB lookup; it is safe to show in UIs and logs.

Scopes: ``read`` < ``scan`` < ``admin``. A key holding ``scan`` may also
read; ``admin`` implies everything. Scope checks live in the HTTP layer;
this module only issues, parses, and verifies.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets

# PBKDF2-SHA256 with 600k iterations (OWASP 2023 guidance for SHA-256).
_HASH_ALGO = "pbkdf2-sha256"
_HASH_ITERATIONS = 600_000
_SALT_BYTES = 16
_DERIVED_BYTES = 32
_KEY_PREFIX_LEN = 12  # "ca_" + 9 chars of the token

VALID_SCOPES = frozenset({"read", "scan", "admin"})
# Broader scopes imply narrower ones.
SCOPE_IMPLICATIONS: dict[str, frozenset[str]] = {
    "admin": frozenset({"read", "scan"}),
    "scan": frozenset({"read"}),
    "read": frozenset(),
}


def generate_api_key() -> tuple[str, str]:
    """Return ``(plaintext_key, key_prefix)``.

    The plaintext must be shown to the user once and then discarded —
    callers must never persist it.
    """
    token = secrets.token_urlsafe(32)  # 256 bits of entropy
    plaintext = f"ca_{token}"
    return plaintext, plaintext[:_KEY_PREFIX_LEN]


def hash_api_key(plaintext: str) -> str:
    """Salted PBKDF2-SHA256 hash in ``algo$iterations$salt_hex$hash_hex`` form."""
    salt = secrets.token_bytes(_SALT_BYTES)
    derived = hashlib.pbkdf2_hmac(
        "sha256", plaintext.encode("utf-8"), salt, _HASH_ITERATIONS
    )
    return f"{_HASH_ALGO}${_HASH_ITERATIONS}${salt.hex()}${derived.hex()}"


def verify_api_key(plaintext: str, stored_hash: str) -> bool:
    """Constant-time verification. False on malformed hashes or mismatch."""
    try:
        algo, iterations_raw, salt_hex, hash_hex = stored_hash.split("$")
        if algo != _HASH_ALGO:
            return False
        iterations = int(iterations_raw)
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(hash_hex)
    except (ValueError, TypeError):
        return False
    derived = hashlib.pbkdf2_hmac(
        "sha256", plaintext.encode("utf-8"), salt, iterations
    )
    return hmac.compare_digest(derived, expected)


def normalize_scopes(scopes: list[str]) -> list[str]:
    """Validate and sort scopes; raises ValueError on unknown scope."""
    unknown = [s for s in scopes if s not in VALID_SCOPES]
    if unknown:
        raise ValueError(f"Unknown API key scopes: {unknown}")
    return sorted(set(scopes))


def scopes_grant(granted: list[str], required: str) -> bool:
    """True when ``granted`` scopes satisfy ``required`` (via implication)."""
    effective = set(granted)
    for scope in list(granted):
        effective |= SCOPE_IMPLICATIONS.get(scope, frozenset())
    return required in effective or "admin" in granted


def encode_scopes(scopes: list[str]) -> str:
    return json.dumps(normalize_scopes(scopes))


def decode_scopes(raw: str) -> list[str]:
    try:
        scopes = json.loads(raw)
    except (ValueError, TypeError):
        return []
    if not isinstance(scopes, list):
        return []
    return [s for s in scopes if s in VALID_SCOPES]
