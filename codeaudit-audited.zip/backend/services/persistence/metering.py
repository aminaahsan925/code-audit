"""Phase 7 — per-API-key usage metering.

Counters (``analyses``, ``scans``, ``ai_calls``, ``ai_tokens``) are the
raw input billing needs later (Phase 11). No prices, no invoices here —
just honest, monotonic counters scoped to the API key that performed
the work. Anonymous (unauthenticated dev-mode) calls are not metered;
there is no key to attribute them to, and inventing attribution would be
dishonest.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from services.persistence.models import UsageCounter

logger = logging.getLogger(__name__)

COUNTER_ANALYSES = "analyses"
COUNTER_SCANS = "scans"
COUNTER_AI_CALLS = "ai_calls"
COUNTER_AI_TOKENS = "ai_tokens"
KNOWN_COUNTERS = frozenset(
    {COUNTER_ANALYSES, COUNTER_SCANS, COUNTER_AI_CALLS, COUNTER_AI_TOKENS}
)


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def increment(session: Session, api_key_id: str | None, counter: str, amount: int = 1) -> None:
    """Increment ``counter`` for ``api_key_id``. No-op for anonymous calls.

    Atomic via ``INSERT ... ON CONFLICT DO UPDATE``: concurrent increments
    can neither lost-update nor hit IntegrityError on the duplicate row.
    """
    if api_key_id is None:
        return
    if counter not in KNOWN_COUNTERS:
        raise ValueError(f"Unknown usage counter: {counter}")
    if amount < 0:
        raise ValueError("Usage increments must be non-negative")
    dialect = session.bind.dialect.name if session.bind is not None else ""
    if dialect == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as dialect_insert
    elif dialect == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as dialect_insert
    else:  # pragma: no cover — unknown dialect, fall back to read-modify-write
        dialect_insert = None
    if dialect_insert is None:
        _increment_legacy(session, api_key_id, counter, amount)
        return
    now = _utcnow()
    session.execute(
        dialect_insert(UsageCounter)
        .values(api_key_id=api_key_id, counter=counter, value=amount, updated_at=now)
        .on_conflict_do_update(
            index_elements=["api_key_id", "counter"],
            set_={"value": UsageCounter.value + amount, "updated_at": now},
        )
    )


def _increment_legacy(session: Session, api_key_id: str, counter: str, amount: int) -> None:
    """Non-atomic read-modify-write fallback for unknown dialects."""
    row = session.execute(
        select(UsageCounter).where(
            UsageCounter.api_key_id == api_key_id, UsageCounter.counter == counter
        )
    ).scalar_one_or_none()
    if row is None:
        row = UsageCounter(api_key_id=api_key_id, counter=counter, value=0)
        session.add(row)
    row.value += amount
    row.updated_at = _utcnow()


def get_counters(session: Session, api_key_id: str) -> dict[str, int]:
    rows = session.execute(
        select(UsageCounter).where(UsageCounter.api_key_id == api_key_id)
    ).scalars()
    counters = {name: 0 for name in sorted(KNOWN_COUNTERS)}
    for row in rows:
        counters[row.counter] = row.value
    return counters
