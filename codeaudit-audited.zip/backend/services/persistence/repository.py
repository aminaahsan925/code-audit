"""Phase 7 — tenant-scoped data access.

Tenant isolation is enforced HERE, in the repository layer, not just at
the HTTP layer: every read/write method takes the caller's ``user_id``
and scopes its queries to rows owned by that user. A caller with
``user_id=None`` (the anonymous dev path, only when
``CODEAUDIT_REQUIRE_AUTH=false``) sees only unowned rows
(``user_id IS NULL``) — never another user's data.

Cross-user access returns ``None`` / empty lists (never a "forbidden"
that would confirm another tenant's row exists).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from services.persistence import auth as auth_lib
from services.persistence.models import (
    ApiKey,
    FindingSnapshot,
    FindingStatus,
    Project,
    RepoAnalysis,
    ScanJob,
    User,
    WebsiteScan,
)


def _utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ---------------------------------------------------------------------------
# Users & API keys
# ---------------------------------------------------------------------------


def create_user(session: Session, name: str) -> User:
    user = User(name=name)
    session.add(user)
    session.flush()
    return user


def create_api_key(
    session: Session, user_id: str, name: str = "", scopes: list[str] | None = None
) -> tuple[ApiKey, str]:
    """Create a key. Returns ``(record, plaintext)`` — the plaintext is
    shown once and must be discarded by the caller (never persisted)."""
    plaintext, prefix = auth_lib.generate_api_key()
    record = ApiKey(
        user_id=user_id,
        key_hash=auth_lib.hash_api_key(plaintext),
        key_prefix=prefix,
        name=name,
        scopes=auth_lib.encode_scopes(scopes or ["read"]),
    )
    session.add(record)
    session.flush()
    return record, plaintext


def find_api_key_by_prefix(session: Session, prefix: str) -> ApiKey | None:
    return session.execute(
        select(ApiKey).where(ApiKey.key_prefix == prefix)
    ).scalar_one_or_none()


def authenticate_api_key(session: Session, plaintext: str) -> ApiKey | None:
    """Return the key record when ``plaintext`` verifies and is active."""
    if not plaintext or len(plaintext) < 13 or not plaintext.startswith("ca_"):
        return None
    candidate = find_api_key_by_prefix(session, plaintext[:12])
    if candidate is None or candidate.revoked:
        return None
    if not auth_lib.verify_api_key(plaintext, candidate.key_hash):
        return None
    candidate.last_used_at = _utcnow()
    return candidate


def revoke_api_key(session: Session, user_id: str | None, key_id: str) -> bool:
    """Revoke one of the caller's own keys. False when not found/owned."""
    key = session.execute(
        select(ApiKey).where(ApiKey.id == key_id, _owner_clause(ApiKey, user_id))
    ).scalar_one_or_none()
    if key is None:
        return False
    key.revoked = True
    return True


def list_api_keys(session: Session, user_id: str | None) -> list[ApiKey]:
    return list(
        session.execute(
            select(ApiKey)
            .where(_owner_clause(ApiKey, user_id))
            .order_by(ApiKey.created_at)
        ).scalars()
    )


def any_api_keys_exist(session: Session) -> bool:
    """True when any API key exists (any owner). For the dev bootstrap."""
    return (
        session.execute(select(func.count()).select_from(ApiKey)).scalar_one() > 0
    )


# ---------------------------------------------------------------------------
# Tenant scoping helpers
# ---------------------------------------------------------------------------


def _owner_clause(model, user_id: str | None):
    """Every tenant-owned row filter goes through here."""
    if user_id is None:
        return model.user_id.is_(None)
    return model.user_id == user_id


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


def create_project(session: Session, user_id: str | None, name: str) -> Project:
    project = Project(user_id=user_id, name=name)
    session.add(project)
    session.flush()
    return project


def get_project(session: Session, user_id: str | None, project_id: str) -> Project | None:
    return session.execute(
        select(Project).where(
            Project.id == project_id, _owner_clause(Project, user_id)
        )
    ).scalar_one_or_none()


def list_projects(session: Session, user_id: str | None) -> list[Project]:
    return list(
        session.execute(
            select(Project).where(_owner_clause(Project, user_id)).order_by(Project.created_at)
        ).scalars()
    )


# ---------------------------------------------------------------------------
# Analyses & scans (history)
# ---------------------------------------------------------------------------


def record_repo_analysis(
    session: Session,
    *,
    user_id: str | None,
    project_id: str | None,
    repository_url: str,
    findings: list[dict],
    risk_score: float | None,
    summary: dict,
) -> RepoAnalysis:
    """Persist one completed repo analysis + immutable finding snapshots."""
    if project_id is not None and get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    analysis = RepoAnalysis(
        user_id=user_id,
        project_id=project_id,
        repository_url=repository_url,
        status="done",
        findings_count=len(findings),
        risk_score=risk_score,
        summary_json=json.dumps(summary),
        finished_at=_utcnow(),
    )
    session.add(analysis)
    session.flush()
    for finding in findings:
        session.add(
            FindingSnapshot(
                owner_type="repo_analysis",
                owner_id=analysis.id,
                finding_json=json.dumps(finding),
            )
        )
    return analysis


def record_website_scan(
    session: Session,
    *,
    user_id: str | None,
    project_id: str | None,
    target_url: str,
    findings: list[dict],
    urls_scanned: int,
    truncated: bool,
    summary: dict,
) -> WebsiteScan:
    """Persist one completed website scan + immutable finding snapshots."""
    if project_id is not None and get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    scan = WebsiteScan(
        user_id=user_id,
        project_id=project_id,
        target_url=target_url,
        status="done",
        findings_count=len(findings),
        urls_scanned=urls_scanned,
        truncated=truncated,
        summary_json=json.dumps(summary),
        finished_at=_utcnow(),
    )
    session.add(scan)
    session.flush()
    for finding in findings:
        session.add(
            FindingSnapshot(
                owner_type="website_scan",
                owner_id=scan.id,
                finding_json=json.dumps(finding),
            )
        )
    return scan


def get_repo_analysis(
    session: Session, user_id: str | None, analysis_id: str
) -> RepoAnalysis | None:
    return session.execute(
        select(RepoAnalysis).where(
            RepoAnalysis.id == analysis_id, _owner_clause(RepoAnalysis, user_id)
        )
    ).scalar_one_or_none()


def get_website_scan(
    session: Session, user_id: str | None, scan_id: str
) -> WebsiteScan | None:
    return session.execute(
        select(WebsiteScan).where(
            WebsiteScan.id == scan_id, _owner_clause(WebsiteScan, user_id)
        )
    ).scalar_one_or_none()


def list_project_history(
    session: Session, user_id: str | None, project_id: str
) -> tuple[list[RepoAnalysis], list[WebsiteScan]]:
    """Both analysis kinds for one project (the scan-history view)."""
    project = get_project(session, user_id, project_id)
    if project is None:
        raise LookupError(f"Project not found: {project_id}")
    analyses = list(
        session.execute(
            select(RepoAnalysis)
            .where(RepoAnalysis.project_id == project_id)
            .order_by(RepoAnalysis.created_at.desc())
        ).scalars()
    )
    scans = list(
        session.execute(
            select(WebsiteScan)
            .where(WebsiteScan.project_id == project_id)
            .order_by(WebsiteScan.created_at.desc())
        ).scalars()
    )
    return analyses, scans


def get_finding_snapshots(
    session: Session, owner_type: str, owner_id: str
) -> list[dict]:
    """Rebuild findings from immutable snapshots (insertion order)."""
    rows = session.execute(
        select(FindingSnapshot)
        .where(
            FindingSnapshot.owner_type == owner_type,
            FindingSnapshot.owner_id == owner_id,
        )
        .order_by(FindingSnapshot.created_at)
    ).scalars()
    return [json.loads(row.finding_json) for row in rows]


def count_user_projects(session: Session, user_id: str | None) -> int:
    return int(
        session.execute(
            select(func.count()).select_from(Project).where(_owner_clause(Project, user_id))
        ).scalar_one()
    )


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


def get_job(session: Session, user_id: str | None, job_id: str) -> ScanJob | None:
    return session.execute(
        select(ScanJob).where(
            ScanJob.id == job_id, _owner_clause(ScanJob, user_id)
        )
    ).scalar_one_or_none()


# ---------------------------------------------------------------------------
# Phase 8 — finding lifecycle (per-project, keyed by finding fingerprint)
# ---------------------------------------------------------------------------

_VALID_LIFECYCLE_STATUSES = ("acknowledged", "fixed")


def set_finding_status(
    session: Session,
    *,
    user_id: str | None,
    project_id: str | None,
    fingerprint: str,
    status: str,
    note: str | None = None,
) -> FindingStatus:
    """Upsert a lifecycle status for one finding fingerprint in a project.

    ``status`` must be ``acknowledged`` or ``fixed`` (``new`` is the
    implicit default = no row). The project must belong to the caller.
    """
    if status not in _VALID_LIFECYCLE_STATUSES:
        raise ValueError(f"Invalid finding status: {status!r}")
    if project_id is not None and get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    existing = session.execute(
        select(FindingStatus).where(
            FindingStatus.project_id == project_id,
            FindingStatus.fingerprint == fingerprint,
            _owner_clause(FindingStatus, user_id),
        )
    ).scalars().all()
    # NOTE: no scalar_one_or_none() here. The (project_id, fingerprint)
    # unique constraint does not apply when project_id IS NULL (NULL≠NULL
    # in SQL), so concurrent anonymous upserts can leave duplicate rows;
    # consolidate them instead of raising MultipleResultsFound.
    if not existing:
        row = FindingStatus(
            user_id=user_id,
            project_id=project_id,
            fingerprint=fingerprint,
            status=status,
            note=note,
        )
        session.add(row)
        session.flush()
        return row
    row = existing[0]
    for dup in existing[1:]:
        session.delete(dup)
    row.status = status
    row.note = note
    row.updated_at = _utcnow()
    session.flush()
    return row


def get_finding_statuses(
    session: Session, *, user_id: str | None, project_id: str | None
) -> list[FindingStatus]:
    """All lifecycle rows for a project (tenant-scoped)."""
    if project_id is not None and get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    return list(
        session.execute(
            select(FindingStatus)
            .where(
                FindingStatus.project_id == project_id,
                _owner_clause(FindingStatus, user_id),
            )
            .order_by(FindingStatus.updated_at.desc())
        ).scalars()
    )


def get_latest_repo_analysis(
    session: Session, *, user_id: str | None, project_id: str
) -> RepoAnalysis | None:
    """Most recent repo analysis in a project (for retest)."""
    if get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    return session.execute(
        select(RepoAnalysis)
        .where(
            RepoAnalysis.project_id == project_id,
            _owner_clause(RepoAnalysis, user_id),
        )
        .order_by(RepoAnalysis.created_at.desc())
    ).scalars().first()


def get_latest_website_scan(
    session: Session, *, user_id: str | None, project_id: str
) -> WebsiteScan | None:
    """Most recent website scan in a project (for retest)."""
    if get_project(session, user_id, project_id) is None:
        raise LookupError(f"Project not found: {project_id}")
    return session.execute(
        select(WebsiteScan)
        .where(
            WebsiteScan.project_id == project_id,
            _owner_clause(WebsiteScan, user_id),
        )
        .order_by(WebsiteScan.created_at.desc())
    ).scalars().first()
