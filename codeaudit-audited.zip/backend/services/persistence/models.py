"""Phase 7 — SQLAlchemy ORM entities.

Portability rules (SQLite dev default, Postgres production target):
- Primary keys are 32-char hex UUIDs (``String(32)``), generated in
  Python — no database-specific UUID or sequence types.
- Datetimes are naive UTC (``datetime.now(timezone.utc).replace(tzinfo=None)``);
  SQLite cannot store tz-aware values and Postgres semantics differ, so we
  standardize on naive UTC everywhere and document it.
- JSON payloads are stored as TEXT via ``json.dumps`` — no JSON/JSONB
  column types, no SQLite-only functions.
- No server-side defaults, triggers, or partial indexes.

``users`` is the tenant root. ``projects`` belong to users; analyses,
scans, and jobs belong to projects (optionally) and always to the user
who created them (``user_id`` nullable only for the pre-auth anonymous
dev path). The repository layer (``repository.py``) scopes every query
by ``user_id`` — tenant isolation is enforced there, not just at the
HTTP layer.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _utcnow() -> datetime:
    """Naive UTC now. See module docstring for why naive."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _new_id() -> str:
    return uuid.uuid4().hex


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)

    api_keys: Mapped[list["ApiKey"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    projects: Mapped[list["Project"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class ApiKey(Base):
    """An API key belongs to a user. Only the salted hash is stored —
    the plaintext is shown once at issuance and never again."""

    __tablename__ = "api_keys"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str] = mapped_column(String(32), ForeignKey("users.id"), nullable=False, index=True)
    # "pbkdf2-sha256$<iterations>$<salt_hex>$<hash_hex>"
    key_hash: Mapped[str] = mapped_column(String(256), nullable=False)
    # Non-secret prefix ("ca_XXXXXXXX") for identification in logs/UI.
    key_prefix: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False, default="")
    # JSON list of scopes, e.g. ["read", "scan"].
    scopes: Mapped[str] = mapped_column(Text, nullable=False, default='["read"]')
    revoked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    user: Mapped[User] = relationship(back_populates="api_keys")


class Project(Base):
    """Tenant root for scans. A project belongs to exactly one user."""

    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("users.id"), nullable=True, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)

    user: Mapped[User | None] = relationship(back_populates="projects")


class RepoAnalysis(Base):
    """One repository analysis run. Summary only — findings live in
    ``finding_snapshots`` as immutable per-scan records."""

    __tablename__ = "repo_analyses"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("users.id"), nullable=True, index=True)
    project_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("projects.id"), nullable=True, index=True
    )
    repository_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="done")
    findings_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    risk_score: Mapped[float | None] = mapped_column(nullable=True)
    # JSON summary: risk breakdown, file accounting, agent/ai metadata.
    summary_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class WebsiteScan(Base):
    """One authorized live website scan. Summary only — findings live in
    ``finding_snapshots``. Never stores caller credentials."""

    __tablename__ = "website_scans"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("users.id"), nullable=True, index=True)
    project_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("projects.id"), nullable=True, index=True
    )
    target_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default="done")
    findings_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    urls_scanned: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    truncated: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    # JSON summary: scope, checks_run, requests_made, duration_ms, disclaimer.
    summary_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class FindingSnapshot(Base):
    """Immutable per-scan finding record. Written once when a scan
    completes; never updated. ``owner_type`` is ``repo_analysis`` or
    ``website_scan``; ``owner_id`` is the corresponding row id."""

    __tablename__ = "finding_snapshots"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    owner_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    owner_id: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # Full serialized Finding JSON (evidence included; secrets stay redacted
    # because detectors redact before findings are built — Phase 4).
    finding_json: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)


class ScanJob(Base):
    """Durable background job. ``kind`` is ``repo_analysis`` or
    ``website_scan``. ``state`` transitions: queued -> running ->
    done | failed | cancelled. Only queued jobs can be cancelled."""

    __tablename__ = "scan_jobs"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("users.id"), nullable=True, index=True)
    project_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("projects.id"), nullable=True, index=True
    )
    api_key_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("api_keys.id"), nullable=True, index=True
    )
    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    state: Mapped[str] = mapped_column(String(16), nullable=False, default="queued", index=True)
    # JSON-serialized request the worker executes.
    request_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    # JSON-serialized result (AnalysisResult / WebsiteScanResult) when done.
    result_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(64), nullable=True)
    error_message: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class UsageCounter(Base):
    """Per-API-key usage counters — the raw input billing needs later
    (Phase 11). Counters: analyses, scans, ai_calls, ai_tokens."""

    __tablename__ = "usage_counters"
    __table_args__ = (UniqueConstraint("api_key_id", "counter", name="uq_usage_key_counter"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    api_key_id: Mapped[str] = mapped_column(String(32), ForeignKey("api_keys.id"), nullable=False, index=True)
    counter: Mapped[str] = mapped_column(String(32), nullable=False)
    value: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)


class SchemaVersion(Base):
    """Single-row schema version table for the migration story."""

    __tablename__ = "schema_version"

    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    applied_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)


class FindingStatus(Base):
    """Phase 8 — per-finding lifecycle state within a project.

    ``fingerprint`` is the stable finding identity from
    ``services.retest.finding_fingerprint``. ``status`` is
    ``acknowledged`` or ``fixed``; the absence of a row means ``new``.
    Rows are upserted by the repository layer (select-then-write, so
    NULL project_id for the anonymous path is handled without relying
    on NULL-sensitive unique constraints).
    """

    __tablename__ = "finding_statuses"

    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=_new_id)
    user_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("users.id"), nullable=True, index=True
    )
    project_id: Mapped[str | None] = mapped_column(
        String(32), ForeignKey("projects.id"), nullable=True, index=True
    )
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    note: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_utcnow)

    __table_args__ = (
        UniqueConstraint("project_id", "fingerprint", name="uq_status_project_fp"),
    )
