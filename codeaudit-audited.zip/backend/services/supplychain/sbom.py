"""Software Bill of Materials: an honest inventory of declared dependencies.

The SBOM is built from the manifests the scanner discovered, using the
same parsers as dependency analysis. Field names follow CycloneDX
conventions (bomFormat, specVersion, components) because that is the
vocabulary SBOM consumers expect — but this is a *CycloneDX-inspired
inventory*, not a claim of full spec compliance, and the document says
so in its own metadata.

Honesty rules:
  * Only declared dependencies appear. Transitive closure is NOT
    computed (that would require resolving the dependency graph, i.e.
    network access or installed packages).
  * Versions come from lockfiles/pins when known; otherwise the version
    is the literal string "unspecified" — never guessed.
  * The advisory database status is recorded in metadata, so a consumer
    can see whether vulnerability data was current when the SBOM was made.
"""

from __future__ import annotations

from datetime import datetime, timezone

from models.schemas import RepositoryMetadata
from services.supplychain.manifests import Dependency, parse_manifest_file

_BOM_FORMAT = "CycloneDX"
_SPEC_VERSION = "1.5"
_TOOL_NAME = "codeaudit-agent"
_TOOL_VERSION = "0.4.0"


def collect_dependencies(contents: dict[str, str]) -> list[Dependency]:
    """Parse every manifest in ``contents`` into dependency records."""
    dependencies: list[Dependency] = []
    for relative_path in sorted(contents):
        name = relative_path.replace("\\", "/").rsplit("/", 1)[-1].lower()
        from services.supplychain.manifests import MANIFEST_FILENAMES

        if name not in MANIFEST_FILENAMES:
            continue
        deps, _parse_error = parse_manifest_file(relative_path, contents[relative_path])
        dependencies.extend(deps)
    # Stable order for deterministic output.
    dependencies.sort(
        key=lambda d: (d.ecosystem, d.name.lower(), d.file, d.pinned_version or "")
    )
    return dependencies


def _purl(dep: Dependency) -> str | None:
    """Package URL (https://github.com/package-url/purl-spec), when known."""
    if not dep.pinned_version:
        return None
    if dep.ecosystem == "pypi":
        return f"pkg:pypi/{dep.name.lower()}@{dep.pinned_version}"
    if dep.ecosystem == "npm":
        return f"pkg:npm/{dep.name.lower()}@{dep.pinned_version}"
    return None


def build_sbom(
    dependencies: list[Dependency],
    repository: RepositoryMetadata | None = None,
    advisory_status: str = "unavailable",
    advisory_generated_at: str | None = None,
) -> dict:
    """Build the SBOM document from parsed dependency records."""
    components = []
    for dep in dependencies:
        # bom-ref must be unique per component (CycloneDX): the same
        # package@version can appear in several manifests, so the
        # manifest path disambiguates.
        component: dict = {
            "bom-ref": (
                f"{dep.ecosystem}:{dep.name}"
                f"@{dep.pinned_version or 'unspecified'}"
                f":{dep.file}"
            ),
            "type": "library",
            "name": dep.name,
            "version": dep.pinned_version or "unspecified",
            "scope": "required" if dep.direct else "optional",
            "evidence": {
                "occurrences": [{"location": f"{dep.file}:{dep.line}" if dep.line else dep.file}]
            },
        }
        purl = _purl(dep)
        if purl:
            component["purl"] = purl
        if dep.raw_spec:
            component["version_specifier"] = dep.raw_spec
        components.append(component)

    metadata: dict = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "tools": [
            {
                "vendor": "CodeAudit",
                "name": _TOOL_NAME,
                "version": _TOOL_VERSION,
            }
        ],
        "notes": (
            "CycloneDX-inspired dependency inventory produced by static "
            "manifest parsing. Only declared dependencies are listed; the "
            "transitive closure is not resolved. Versions marked "
            "'unspecified' were not pinned in the manifest. This document "
            "does not claim full CycloneDX specification compliance."
        ),
        "advisory_database": {
            "status": advisory_status,
            "generated_at": advisory_generated_at,
        },
    }
    if repository is not None:
        metadata["component"] = {
            "type": "application",
            "name": f"{repository.owner}/{repository.name}",
            "version": "unspecified",
        }
    return {
        "bomFormat": _BOM_FORMAT,
        "specVersion": _SPEC_VERSION,
        "version": 1,
        "metadata": metadata,
        "components": components,
    }


def build_sbom_for_scan(
    contents: dict[str, str],
    repository: RepositoryMetadata | None = None,
    advisory_status: str = "unavailable",
    advisory_generated_at: str | None = None,
) -> dict:
    """Parse manifests from scan contents and build the SBOM document."""
    dependencies = collect_dependencies(contents)
    return build_sbom(dependencies, repository, advisory_status, advisory_generated_at)


__all__ = ["collect_dependencies", "build_sbom", "build_sbom_for_scan"]
