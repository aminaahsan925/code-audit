"""Dependency manifest parsers: extract (name, version, ecosystem) without
executing anything.

Supported manifests:
  Python: requirements.txt, setup.py (AST, never executed), pyproject.toml,
          Pipfile, Pipfile.lock
  JavaScript: package.json, package-lock.json

Every parser is total: unparseable content yields an empty list (or a
recorded parse error via ``parse_manifest``), never an exception. Version
specifiers are normalized with ``packaging`` (PEP 440) for Python and kept
as raw npm range strings for JavaScript; advisory matching only runs when
a concrete installed version is known (lockfiles) or the specifier pins
exactly one version (``==``).
"""

from __future__ import annotations

import ast
import json
import logging
import re
import tomllib
from dataclasses import dataclass, field

from packaging.requirements import InvalidRequirement, Requirement

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Dependency:
    """One dependency extracted from a manifest file."""

    name: str
    ecosystem: str  # "pypi" | "npm"
    file: str  # manifest relative path
    line: int  # 1-based line of the declaration (0 when unknown)
    raw_spec: str = ""  # the version specifier as written, e.g. "==1.2.3"
    pinned_version: str | None = None  # concrete version when known
    direct: bool = True
    # True when the version came from a lockfile (actually installed).
    from_lockfile: bool = False


# Filenames (exact, case-insensitive) that carry dependency manifests.
MANIFEST_FILENAMES = frozenset(
    {
        "requirements.txt",
        "requirements-dev.txt",
        "requirements-test.txt",
        "setup.py",
        "pyproject.toml",
        "pipfile",
        "pipfile.lock",
        "package.json",
        "package-lock.json",
        "npm-shrinkwrap.json",
    }
)


def is_manifest_file(relative_path: str) -> bool:
    """Whether this path is a supported dependency manifest."""
    name = relative_path.replace("\\", "/").rsplit("/", 1)[-1].lower()
    return name in MANIFEST_FILENAMES


def ecosystem_for(relative_path: str) -> str | None:
    name = relative_path.replace("\\", "/").rsplit("/", 1)[-1].lower()
    if name in {
        "requirements.txt",
        "requirements-dev.txt",
        "requirements-test.txt",
        "setup.py",
        "pyproject.toml",
        "pipfile",
        "pipfile.lock",
    }:
        return "pypi"
    if name in {"package.json", "package-lock.json", "npm-shrinkwrap.json"}:
        return "npm"
    return None


def normalize_pypi_name(name: str) -> str:
    """PEP 503 normalization for advisory lookups."""
    return re.sub(r"[-_.]+", "-", name).lower()


# ---------------------------------------------------------------------------
# requirements.txt
# ---------------------------------------------------------------------------

_REQ_LINE_RE = re.compile(r"^\s*([A-Za-z0-9_.\-\[\]]+)\s*(.*?)\s*(?:[#;].*)?$")


def parse_requirements_txt(content: str, path: str) -> list[Dependency]:
    deps: list[Dependency] = []
    for lineno, raw in enumerate(content.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Includes, constraints, options, editable installs: cannot be
        # resolved hermetically; skipped (documented limitation).
        if line.startswith(("-", "--")) or "://" in line or line.startswith("."):
            continue
        # PEP 508 direct reference: pkg @ https://...
        if "@" in line and "://" in line:
            name = line.split("@")[0].strip()
            if name:
                deps.append(
                    Dependency(name=name, ecosystem="pypi", file=path,
                               line=lineno, raw_spec=line)
                )
            continue
        match = _REQ_LINE_RE.match(raw)
        if not match:
            continue
        name, spec = match.group(1), match.group(2).strip().rstrip("\\").strip()
        # Strip pip options (e.g. --hash=sha256:..., --no-binary): they are
        # not part of the version specifier and would corrupt pinning.
        spec = re.split(r"\s+--", spec, maxsplit=1)[0].strip()
        # Strip extras: requests[security]==2.31 -> requests
        name = name.split("[")[0]
        if not name:
            continue
        pinned = _pinned_from_spec(spec)
        deps.append(
            Dependency(
                name=name, ecosystem="pypi", file=path, line=lineno,
                raw_spec=spec, pinned_version=pinned,
            )
        )
    return deps


def _pinned_from_spec(spec: str) -> str | None:
    """Concrete version when the specifier pins exactly one (``==1.2.3``)."""
    spec = spec.strip().rstrip(",").strip()
    if spec.startswith("==") and not spec.startswith("==="):
        version = spec[2:].strip().split(",")[0].strip()
        # "==1.2.*" is a prefix match, not a pin.
        if version and not version.endswith("*") and ";" not in version:
            return version
    return None


# ---------------------------------------------------------------------------
# setup.py (AST only — never executed)
# ---------------------------------------------------------------------------

def parse_setup_py(content: str, path: str) -> list[Dependency]:
    """Extract install_requires / extras_require via AST (never executed)."""
    deps: list[Dependency] = []
    try:
        tree = ast.parse(content)
    except (SyntaxError, ValueError):
        return deps
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        func_name = func.id if isinstance(func, ast.Name) else (
            func.attr if isinstance(func, ast.Attribute) else ""
        )
        if func_name != "setup":
            continue
        for kw in node.keywords:
            if kw.arg == "install_requires":
                deps.extend(_req_list_from_ast(kw.value, path, node.lineno, True))
            elif kw.arg == "extras_require":
                if isinstance(kw.value, ast.Dict):
                    for v in kw.value.values:
                        deps.extend(_req_list_from_ast(v, path, node.lineno, False))
    return deps


def _req_list_from_ast(
    node: ast.AST, path: str, lineno: int, direct: bool
) -> list[Dependency]:
    deps: list[Dependency] = []
    if not isinstance(node, (ast.List, ast.Tuple)):
        return deps
    for elt in node.elts:
        if not (isinstance(elt, ast.Constant) and isinstance(elt.value, str)):
            continue
        text = elt.value.strip()
        if not text or text.startswith(("-", ".")) or "://" in text:
            continue
        try:
            req = Requirement(text)
        except InvalidRequirement:
            continue
        pinned = _pinned_from_spec(str(req.specifier))
        deps.append(
            Dependency(
                name=req.name, ecosystem="pypi", file=path,
                line=getattr(elt, "lineno", lineno),
                raw_spec=str(req.specifier), pinned_version=pinned,
                direct=direct,
            )
        )
    return deps


# ---------------------------------------------------------------------------
# pyproject.toml / Pipfile (TOML, stdlib)
# ---------------------------------------------------------------------------

def _toml_load(content: str) -> dict | None:
    try:
        return tomllib.loads(content)
    except tomllib.TOMLDecodeError:
        return None


def _dep_from_pep508(
    text: str, path: str, lineno: int, direct: bool, ecosystem: str = "pypi"
) -> Dependency | None:
    text = text.strip()
    if not text:
        return None
    try:
        req = Requirement(text)
    except InvalidRequirement:
        # Bare name without specifier.
        if re.fullmatch(r"[A-Za-z0-9_.\-]+", text):
            return Dependency(name=text, ecosystem=ecosystem, file=path,
                              line=lineno, raw_spec="")
        return None
    return Dependency(
        name=req.name, ecosystem=ecosystem, file=path, line=lineno,
        raw_spec=str(req.specifier),
        pinned_version=_pinned_from_spec(str(req.specifier)),
        direct=direct,
    )


def parse_pyproject_toml(content: str, path: str) -> list[Dependency]:
    data = _toml_load(content)
    if not data:
        return []
    deps: list[Dependency] = []
    project = data.get("project", {})
    if not isinstance(project, dict):
        return deps
    for req_text in project.get("dependencies", []) or []:
        dep = _dep_from_pep508(str(req_text), path, 0, True)
        if dep:
            deps.append(dep)
    optional = project.get("optional-dependencies", {}) or {}
    if isinstance(optional, dict):
        for req_list in optional.values():
            for req_text in req_list or []:
                dep = _dep_from_pep508(str(req_text), path, 0, False)
                if dep:
                    deps.append(dep)
    return deps


def parse_pipfile(content: str, path: str) -> list[Dependency]:
    data = _toml_load(content)
    if not data:
        return []
    deps: list[Dependency] = []
    for section, direct in (("packages", True), ("dev-packages", False)):
        entries = data.get(section, {}) or {}
        if not isinstance(entries, dict):
            continue
        for name, spec in entries.items():
            if isinstance(spec, dict):
                spec_text = str(spec.get("version", "") or "")
            else:
                spec_text = str(spec or "")
            spec_text = spec_text.strip()
            if spec_text in ("*", ""):
                deps.append(Dependency(name=name, ecosystem="pypi", file=path,
                                       line=0, raw_spec=spec_text, direct=direct))
                continue
            dep = _dep_from_pep508(f"{name}{spec_text}", path, 0, direct)
            if dep:
                deps.append(dep)
            else:
                deps.append(Dependency(name=name, ecosystem="pypi", file=path,
                                       line=0, raw_spec=spec_text, direct=direct))
    return deps


def parse_pipfile_lock(content: str, path: str) -> list[Dependency]:
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return []
    deps: list[Dependency] = []
    for section, direct in (("default", True), ("develop", False)):
        entries = data.get(section, {}) or {}
        if not isinstance(entries, dict):
            continue
        for name, meta in entries.items():
            version = ""
            if isinstance(meta, dict):
                version = str(meta.get("version", "") or "").lstrip("=")
            deps.append(
                Dependency(name=name, ecosystem="pypi", file=path, line=0,
                           raw_spec=f"=={version}" if version else "",
                           pinned_version=version or None,
                           direct=direct, from_lockfile=True)
            )
    return deps


# ---------------------------------------------------------------------------
# package.json / package-lock.json
# ---------------------------------------------------------------------------

_NPM_SECTIONS = (
    ("dependencies", True),
    ("optionalDependencies", True),
    ("peerDependencies", False),
    ("devDependencies", False),
)


def parse_package_json(content: str, path: str) -> list[Dependency]:
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return []
    if not isinstance(data, dict):
        return []
    deps: list[Dependency] = []
    for section, direct in _NPM_SECTIONS:
        entries = data.get(section, {}) or {}
        if not isinstance(entries, dict):
            continue
        for name, spec in entries.items():
            spec_text = str(spec or "").strip()
            deps.append(
                Dependency(
                    name=name, ecosystem="npm", file=path, line=0,
                    raw_spec=spec_text,
                    pinned_version=_npm_pinned(spec_text),
                    direct=direct,
                )
            )
    return deps


def _npm_pinned(spec: str) -> str | None:
    """Concrete version only for exact pins (``1.2.3``, ``=1.2.3``)."""
    spec = spec.strip()
    if re.fullmatch(r"=?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:[-+][0-9A-Za-z.\-]+)?", spec):
        return spec.lstrip("=")
    return None


def parse_package_lock(content: str, path: str) -> list[Dependency]:
    try:
        data = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return []
    if not isinstance(data, dict):
        return []
    deps: list[Dependency] = []
    packages = data.get("packages")
    if isinstance(packages, dict):
        # lockfileVersion >= 7: keys are node_modules paths; "" is the root.
        # A package is direct when the root project declares it: check the
        # root entry's dependency sections (not the key shape — every
        # non-root key contains "node_modules/").
        root_meta = packages.get("", {})
        root_declared: set[str] = set()
        if isinstance(root_meta, dict):
            for section in (
                "dependencies",
                "devDependencies",
                "optionalDependencies",
                "peerDependencies",
            ):
                entries = root_meta.get(section)
                if isinstance(entries, dict):
                    root_declared.update(entries.keys())
        for key, meta in packages.items():
            if not key or not isinstance(meta, dict):
                continue
            # node_modules/a/node_modules/b -> package b
            name = key.split("node_modules/")[-1]
            if not name or "/" in name.rstrip("/"):
                # Scoped packages contain one slash: @scope/name.
                if not (name.startswith("@") and name.count("/") == 1):
                    continue
            version = str(meta.get("version", "") or "")
            deps.append(
                Dependency(
                    name=name, ecosystem="npm", file=path, line=0,
                    raw_spec=f"={version}" if version else "",
                    pinned_version=version or None,
                    direct=name in root_declared,
                    from_lockfile=True,
                )
            )
        return deps
    legacy = data.get("dependencies")
    if isinstance(legacy, dict):
        for name, meta in legacy.items():
            version = str(meta.get("version", "") or "") if isinstance(meta, dict) else ""
            deps.append(
                Dependency(name=name, ecosystem="npm", file=path, line=0,
                           raw_spec=f"={version}" if version else "",
                           pinned_version=version or None,
                           direct=True, from_lockfile=True)
            )
            _collect_nested(name, meta, path, deps)
    return deps


def _collect_nested(parent: str, meta: object, path: str, deps: list[Dependency]) -> None:
    if not isinstance(meta, dict):
        return
    nested = meta.get("dependencies")
    if not isinstance(nested, dict):
        return
    for name, sub in nested.items():
        version = str(sub.get("version", "") or "") if isinstance(sub, dict) else ""
        deps.append(
            Dependency(name=f"{parent}>{name}", ecosystem="npm", file=path,
                       line=0, raw_spec=f"={version}" if version else "",
                       pinned_version=version or None,
                       direct=False, from_lockfile=True)
        )
        _collect_nested(f"{parent}>{name}", sub, path, deps)


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def parse_manifest_file(
    relative_path: str, content: str
) -> tuple[list[Dependency], str | None]:
    """Parse one manifest. Returns (dependencies, parse_error).

    ``parse_error`` is a short human-readable reason when the file was
    recognized but could not be parsed; None on success (including the
    empty-manifest case).
    """
    name = relative_path.replace("\\", "/").rsplit("/", 1)[-1].lower()
    try:
        if name in {"requirements.txt", "requirements-dev.txt", "requirements-test.txt"}:
            return parse_requirements_txt(content, relative_path), None
        if name == "setup.py":
            return parse_setup_py(content, relative_path), None
        if name == "pyproject.toml":
            deps = parse_pyproject_toml(content, relative_path)
            if not deps and content.strip():
                # Distinguish "no [project] table" from "broken TOML".
                if _toml_load(content) is None:
                    return [], "invalid TOML"
            return deps, None
        if name == "pipfile":
            deps = parse_pipfile(content, relative_path)
            if not deps and content.strip() and _toml_load(content) is None:
                return [], "invalid TOML"
            return deps, None
        if name == "pipfile.lock":
            try:
                json.loads(content)
            except (json.JSONDecodeError, ValueError):
                return [], "invalid JSON"
            return parse_pipfile_lock(content, relative_path), None
        if name == "package.json":
            try:
                json.loads(content)
            except (json.JSONDecodeError, ValueError):
                return [], "invalid JSON"
            return parse_package_json(content, relative_path), None
        if name in {"package-lock.json", "npm-shrinkwrap.json"}:
            try:
                json.loads(content)
            except (json.JSONDecodeError, ValueError):
                return [], "invalid JSON"
            return parse_package_lock(content, relative_path), None
    except Exception as exc:  # noqa: BLE001 — parsers must never raise
        logger.warning("Manifest parse failed for %s: %s", relative_path, exc)
        return [], "parser error"
    return [], None


__all__ = [
    "Dependency",
    "MANIFEST_FILENAMES",
    "is_manifest_file",
    "ecosystem_for",
    "normalize_pypi_name",
    "parse_manifest_file",
]
