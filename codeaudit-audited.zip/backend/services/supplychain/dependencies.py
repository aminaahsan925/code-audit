"""Dependency analysis: manifests -> advisories -> findings.

For each supported manifest file, dependencies are extracted (see
``manifests.py``) and every *concretely-versioned* dependency is looked up
in the advisory source. Findings:

  * ``DEP-001`` (dep_vulnerable_package): the installed version falls
    inside a known advisory's affected range. Severity comes from the
    advisory (default HIGH). The finding names the advisory ID, affected
    range, fixed version (when the advisory provides one — never invented),
    and the advisory database status.
  * ``DEP-002`` (dep_unpinned): the manifest entry has no version
    constraint at all (``*``, empty, ``latest``). LOW/informational: the
    installed version is unknowable from the manifest alone.
  * ``DEP-003`` (dep_advisory_db_status): one informational finding per
    manifest when the advisory database is ``stale`` or ``unavailable``,
    disclosing that vulnerability matching was limited or disabled.
  * ``DEP-004`` (dep_manifest_parse_error): the manifest was recognized
    but could not be parsed. LOW.

Honesty rules: advisory matching requires a concrete version (lockfiles or
``==`` pins). A range-only specifier (``>=1.0``, ``^1.2``) is NOT matched
against advisories — guessing which version resolves would fabricate
results. Dependencies with no advisory match and a current database
produce no finding at all (silence, not a clean bill of health).
"""

from __future__ import annotations

import logging

from models.schemas import Category, Confidence, Finding, Severity
from services.supplychain.advisories import AdvisorySource
from services.supplychain.findings import make_finding
from services.supplychain.manifests import (
    Dependency,
    is_manifest_file,
    parse_manifest_file,
)

logger = logging.getLogger(__name__)

# Specifiers that pin nothing: the installed version is unknowable.
_UNPINNED_SPECS = frozenset({"", "*", "latest"})


def _advisory_severity(severity: str) -> Severity:
    return {
        "critical": Severity.CRITICAL,
        "high": Severity.HIGH,
        "medium": Severity.MEDIUM,
        "low": Severity.LOW,
    }.get(severity.strip().lower(), Severity.HIGH)


def _line_of(content: str, lineno: int) -> str:
    lines = content.splitlines()
    if 1 <= lineno <= len(lines):
        return lines[lineno - 1].strip()
    return ""


def analyze_dependencies(
    relative_path: str,
    content: str,
    advisory_source: AdvisorySource,
) -> list[Finding]:
    """Analyze one manifest file. Never raises on bad input."""
    if not is_manifest_file(relative_path):
        return []
    findings: list[Finding] = []
    db_status = advisory_source.status

    dependencies, parse_error = parse_manifest_file(relative_path, content)
    if parse_error is not None:
        findings.append(
            make_finding(
                detector="dep_manifest_parse_error",
                category=Category.SECURITY,
                severity=Severity.LOW,
                title="Dependency manifest could not be parsed",
                description=(
                    f"{relative_path} was recognized as a dependency manifest "
                    f"but could not be parsed ({parse_error}). Its dependencies "
                    "were not analyzed; fix the syntax to restore coverage."
                ),
                relative_path=relative_path,
                line=1,
                evidence=_line_of(content, 1) or relative_path,
                confidence=Confidence.HIGH,
                suggested_fix="Fix the manifest syntax so dependencies can be inventoried.",
                language="manifest",
            )
        )
        return findings

    if db_status != "current":
        findings.append(
            make_finding(
                detector="dep_advisory_db_status",
                category=Category.SECURITY,
                severity=Severity.INFO,
                title=f"Advisory database {db_status}: vulnerability matching limited",
                description=(
                    f"The advisory database is {db_status} "
                    f"(generated_at={advisory_source.generated_at}). "
                    f"{len(dependencies)} dependencies from {relative_path} "
                    "were inventoried (see the SBOM in the result metadata), "
                    "but known-vulnerability matching "
                    + (
                        "used stale data — results may miss recent advisories."
                        if db_status == "stale"
                        else "was disabled — no vulnerability verdicts were made."
                    )
                    + " Refresh the database with "
                    "backend/scripts/refresh_advisories.py."
                ),
                relative_path=relative_path,
                line=1,
                evidence=_line_of(content, 1) or relative_path,
                confidence=Confidence.HIGH,
                suggested_fix=(
                    "Refresh the advisory database, then re-run the analysis."
                ),
                language="manifest",
            )
        )

    for dep in dependencies:
        findings.extend(_analyze_dependency(dep, content, advisory_source, db_status))
    return findings


def _analyze_dependency(
    dep: Dependency,
    content: str,
    advisory_source: AdvisorySource,
    db_status: str,
) -> list[Finding]:
    findings: list[Finding] = []
    line = dep.line if dep.line >= 1 else 1
    evidence = _line_of(content, line) or f"{dep.name} {dep.raw_spec}".strip()

    # Unpinned: no constraint at all.
    if dep.raw_spec.strip().lower() in _UNPINNED_SPECS and not dep.pinned_version:
        findings.append(
            make_finding(
                detector="dep_unpinned",
                category=Category.SECURITY,
                severity=Severity.LOW,
                title=f"Unpinned dependency: {dep.name}",
                description=(
                    f"{dep.name} ({dep.ecosystem}) is declared in "
                    f"{dep.file} with no version constraint. The installed "
                    "version is unknowable from the manifest, so future "
                    "installs may silently pull a vulnerable release. "
                    "Advisory matching was skipped: there is no concrete "
                    f"version to match. Advisory database status: {db_status}."
                ),
                relative_path=dep.file,
                line=line,
                evidence=evidence,
                confidence=Confidence.HIGH,
                suggested_fix=(
                    f"Pin {dep.name} to a reviewed version and commit a "
                    "lockfile (Pipfile.lock, package-lock.json)."
                ),
                language="manifest",
            )
        )
        return findings

    # Advisory matching needs a concrete version. Without one, stay silent:
    # matching a range against advisories would be guessing.
    if not dep.pinned_version:
        return findings
    if db_status == "unavailable":
        return findings

    advisories = advisory_source.lookup(dep.name, dep.pinned_version, dep.ecosystem)
    for advisory in advisories:
        fixed = (
            f" Fixed in {advisory.fixed_version}."
            if advisory.fixed_version
            else " No fixed version recorded in the advisory."
        )
        findings.append(
            make_finding(
                detector="dep_vulnerable_package",
                category=Category.SECURITY,
                severity=_advisory_severity(advisory.severity),
                title=f"Vulnerable dependency: {dep.name} {dep.pinned_version}",
                description=(
                    f"{dep.name} {dep.pinned_version} ({dep.ecosystem}, "
                    f"{'direct' if dep.direct else 'transitive'}, from "
                    f"{dep.file}) is affected by {advisory.id}: "
                    f"{advisory.summary or 'no summary recorded.'} "
                    f"Affected range: {advisory.affected_spec}.{fixed} "
                    f"Advisory database status: {db_status} "
                    f"(generated_at={advisory_source.generated_at})."
                ),
                relative_path=dep.file,
                line=line,
                evidence=evidence,
                confidence=Confidence.HIGH,
                suggested_fix=(
                    f"Upgrade {dep.name} to "
                    f"{advisory.fixed_version or 'a non-affected version'} "
                    "and verify with your lockfile."
                    if advisory.fixed_version
                    else f"Upgrade {dep.name} past the affected range "
                    f"({advisory.affected_spec}) and verify."
                ),
                language="manifest",
            )
        )
    return findings


__all__ = ["analyze_dependencies"]
