"""Supply-chain dispatch: which analyzers run on which files.

File-kind detection is filename/path-based (not extension-based like
language detection), because supply-chain files are identified by name:
``Dockerfile``, ``requirements.txt``, ``.github/workflows/*.yml``.

Two concepts:
  * *Structural* analyzers (manifests, Dockerfile, workflows, compose):
    these determine the accounting bucket — a file they cover counts as
    deep-analyzed instead of unsupported.
  * The *secret* analyzer runs on every scanned file regardless of kind;
    it is a cross-cutting pass and does not change the bucket.

The orchestrator calls :func:`analyze_supplychain_file` once per scanned
file (with a single shared advisory source per analysis) and
:func:`supplychain_covered_files` for accounting.
"""

from __future__ import annotations

import logging
import os

from models.schemas import Finding
from services.supplychain.advisories import AdvisorySource, LocalAdvisoryDB
from services.supplychain.config import (
    analyze_compose,
    analyze_dockerfile,
    analyze_github_workflow,
    is_compose_file,
    is_dockerfile,
    is_github_workflow,
)
from services.supplychain.dependencies import analyze_dependencies
from services.supplychain.manifests import is_manifest_file
from services.supplychain.secrets import analyze_secrets

logger = logging.getLogger(__name__)

_DEFAULT_DB_RELATIVE = os.path.join("data", "advisories.json")


def default_advisory_db_path() -> str:
    """<backend>/data/advisories.json, resolved from this file's location."""
    backend_dir = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    return os.path.join(backend_dir, _DEFAULT_DB_RELATIVE)


def get_advisory_source(cfg=None) -> LocalAdvisoryDB:
    """Build the advisory source from settings (fresh read per analysis)."""
    from app.config import settings as default_settings

    cfg = cfg or default_settings
    raw = (getattr(cfg, "advisory_db_path", "") or "").strip()
    max_age = int(getattr(cfg, "advisory_max_age_days", 30) or 30)
    path = raw or default_advisory_db_path()
    return LocalAdvisoryDB(path, max_age_days=max_age)


def has_structural_analyzer(relative_path: str) -> bool:
    """Whether a supply-chain file-kind analyzer covers this path."""
    return (
        is_manifest_file(relative_path)
        or is_dockerfile(relative_path)
        or is_github_workflow(relative_path)
        or is_compose_file(relative_path)
    )


def supplychain_covered_files(relative_paths: list[str]) -> set[str]:
    """Paths covered by a structural supply-chain analyzer (for accounting)."""
    return {p for p in relative_paths if has_structural_analyzer(p)}


def analyze_supplychain_file(
    relative_path: str,
    content: str,
    advisory_source: AdvisorySource,
) -> list[Finding]:
    """Run every applicable supply-chain analyzer on one file.

    Secrets run on all files; structural analyzers run by file kind.
    Never raises on bad input (each analyzer is total).
    """
    findings: list[Finding] = []
    try:
        findings.extend(analyze_secrets(relative_path, content))
        if is_manifest_file(relative_path):
            findings.extend(
                analyze_dependencies(relative_path, content, advisory_source)
            )
        if is_dockerfile(relative_path):
            findings.extend(analyze_dockerfile(relative_path, content))
        if is_github_workflow(relative_path):
            findings.extend(analyze_github_workflow(relative_path, content))
        if is_compose_file(relative_path):
            findings.extend(analyze_compose(relative_path, content))
    except Exception:  # noqa: BLE001 — supply-chain must never break analysis
        logger.exception("Supply-chain analysis failed for %s", relative_path)
    findings.sort(key=lambda f: (f.file, f.line, f.detector))
    return findings


__all__ = [
    "default_advisory_db_path",
    "get_advisory_source",
    "has_structural_analyzer",
    "supplychain_covered_files",
    "analyze_supplychain_file",
]
