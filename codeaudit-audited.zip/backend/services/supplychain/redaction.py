"""Secret redaction: evidence must never carry a complete secret value.

Every secret detector in this package produces evidence with the secret
itself replaced by a redacted placeholder (``sk-live-****abcd``): enough
for a human to identify *which* credential leaked, never enough to use it.

The evidence validator (``services/finding_validator.py``) understands
this scheme: for findings marked ``sensitive``, it checks that every
literal fragment of the redacted evidence appears in order in the cited
line, instead of requiring a verbatim substring match.
"""

from __future__ import annotations

REDACTION_MARKER = "****"


def redact_secret_value(value: str) -> str:
    """Redact one secret value, keeping just enough to identify it.

    ``sk-live-abc123def456`` -> ``sk-live-****f456``. Values too short to
    split safely collapse to ``****``.
    """
    value = value.strip().strip("\"'").strip()
    if len(value) <= 8:
        return REDACTION_MARKER
    if "-" in value:
        # Keep the scheme prefix (e.g. "sk-live", "AKIA" has no dash) so the
        # credential type stays recognizable, plus the last 4 characters.
        prefix = value.split("-", 1)[0]
        return f"{prefix}-{REDACTION_MARKER}{value[-4:]}"
    return f"{value[:3]}{REDACTION_MARKER}{value[-4:]}"


def redact_line(line: str, secrets: list[str]) -> str:
    """Replace every occurrence of each secret in ``line`` with its redaction.

    Longer secrets are replaced first so a short secret that is a substring
    of a longer one cannot corrupt the longer redaction.
    """
    redacted = line
    for secret in sorted(set(secrets), key=len, reverse=True):
        if secret and secret in redacted:
            redacted = redacted.replace(secret, redact_secret_value(secret))
    return redacted


__all__ = ["REDACTION_MARKER", "redact_secret_value", "redact_line"]
