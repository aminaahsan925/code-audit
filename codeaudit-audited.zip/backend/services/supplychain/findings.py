"""Shared finding constructor for supply-chain analyzers.

Mirrors the contract of the language analyzers' ``_make_finding`` helpers:
stable ``detector:path:line`` IDs, rule attribution stamped from the rule
registry (never invented), deterministic source. Adds two supply-chain
needs: ``sensitive`` marking (secret findings) and ``language`` override
(the file-kind that produced the finding, e.g. "dockerfile").
"""

from __future__ import annotations

from models.schemas import Category, Confidence, Finding, FindingSource, Severity
from services.languages.rule_registry import get_rule


def make_finding(
    *,
    detector: str,
    category: Category,
    severity: Severity,
    title: str,
    description: str,
    relative_path: str,
    line: int,
    evidence: str,
    confidence: Confidence,
    suggested_fix: str | None = None,
    language: str | None = None,
    sensitive: bool = False,
    column: int | None = None,
) -> Finding:
    finding_id = f"{detector}:{relative_path}:{line}"
    rule = get_rule(detector)
    return Finding(
        id=finding_id,
        category=category,
        severity=severity,
        title=title,
        description=description,
        file=relative_path,
        line=line,
        column=column,
        evidence=evidence,
        suggested_fix=suggested_fix,
        confidence=confidence,
        source=FindingSource.DETERMINISTIC,
        detector=detector,
        language=language,
        rule_id=rule.rule_id if rule is not None else None,
        cwe_ids=list(rule.cwe_ids) if rule is not None else [],
        sensitive=sensitive,
    )


__all__ = ["make_finding"]
