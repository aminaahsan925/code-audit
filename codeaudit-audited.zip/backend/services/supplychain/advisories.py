"""Advisory source: known-vulnerable package versions.

An ``AdvisorySource`` answers one question: "is this (ecosystem, package,
version) affected by a known advisory?" Two honesty rules are load-bearing:

1. NEVER invent an advisory. A lookup with no match returns an empty list,
   and a dependency with no advisory data produces at most an informational
   inventory finding — never a fabricated vulnerability.
2. Every dependency finding carries ``database_status``: ``current``,
   ``stale``, or ``unavailable``. A stale or missing database is disclosed
   on the finding itself, so a "no known vulnerabilities" result can never
   be mistaken for a guarantee.

The bundled implementation is ``LocalAdvisoryDB``: a JSON file the user
refreshes with ``backend/scripts/refresh_advisories.py`` (OSV.dev).
Matching is conservative: the installed version must fall inside the
advisory's affected range, evaluated with ``packaging`` (PEP 440) for PyPI
and a small explicit npm-range evaluator for npm. Unparseable ranges never
match (fail-closed toward silence).
"""

from __future__ import annotations

import json
import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version

from services.supplychain.manifests import normalize_pypi_name

logger = logging.getLogger(__name__)

# A database older than this is reported as stale, not current.
DEFAULT_MAX_AGE_DAYS = 30


@dataclass(frozen=True)
class Advisory:
    """One known-vulnerable package version range."""

    id: str  # e.g. "CVE-2024-12345", "GHSA-abcd-efgh-ijkl", "PYSEC-..."
    package: str
    ecosystem: str  # "pypi" | "npm"
    affected_spec: str  # version range, e.g. ">=2.0,<2.0.1" (PEP 440 / npm)
    fixed_version: str | None = None
    severity: str = "high"  # critical | high | medium | low
    summary: str = ""
    published: str | None = None
    url: str | None = None


class AdvisorySource(ABC):
    """Answers "is this package@version affected by a known advisory?"."""

    @abstractmethod
    def lookup(
        self, name: str, version: str, ecosystem: str
    ) -> list[Advisory]:
        """Advisories affecting this exact installed version (may be empty)."""
        ...

    @property
    @abstractmethod
    def status(self) -> str:
        """'current' | 'stale' | 'unavailable'."""
        ...

    @property
    @abstractmethod
    def generated_at(self) -> str | None:
        """ISO-8601 timestamp of the underlying data, if known."""
        ...


def _version_in_spec(version: str, spec: str, ecosystem: str) -> bool:
    """Conservative range check. Unparseable input never matches."""
    spec = (spec or "").strip()
    version = (version or "").strip()
    if not spec or not version:
        return False
    try:
        if ecosystem == "pypi":
            return Version(version) in SpecifierSet(spec)
        if ecosystem == "npm":
            return _npm_satisfies(version, spec)
    except (InvalidVersion, InvalidSpecifier, ValueError):
        return False
    return False


_NPM_NUMERIC = re.compile(r"^(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$")


def _npm_tuple(version: str) -> tuple[int, int, int] | None:
    match = _NPM_NUMERIC.match(version.strip().lstrip("=v"))
    if not match:
        return None
    return tuple(int(g) for g in match.groups())  # type: ignore[return-value]


def _npm_satisfies(version: str, spec: str) -> bool:
    """Minimal npm range evaluator: ^, ~, >=, <=, >, <, exact, hyphen-free.

    Only the forms we can evaluate exactly are supported; anything else
    (x-ranges, hyphen ranges, ||, tags like 'latest') returns False rather
    than guessing.
    """
    ver = _npm_tuple(version)
    if ver is None:
        return False
    spec = spec.strip()
    # Exact pin, with or without leading =/v.
    if _NPM_NUMERIC.match(spec.lstrip("=v")) and not spec[0] in "^~<>":
        return _npm_tuple(spec) == ver
    # Compound comparators: ">=1.2.3 <2.0.0".
    parts = spec.split()
    if len(parts) > 1:
        return all(_npm_satisfies(version, p) for p in parts)
    for prefix, op in ((">=", "ge"), ("<=", "le"), (">", "gt"), ("<", "lt")):
        if spec.startswith(prefix):
            bound = _npm_tuple(spec[len(prefix):])
            if bound is None:
                return False
            return {"ge": ver >= bound, "le": ver <= bound,
                    "gt": ver > bound, "lt": ver < bound}[op]
    if spec.startswith("^"):
        bound = _npm_tuple(spec[1:])
        if bound is None:
            return False
        major, minor, _patch = bound
        if major > 0:
            upper = (major + 1, 0, 0)
        elif minor > 0:
            upper = (0, minor + 1, 0)
        else:
            upper = (0, 0, bound[2] + 1)
        return bound <= ver < upper
    if spec.startswith("~"):
        bound = _npm_tuple(spec[1:])
        if bound is None:
            return False
        return bound <= ver < (bound[0], bound[1] + 1, 0)
    return False


class LocalAdvisoryDB(AdvisorySource):
    """JSON-file advisory database.

    Schema::

        {
          "generated_at": "2026-10-02T12:00:00+00:00",   # ISO-8601
          "source": "https://api.osv.dev",
          "advisories": [
            {"id": "CVE-...", "package": "django", "ecosystem": "pypi",
             "affected_spec": ">=4.0,<4.2.11", "fixed_version": "4.2.11",
             "severity": "high", "summary": "...", "published": "...",
             "url": "..."}
          ]
        }

    Status semantics: missing file / unreadable / unparseable ->
    ``unavailable``; ``generated_at`` older than ``max_age_days`` (or
    missing/unparseable) -> ``stale``; otherwise ``current``.
    """

    def __init__(self, path: str, max_age_days: int = DEFAULT_MAX_AGE_DAYS):
        self.path = path
        self.max_age_days = max_age_days
        self._advisories: list[Advisory] = []
        self._generated_at: str | None = None
        self._load_error: str | None = None
        self._load()

    def _load(self) -> None:
        try:
            with open(self.path, encoding="utf-8") as fh:
                data = json.load(fh)
        except FileNotFoundError:
            self._load_error = "database file not found"
            return
        except (OSError, ValueError) as exc:
            self._load_error = f"unreadable: {exc}"
            return
        if not isinstance(data, dict):
            self._load_error = "top-level JSON is not an object"
            return
        generated = data.get("generated_at")
        self._generated_at = generated if isinstance(generated, str) else None
        advisories = data.get("advisories", [])
        if not isinstance(advisories, list):
            self._load_error = "'advisories' is not a list"
            return
        for entry in advisories:
            if not isinstance(entry, dict):
                continue
            try:
                self._advisories.append(
                    Advisory(
                        id=str(entry.get("id", "")),
                        package=str(entry.get("package", "")),
                        ecosystem=str(entry.get("ecosystem", "")),
                        affected_spec=str(entry.get("affected_spec", "")),
                        fixed_version=entry.get("fixed_version"),
                        severity=str(entry.get("severity", "high") or "high"),
                        summary=str(entry.get("summary", "") or ""),
                        published=entry.get("published"),
                        url=entry.get("url"),
                    )
                )
            except (TypeError, ValueError):
                continue

    @property
    def generated_at(self) -> str | None:
        return self._generated_at

    @property
    def status(self) -> str:
        if self._load_error is not None:
            return "unavailable"
        if not self._generated_at:
            return "stale"
        try:
            generated = datetime.fromisoformat(self._generated_at)
        except ValueError:
            return "stale"
        if generated.tzinfo is None:
            generated = generated.replace(tzinfo=timezone.utc)
        age = datetime.now(timezone.utc) - generated
        if age > timedelta(days=self.max_age_days):
            return "stale"
        return "current"

    def lookup(
        self, name: str, version: str, ecosystem: str
    ) -> list[Advisory]:
        """Advisories whose affected range contains this exact version."""
        if ecosystem == "pypi":
            wanted = normalize_pypi_name(name)
            key = lambda a: normalize_pypi_name(a.package)  # noqa: E731
        else:
            wanted = name.lower()
            key = lambda a: a.package.lower()  # noqa: E731
        matches = []
        for advisory in self._advisories:
            if advisory.ecosystem != ecosystem:
                continue
            if key(advisory) != wanted:
                continue
            if _version_in_spec(version, advisory.affected_spec, ecosystem):
                matches.append(advisory)
        return matches

    def __len__(self) -> int:
        return len(self._advisories)


__all__ = [
    "Advisory",
    "AdvisorySource",
    "LocalAdvisoryDB",
    "DEFAULT_MAX_AGE_DAYS",
]
