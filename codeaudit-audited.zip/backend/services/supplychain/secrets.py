"""Secret detection across every scanned file.

Beyond the language-specific hardcoded-secret rules (``PY-SEC-001``,
``JS-SEC-006``, which fire on secret-*named* assignments in code), this
module catches secrets by *value shape* wherever they appear: PEM private
keys, AWS keys, GitHub tokens, Google API keys, Stripe-style keys, plus a
generic high-entropy fallback for secret-named assignments in non-code
files (``.env``, configs, YAML, Dockerfiles, ...).

Dedup contract with the language detectors (no double-reporting):
  * Language detectors *defer* values matching a known token pattern
    (see :func:`matches_known_token_pattern`): the SECRET-* finding is the
    single report for that secret.
  * ``SECRET-006`` (generic high-entropy) does not run on ``.py``/``.js``/
    ``.jsx``/``.ts``/``.tsx`` files: ``PY-SEC-001``/``JS-SEC-006`` already
    own name-based assignment detection there.

CRITICAL honesty rules:
  * Evidence is ALWAYS redacted (``redact_line``): ``sk-live-****abcd``.
    The complete secret value never appears in a finding, report, log, or
    AI context.
  * Every finding from this module is marked ``sensitive=True``: the AI
    context builder excludes sensitive findings and their files, and the
    evidence validator uses a redaction-aware check for them.
"""

from __future__ import annotations

import logging
import math
import re

from models.schemas import Category, Confidence, Finding, Severity
from services.supplychain.findings import make_finding
from services.supplychain.redaction import redact_line
from utils.constants import SECRET_NAME_HINTS, SECRET_PLACEHOLDER_HINTS

logger = logging.getLogger(__name__)

# Extensions whose name-based secret assignments are owned by the language
# analyzers (PY-SEC-001 / JS-SEC-006). SECRET-006 stays out of these files.
_CODE_SECRET_EXTENSIONS = frozenset({".py", ".js", ".jsx", ".ts", ".tsx"})

# --- Known token patterns: (detector, compiled regex, description) --------

# Matches a whole PEM private-key block (headers + base64 body), for
# redacting key material out of AI-bound contexts.
_PEM_BLOCK_RE = re.compile(
    r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"
    r".*?"
    r"-----END (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----",
    re.DOTALL,
)

_TOKEN_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "secret_pem_key",
        re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"),
        "PEM-encoded private key",
    ),
    (
        "secret_aws_key",
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        "AWS access key ID",
    ),
    (
        "secret_github_token",
        re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}\b"),
        "GitHub token",
    ),
    (
        "secret_google_api_key",
        re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"),
        "Google API key",
    ),
    (
        "secret_stripe_key",
        re.compile(r"\bsk-(?:live|test)-[0-9A-Za-z]{16,}\b"),
        "Stripe-style secret key",
    ),
)

# Values that are documentation examples, not real credentials.
_EXAMPLE_HINTS = ("example", "xxx", "***", "sample", "fake", "testkey")


def matches_known_token_pattern(value: str) -> str | None:
    """Detector name whose token pattern matches ``value``, else None.

    Used by the language hardcoded-secret detectors to defer: when a
    secret-like assignment's value already matches a known token shape,
    the SECRET-* finding (redacted, sensitive) is the single report and
    the language detector stays silent.
    """
    for detector, pattern, _ in _TOKEN_PATTERNS:
        if pattern.search(value):
            return detector
    return None


def _is_example(value: str) -> bool:
    lowered = value.lower()
    return any(hint in lowered for hint in _EXAMPLE_HINTS)


def redact_known_tokens_in_text(text: str) -> str:
    """Redact every known token shape (SECRET-001..005) in free text.

    Used for AI-bound contexts (fix windows) where the raw secret must not
    appear even outside the finding's own evidence line. PEM blocks are
    redacted whole: the header line carries no key material, but the
    base64 body between the headers is the actual private key and must
    never reach the AI provider.
    """
    from services.supplychain.redaction import redact_secret_value

    redacted = text
    for detector, pattern, _label in _TOKEN_PATTERNS:
        if detector == "secret_pem_key":
            continue
        def _replace(match: re.Match[str]) -> str:
            token = match.group(0)
            if _is_example(token):
                return token
            return redact_secret_value(token)

        redacted = pattern.sub(_replace, redacted)
    # PEM key material: redact the entire block (headers + base64 body).
    redacted = _PEM_BLOCK_RE.sub("[REDACTED PRIVATE KEY BLOCK]", redacted)
    return redacted


def _looks_secret_name(name: str) -> bool:
    lowered = name.lower()
    return any(hint in lowered for hint in SECRET_NAME_HINTS)


def _is_placeholder(value: str) -> bool:
    lowered = value.lower()
    return (
        len(value.strip()) < 4
        or any(hint in lowered for hint in SECRET_PLACEHOLDER_HINTS)
        or lowered.startswith(("os.environ", "getenv", "$"))
        or value.strip().startswith("${")
    )


def _shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    counts: dict[str, int] = {}
    for ch in text:
        counts[ch] = counts.get(ch, 0) + 1
    length = len(text)
    return -sum((c / length) * math.log2(c / length) for c in counts.values())


_GENERIC_ASSIGN_RE = re.compile(
    r"""(?:^|[\s;])                        # start of line or after separator
        (?:export\s+)?                     # optional shell export
        ([A-Za-z_][A-Za-z0-9_]*)           # variable name
        \s*[:=]\s*                         # separator
        ["']?                              # optional quote
        ([^\s"'#;]+)                       # the value (no spaces/quotes)
        """,
    re.VERBOSE,
)

# Obvious non-secrets even when the name looks secret-like.
_NON_SECRET_VALUES = re.compile(
    r"^(true|false|yes|no|none|null|undefined|0|1|/[^ ]*|[a-z]+://.*)$",
    re.IGNORECASE,
)


def _generic_high_entropy_findings(
    relative_path: str, lineno: int, line: str, language: str | None = None
) -> list[Finding]:
    """SECRET-006: secret-named assignments with high-entropy values.

    Every ``NAME=<high-entropy>`` pair on the line gets its own finding
    (the old ``^``-anchored match saw only the first pair). Each finding's
    evidence redacts *all* secret values on the line, so a sibling secret
    never leaks in cleartext via another finding's evidence.
    """
    pairs: list[tuple[str, str]] = []  # (name, value)
    for match in _GENERIC_ASSIGN_RE.finditer(line):
        name, value = match.group(1), match.group(2).strip().strip("\"'").strip()
        if not _looks_secret_name(name):
            continue
        if (
            not value
            or len(value) < 12
            or _is_placeholder(value)
            or _is_example(value)
            or matches_known_token_pattern(value)
            or _NON_SECRET_VALUES.match(value)
        ):
            continue
        if _shannon_entropy(value) < 4.5:
            continue
        pairs.append((name, value))
    if not pairs:
        return []
    all_values = [value for _, value in pairs]
    stripped = line.strip()
    findings: list[Finding] = []
    for name, value in pairs:
        findings.append(
            make_finding(
                detector="secret_high_entropy",
                category=Category.SECURITY,
                severity=Severity.HIGH,
                title="High-entropy secret-like value",
                description=(
                    f"Assignment to '{name}' holds a high-entropy string that looks "
                    "like a generated credential. It is committed to the repository "
                    "in cleartext."
                ),
                relative_path=relative_path,
                line=lineno,
                evidence=redact_line(stripped, all_values),
                confidence=Confidence.MEDIUM,
                suggested_fix=(
                    "Move the value to an environment variable or secrets manager "
                    "and rotate it; high-entropy strings in repos are routinely "
                    "harvested by scanners."
                ),
                language=language,
                sensitive=True,
            )
        )
    return findings


_SEVERITY_BY_DETECTOR = {
    "secret_pem_key": Severity.HIGH,
    "secret_aws_key": Severity.HIGH,
    "secret_github_token": Severity.HIGH,
    "secret_google_api_key": Severity.HIGH,
    "secret_stripe_key": Severity.HIGH,
}

_TITLE_BY_DETECTOR = {
    "secret_pem_key": "Private key committed to repository",
    "secret_aws_key": "AWS access key committed to repository",
    "secret_github_token": "GitHub token committed to repository",
    "secret_google_api_key": "Google API key committed to repository",
    "secret_stripe_key": "Stripe-style secret key committed to repository",
}

_FIX_BY_DETECTOR = {
    "secret_pem_key": (
        "Delete the key from the repository history (it is compromised the "
        "moment it is pushed), generate a new key pair, and never commit "
        "private keys — use a secrets manager or mounted secret files."
    ),
    "secret_aws_key": (
        "Revoke the access key in the AWS console immediately, issue a new "
        "one, and load it from an environment variable or secrets manager."
    ),
    "secret_github_token": (
        "Revoke the token in GitHub settings immediately and replace it with "
        "a securely stored credential (environment variable, Actions secret)."
    ),
    "secret_google_api_key": (
        "Regenerate the API key in Google Cloud Console, restrict it by API "
        "and referrer/IP, and stop committing it."
    ),
    "secret_stripe_key": (
        "Roll the key in the Stripe dashboard immediately and load it from "
        "an environment variable at runtime."
    ),
}


def _language_for_path(relative_path: str) -> str | None:
    """Best-effort language attribution for a secret finding.

    A secret found in app.js is a finding about a JavaScript file; one in
    a Dockerfile or .env has no language analyzer and stays None. This is
    attribution for reporting, not a claim about the secret itself.
    """
    name = relative_path.rsplit("/", 1)[-1]
    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return {
        ".py": "python",
        ".js": "javascript",
        ".jsx": "javascript",
        ".ts": "typescript",
        ".tsx": "typescript",
    }.get(ext)


def analyze_secrets(relative_path: str, content: str) -> list[Finding]:
    """Run all secret detectors over one file's content.

    Runs on every scanned file regardless of language. Findings are
    redacted and marked sensitive. Never raises on bad input.
    """
    findings: list[Finding] = []
    extension = "." + relative_path.rsplit(".", 1)[-1].lower() if "." in relative_path.rsplit("/", 1)[-1] else ""
    allow_generic = extension not in _CODE_SECRET_EXTENSIONS
    language = _language_for_path(relative_path)

    for lineno, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        if not stripped:
            continue
        # Collect ALL token matches on the line first: a finding's evidence
        # must redact every secret on the line, not just its own, so a
        # second secret never leaks in cleartext via a sibling finding.
        matches: list[tuple[str, str, str]] = []  # (detector, token, label)
        for detector, pattern, label in _TOKEN_PATTERNS:
            for match in pattern.finditer(line):
                token = match.group(0)
                if _is_example(token):
                    continue
                matches.append((detector, token, label))
        all_tokens = [token for _, token, _ in matches]
        for detector, token, label in matches:
            if detector == "secret_pem_key":
                # The BEGIN line carries no key material; the finding
                # points at the key block that follows.
                evidence = stripped
            else:
                evidence = redact_line(stripped, all_tokens)
            findings.append(
                make_finding(
                    detector=detector,
                    category=Category.SECURITY,
                    severity=_SEVERITY_BY_DETECTOR[detector],
                    title=_TITLE_BY_DETECTOR[detector],
                    description=(
                        f"A {label} appears in this file in cleartext. "
                        "Anyone with repository read access can copy it; "
                        "assume it is compromised and rotate it."
                    ),
                    relative_path=relative_path,
                    line=lineno,
                    evidence=evidence,
                    confidence=Confidence.HIGH,
                    suggested_fix=_FIX_BY_DETECTOR[detector],
                    language=language,
                    sensitive=True,
                )
            )
        if matches or not allow_generic:
            continue
        findings.extend(
            _generic_high_entropy_findings(
                relative_path, lineno, line, language
            )
        )

    # One finding per (detector, line, description, evidence): overlapping
    # patterns on the same line collapse to the first match already;
    # dedupe defensively. The description is part of the key so that two
    # SECRET-006 findings for different variables on one line (whose
    # fully-redacted evidence is identical) are not collapsed into one.
    seen: set[tuple[str, int, str, str]] = set()
    unique: list[Finding] = []
    for finding in findings:
        key = (finding.detector, finding.line, finding.description, finding.evidence)
        if key not in seen:
            seen.add(key)
            unique.append(finding)
    return unique


__all__ = ["analyze_secrets", "matches_known_token_pattern"]
