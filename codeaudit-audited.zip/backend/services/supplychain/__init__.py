"""Supply-chain security analyzers: dependencies, secrets, configuration.

Each submodule is import-safe on its own (no package-level side effects),
so language analyzers can import helpers (e.g. token-pattern deferral)
without pulling the whole package.
"""

from services.supplychain.dispatch import (
    analyze_supplychain_file,
    default_advisory_db_path,
    get_advisory_source,
    has_structural_analyzer,
    supplychain_covered_files,
)
from services.supplychain.manifests import parse_manifest_file
from services.supplychain.dependencies import analyze_dependencies
from services.supplychain.secrets import analyze_secrets
from services.supplychain.config import (
    analyze_compose,
    analyze_dockerfile,
    analyze_github_workflow,
)
from services.supplychain.sbom import build_sbom_for_scan

__all__ = [
    "analyze_supplychain_file",
    "default_advisory_db_path",
    "get_advisory_source",
    "has_structural_analyzer",
    "supplychain_covered_files",
    "parse_manifest_file",
    "analyze_dependencies",
    "analyze_secrets",
    "analyze_compose",
    "analyze_dockerfile",
    "analyze_github_workflow",
    "build_sbom_for_scan",
]
