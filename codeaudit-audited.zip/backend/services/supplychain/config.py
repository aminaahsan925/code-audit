"""Infrastructure and CI/CD configuration scanning.

Deterministic, line-based checks for:
  * Dockerfiles (``Dockerfile``, ``Dockerfile.*``): root user, ``latest``
    tags, secrets in ENV/ARG, ADD-vs-COPY, curl-pipe-shell.
  * GitHub Actions workflows (``.github/workflows/*.yml|*.yaml``):
    ``permissions: write-all``, ``pull_request_target`` + checkout,
    unpinned third-party actions.
  * Compose files (``docker-compose*.yml|yaml``, ``compose*.yml|yaml``):
    ``privileged: true``, secrets in ``environment:``.

These are deliberately line-based, not YAML-parsed: the backend takes no
YAML dependency, and the checks target line-local patterns (an instruction,
a key, a ``uses:`` reference). The trade-off is documented on every rule:
multi-line block scalars, anchors, and deeply nested structures can hide
a pattern from these checks. They are a first net, not a proof of absence.
"""

from __future__ import annotations

import logging
import re

from models.schemas import Category, Confidence, Finding, Severity
from services.supplychain.findings import make_finding
from services.supplychain.redaction import redact_line
from utils.constants import SECRET_NAME_HINTS, SECRET_PLACEHOLDER_HINTS

logger = logging.getLogger(__name__)


def _stripped_lines(content: str) -> list[tuple[int, str]]:
    """(lineno, line) with full-line comments removed, empties dropped."""
    result = []
    for lineno, raw in enumerate(content.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        result.append((lineno, line))
    return result


def _looks_secret_name(name: str) -> bool:
    lowered = name.lower()
    return any(hint in lowered for hint in SECRET_NAME_HINTS)


def _is_placeholder(value: str) -> bool:
    # Unquote first: ENV DB_PASSWORD="" captures as '""', which is empty.
    stripped = value.strip().strip("\"'").strip()
    lowered = stripped.lower()
    return (
        not stripped
        or any(hint in lowered for hint in SECRET_PLACEHOLDER_HINTS)
        or lowered.startswith("$")
        or stripped.startswith("${")
    )


def _unquote(value: str) -> str:
    """Strip one layer of surrounding quotes from a captured ENV value."""
    return value.strip().strip("\"'").strip()


# ---------------------------------------------------------------------------
# Kind detection
# ---------------------------------------------------------------------------

def is_dockerfile(relative_path: str) -> bool:
    name = relative_path.replace("\\", "/").rsplit("/", 1)[-1]
    lowered = name.lower()
    return lowered == "dockerfile" or lowered.startswith("dockerfile.")


def is_github_workflow(relative_path: str) -> bool:
    lowered = relative_path.replace("\\", "/").lower()
    return (
        ".github/workflows/" in lowered
        and (lowered.endswith(".yml") or lowered.endswith(".yaml"))
    )


def is_compose_file(relative_path: str) -> bool:
    name = relative_path.replace("\\", "/").rsplit("/", 1)[-1].lower()
    return (
        name.startswith("docker-compose.") or name.startswith("compose.")
    ) and (name.endswith(".yml") or name.endswith(".yaml"))


# ---------------------------------------------------------------------------
# Dockerfile
# ---------------------------------------------------------------------------

_FROM_RE = re.compile(r"^FROM\s+(?:--\S+\s+)*(\S+)", re.IGNORECASE)
# Quoted values are captured whole ("[^"]*" / '[^']*'); otherwise the
# value truncates at the first space and most of a quoted secret leaks
# into evidence in cleartext.
_ENV_ARG_RE = re.compile(
    r"""^(?:ENV|ARG)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("[^"]*"|'[^']*'|\S+)""",
    re.IGNORECASE,
)
_CURL_PIPE_RE = re.compile(
    r"\b(?:curl|wget)\b[^|]*\|\s*(?:sudo\s+)?(?:sh|bash|zsh)\b", re.IGNORECASE
)


def analyze_dockerfile(relative_path: str, content: str) -> list[Finding]:
    """Line-based Dockerfile checks. Never raises on bad input."""
    findings: list[Finding] = []
    lines = _stripped_lines(content)
    if not lines:
        return findings

    first_from: tuple[int, str] | None = None
    has_user = False
    for lineno, line in lines:
        upper = line.upper()
        from_match = _FROM_RE.match(line)
        if from_match is not None:
            # Every build stage is latest-tag checked, not just the first.
            if first_from is None:
                first_from = (lineno, line)
            image = from_match.group(1)
            # Implicit ":latest" when no tag/digest is present.
            if ":" not in image.split("/")[-1] and "@" not in image:
                findings.append(
                    make_finding(
                        detector="cfg_docker_latest_tag",
                        category=Category.SECURITY,
                        severity=Severity.LOW,
                        title="Dockerfile uses the implicit 'latest' tag",
                        description=(
                            f"FROM {image} has no tag, so builds resolve "
                            "the mutable 'latest' tag. Rebuilds can "
                            "silently change the base image, including to "
                            "a vulnerable one."
                        ),
                        relative_path=relative_path,
                        line=lineno,
                        evidence=line,
                        confidence=Confidence.HIGH,
                        suggested_fix=(
                            "Pin the base image to an immutable tag or "
                            "digest (e.g. FROM image:1.2.3 or "
                            "FROM image@sha256:...)."
                        ),
                        language="dockerfile",
                    )
                )
            elif re.search(r":latest\b", image, re.IGNORECASE):
                findings.append(
                    make_finding(
                        detector="cfg_docker_latest_tag",
                        category=Category.SECURITY,
                        severity=Severity.LOW,
                        title="Dockerfile pins the 'latest' tag",
                        description=(
                            f"FROM {image} pins the mutable 'latest' tag; "
                            "rebuilds can silently change the base image."
                        ),
                        relative_path=relative_path,
                        line=lineno,
                        evidence=line,
                        confidence=Confidence.HIGH,
                        suggested_fix=(
                            "Pin an immutable tag or digest instead of "
                            "'latest'."
                        ),
                        language="dockerfile",
                    )
                )
            continue
        if upper.startswith("USER "):
            has_user = True
        if upper.startswith("ADD "):
            findings.append(
                make_finding(
                    detector="cfg_docker_add",
                    category=Category.SECURITY,
                    severity=Severity.LOW,
                    title="Dockerfile uses ADD instead of COPY",
                    description=(
                        "ADD auto-extracts local tarballs and can fetch "
                        "remote URLs, which makes builds less predictable "
                        "than COPY."
                    ),
                    relative_path=relative_path,
                    line=lineno,
                    evidence=line,
                    confidence=Confidence.HIGH,
                    suggested_fix="Prefer COPY; use curl/RUN for remote fetches.",
                    language="dockerfile",
                )
            )
        env_match = _ENV_ARG_RE.match(line)
        if env_match:
            var_name = env_match.group(1)
            var_value = _unquote(env_match.group(2))
            if _looks_secret_name(var_name) and not _is_placeholder(var_value):
                findings.append(
                    make_finding(
                        detector="cfg_docker_secret_env",
                        category=Category.SECURITY,
                        severity=Severity.HIGH,
                        title=f"Possible secret in Dockerfile {line.split()[0]}: {var_name}",
                        description=(
                            f"{line.split()[0]} sets '{var_name}', which looks "
                            "like a credential. Values baked into image "
                            "layers are visible to anyone who can pull the "
                            "image, and persist in layer history."
                        ),
                        relative_path=relative_path,
                        line=lineno,
                        evidence=redact_line(line, [var_value]),
                        confidence=Confidence.MEDIUM,
                        suggested_fix=(
                            "Pass secrets at runtime (mounted secret files, "
                            "environment from the orchestrator), never bake "
                            "them into the image."
                        ),
                        language="dockerfile",
                        sensitive=True,
                    )
                )
        if upper.startswith("RUN ") and _CURL_PIPE_RE.search(line):
            findings.append(
                make_finding(
                    detector="cfg_docker_curl_pipe",
                    category=Category.SECURITY,
                    severity=Severity.MEDIUM,
                    title="curl-pipe-shell in Dockerfile RUN",
                    description=(
                        "A RUN instruction pipes a downloaded script straight "
                        "into a shell. The fetched code is unreviewed and "
                        "unpinned; a compromised server means arbitrary code "
                        "in the build."
                    ),
                    relative_path=relative_path,
                    line=lineno,
                    evidence=line,
                    confidence=Confidence.HIGH,
                    suggested_fix=(
                        "Vendor the script, verify a checksum/signature, or "
                        "install from a pinned package instead."
                    ),
                    language="dockerfile",
                )
            )

    if not has_user and first_from is not None:
        lineno, line = first_from
        findings.append(
            make_finding(
                detector="cfg_docker_no_user",
                category=Category.SECURITY,
                severity=Severity.HIGH,
                title="Dockerfile has no USER instruction (runs as root)",
                description=(
                    "No USER instruction was found, so the container runs as "
                    "root by default. A container escape or exploited process "
                    "then has full host-adjacent privilege."
                ),
                relative_path=relative_path,
                line=lineno,
                # Evidence is the FROM line: the validator requires evidence
                # to be a substring of the cited line, and "missing USER" has
                # no line of its own.
                evidence=line,
                confidence=Confidence.HIGH,
                suggested_fix=(
                    "Add 'USER <nonroot>' (creating the user first if needed) "
                    "after installing system packages."
                ),
                language="dockerfile",
            )
        )
    return findings


# ---------------------------------------------------------------------------
# GitHub Actions workflows
# ---------------------------------------------------------------------------

_PERMISSIONS_WRITE_ALL_RE = re.compile(
    r"^\s*permissions\s*:\s*write-all\s*(?:#.*)?$", re.IGNORECASE
)
# Block/list forms inside an `on:` block (indent-tracked below).
_PR_TARGET_KEY_RE = re.compile(
    r"^\s*(?:-\s*)?pull_request_target\s*:?\s*(?:#.*)?$", re.IGNORECASE
)
# Inline form: `on: pull_request_target` or `on: [push, pull_request_target]`.
_ON_INLINE_RE = re.compile(r"^\s*on\s*:(.*)$", re.IGNORECASE)
_USES_RE = re.compile(r"^\s*(?:-\s*)?uses\s*:\s*(\S+)", re.IGNORECASE)
_CHECKOUT_RE = re.compile(
    r"uses\s*:\s*actions/checkout@", re.IGNORECASE
)


def _raw_lines(content: str) -> list[tuple[int, str]]:
    """(lineno, raw line) with full-line comments and blanks removed.

    Unlike _stripped_lines, leading indentation is preserved: the
    workflow/compose checks need it to track block structure.
    """
    result = []
    for lineno, raw in enumerate(content.splitlines(), 1):
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        result.append((lineno, raw.rstrip()))
    return result


def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip())


def analyze_github_workflow(relative_path: str, content: str) -> list[Finding]:
    """Line-based workflow checks. Never raises on bad input."""
    findings: list[Finding] = []
    if not _raw_lines(content):
        return findings

    has_pr_target = False
    pr_target_line: tuple[int, str] | None = None
    has_checkout = False
    # Track the `on:` trigger block by indentation so `pull_request_target`
    # is only recognized as a trigger (not a stray word elsewhere).
    in_on_block = False
    on_indent = 0
    for lineno, raw in _raw_lines(content):
        line = raw.strip()
        indent = _indent_of(raw)
        on_inline = _ON_INLINE_RE.match(raw)
        if on_inline is not None:
            on_indent = indent
            rest = on_inline.group(1).strip()
            if "pull_request_target" in rest.lower():
                has_pr_target = True
                pr_target_line = (lineno, line)
                in_on_block = False
            else:
                # Block form follows (`on:` alone on the line).
                in_on_block = not rest
        elif in_on_block:
            if indent <= on_indent:
                in_on_block = False
            elif _PR_TARGET_KEY_RE.match(raw):
                has_pr_target = True
                pr_target_line = (lineno, line)
        if _PERMISSIONS_WRITE_ALL_RE.match(line):
            findings.append(
                make_finding(
                    detector="cfg_gha_write_all",
                    category=Category.SECURITY,
                    severity=Severity.HIGH,
                    title="Workflow grants permissions: write-all",
                    description=(
                        "permissions: write-all gives every job the maximum "
                        "token scope. A compromised action or script can then "
                        "push code, publish releases, or exfiltrate secrets."
                    ),
                    relative_path=relative_path,
                    line=lineno,
                    evidence=line,
                    confidence=Confidence.HIGH,
                    suggested_fix=(
                        "Scope permissions per job to the minimum needed "
                        "(e.g. permissions: contents: read)."
                    ),
                    language="github-actions",
                )
            )
        # NOTE: pull_request_target trigger detection is handled by the
        # indent-aware `on:` block tracking at the top of the loop.
        if _CHECKOUT_RE.search(line):
            has_checkout = True
        uses_match = _USES_RE.match(line)
        if uses_match:
            ref = uses_match.group(1)
            # Local and docker actions are out of scope for pinning checks.
            if ref.startswith("./") or ref.startswith("docker://"):
                continue
            if "@" not in ref:
                continue
            _action, _, pin = ref.partition("@")
            # A 40-hex-char pin is a commit SHA (pinned). Anything else —
            # branch, tag, short SHA — is flagged.
            if not re.fullmatch(r"[0-9a-fA-F]{40}", pin):
                findings.append(
                    make_finding(
                        detector="cfg_gha_unpinned_action",
                        category=Category.SECURITY,
                        severity=Severity.MEDIUM,
                        title=f"Third-party action not pinned to a commit SHA: {ref}",
                        description=(
                            f"uses: {ref} resolves a mutable ref (branch or "
                            "tag). The action owner — or anyone who "
                            "compromises the tag — can change what runs in "
                            "your pipeline without a diff."
                        ),
                        relative_path=relative_path,
                        line=lineno,
                        evidence=line,
                        confidence=Confidence.HIGH,
                        suggested_fix=(
                            "Pin third-party actions to a full 40-char "
                            "commit SHA (with a comment noting the version)."
                        ),
                        language="github-actions",
                    )
                )

    if has_pr_target and has_checkout and pr_target_line is not None:
        lineno, line = pr_target_line
        findings.append(
            make_finding(
                detector="cfg_gha_pull_request_target",
                category=Category.SECURITY,
                severity=Severity.HIGH,
                title="pull_request_target with actions/checkout",
                description=(
                    "pull_request_target runs in the context of the base "
                    "repository with write permissions, and this workflow "
                    "also checks out code. Checking out the PR's code in "
                    "this context is a classic privilege-escalation vector: "
                    "an attacker-crafted PR can run code with elevated "
                    "token permissions."
                ),
                relative_path=relative_path,
                line=lineno,
                evidence=line,
                confidence=Confidence.MEDIUM,
                suggested_fix=(
                    "Avoid checking out untrusted PR code under "
                    "pull_request_target; if checkout is needed, pin "
                    "ref explicitly and never persist credentials."
                ),
                language="github-actions",
            )
        )
    return findings


# ---------------------------------------------------------------------------
# Compose files (small, line-based, documented as such)
# ---------------------------------------------------------------------------

_ENV_ASSIGN_RE = re.compile(
    r"""^\s*(?:-\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*("[^"]*"|'[^']*'|\S+)"""
)


def analyze_compose(relative_path: str, content: str) -> list[Finding]:
    """Two line-based compose checks. Never raises on bad input."""
    findings: list[Finding] = []
    raw_lines = _raw_lines(content)
    if not raw_lines:
        return findings
    in_environment = False
    env_indent = 0
    for lineno, raw in raw_lines:
        line = raw.strip()
        indent = _indent_of(raw)
        if re.match(r"^\s*privileged\s*:\s*true\s*(?:#.*)?$", line, re.IGNORECASE):
            findings.append(
                make_finding(
                    detector="cfg_compose_privileged",
                    category=Category.SECURITY,
                    severity=Severity.MEDIUM,
                    title="Compose service runs privileged",
                    description=(
                        "privileged: true disables container isolation; a "
                        "process in this container can access host devices "
                        "and escape far more easily."
                    ),
                    relative_path=relative_path,
                    line=lineno,
                    evidence=line,
                    confidence=Confidence.HIGH,
                    suggested_fix=(
                        "Drop privileged: true; add only the specific "
                        "capabilities the service needs."
                    ),
                    language="compose",
                )
            )
        # Track whether we are inside an `environment:` block by
        # indentation: a line at or above the block's indent ends it.
        # (Line-based approximation; documented on the rule.)
        if re.match(r"^\s*environment\s*:", raw, re.IGNORECASE):
            in_environment = True
            env_indent = indent
            continue
        if in_environment and indent <= env_indent:
            in_environment = False
        if in_environment:
            env_match = _ENV_ASSIGN_RE.match(line)
            if env_match:
                var_name = env_match.group(1)
                var_value = _unquote(env_match.group(2))
                if _looks_secret_name(var_name) and not _is_placeholder(var_value):
                    findings.append(
                        make_finding(
                            detector="cfg_compose_secret_env",
                            category=Category.SECURITY,
                            severity=Severity.HIGH,
                            title=f"Possible secret in compose environment: {var_name}",
                            description=(
                                f"environment sets '{var_name}', which looks "
                                "like a credential, in cleartext in the "
                                "compose file. It is visible to anyone with "
                                "repository access and lands in container "
                                "inspect output."
                            ),
                            relative_path=relative_path,
                            line=lineno,
                            evidence=redact_line(line, [var_value]),
                            confidence=Confidence.MEDIUM,
                            suggested_fix=(
                                "Use Docker secrets or env_file with a file "
                                "that is not committed."
                            ),
                            language="compose",
                            sensitive=True,
                        )
                    )
    return findings


__all__ = [
    "is_dockerfile",
    "is_github_workflow",
    "is_compose_file",
    "analyze_dockerfile",
    "analyze_github_workflow",
    "analyze_compose",
]
