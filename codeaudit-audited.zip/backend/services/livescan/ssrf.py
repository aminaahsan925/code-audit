"""SSRF guard for live website scanning.

EVERY outbound request the scanner makes passes through
:func:`validate_url` first. The guard is fail-closed:

- Only ``http`` / ``https`` schemes.
- No userinfo (``http://user:pass@host/``).
- The host is resolved with :func:`socket.getaddrinfo` and EVERY resolved
  IP must be globally routable (``ip.is_global``). This single predicate
  rejects private (10/8, 172.16/12, 192.168/16), loopback, link-local
  (including the 169.254.169.254 cloud-metadata address), multicast,
  unspecified, reserved, and documentation ranges. Resolution (not string
  matching) also defeats decimal/octal/hex IP spellings such as
  ``http://2130706433/``.
- ``localhost`` / ``127.0.0.1`` / ``::1`` are rejected unless the operator
  explicitly sets ``CODEAUDIT_SCAN_ALLOW_LOCALHOST=true`` (intended for
  hermetic tests against a fixture server, never for production).
- DNS resolution failure → blocked (fail closed).

Redirects are re-validated per hop by the HTTP client; a redirect chain
that leaves the safe address space is refused.

Known residual risks (documented, not hidden — see docs/SECURITY_MODEL.md):
- DNS TOCTOU: the address checked is the address at check time; a
  rebinding DNS record could resolve differently when the socket
  connects. The scanner keeps connections short-lived and re-validates
  redirects, but a fully determined attacker controlling the target's
  DNS can still race this. Treat the guard as a strong default, not a
  proof against malicious DNS operators.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlsplit

from .errors import SSRFBlockedError

_ALLOWED_SCHEMES = ("http", "https")


@dataclass(frozen=True)
class GuardedURL:
    """A URL that passed the SSRF guard."""

    url: str
    scheme: str
    host: str
    port: int
    resolved_ips: tuple[str, ...]


def _reject(url: str, reason: str) -> SSRFBlockedError:
    # The URL itself is safe to include: it is the scan target, not a
    # credential. Tokens/cookies are never part of URLs here (userinfo
    # is rejected before this point).
    return SSRFBlockedError(f"SSRF guard refused URL {url!r}: {reason}.")


def validate_url(url: str, *, allow_localhost: bool = False) -> GuardedURL:
    """Validate one URL for outbound fetching. Raises SSRFBlockedError."""
    if not url or not isinstance(url, str):
        raise _reject(str(url), "empty or non-string URL")

    try:
        parts = urlsplit(url)
    except ValueError as exc:
        raise _reject(url, f"unparseable URL ({exc})") from exc

    scheme = (parts.scheme or "").lower()
    if scheme not in _ALLOWED_SCHEMES:
        raise _reject(url, f"scheme {scheme!r} is not http/https")

    # Reject userinfo (credentials in URL) — also blocks the
    # http://expected@evil/ confusion shape.
    if parts.username or parts.password or "@" in (parts.netloc or ""):
        raise _reject(url, "userinfo (username/password) in URL is not allowed")

    host = parts.hostname or ""
    if not host:
        raise _reject(url, "no host")

    try:
        port = parts.port
    except ValueError:
        raise _reject(url, "invalid port") from None
    if port is None:
        port = 443 if scheme == "https" else 80

    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise _reject(url, f"host did not resolve ({exc})") from exc
    if not infos:
        raise _reject(url, "host resolved to no addresses")

    resolved: list[str] = []
    for info in infos:
        sockaddr = info[4]
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            raise _reject(url, f"unparseable resolved address {ip_str!r}") from None
        # Explicit property blocklist (do NOT rely on is_global alone:
        # some Python versions report multicast space as global).
        # This covers private (RFC1918 + CGNAT), loopback, link-local
        # (including the 169.254.169.254 cloud-metadata address),
        # multicast, reserved, unspecified, and documentation ranges.
        if ip.is_loopback:
            if not allow_localhost:
                raise _reject(url, f"resolved address {ip_str} is loopback")
        elif (
            ip.is_private
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
            or not ip.is_global
        ):
            raise _reject(
                url,
                f"resolved address {ip_str} is not publicly routable "
                "(private/loopback/link-local/multicast/reserved)",
            )
        resolved.append(ip_str)

    return GuardedURL(
        url=url,
        scheme=scheme,
        host=host.lower(),
        port=port,
        resolved_ips=tuple(dict.fromkeys(resolved)),
    )
