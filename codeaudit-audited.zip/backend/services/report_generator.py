"""Report generator: Phase 1 establishes the interface.

Consumes structured AnalysisResult objects (never raw AI text). Polished
reports and PDF export arrive in a later phase.
"""

from __future__ import annotations

import html

from models.schemas import AnalysisResult


def _ai_line(result: AnalysisResult) -> str:
    """One honest line about what the AI layer did in this run."""
    ai = result.ai
    if ai.status.value == "disabled":
        return "AI: disabled (deterministic analysis only)"
    if ai.status.value == "enabled":
        return (
            f"AI: {ai.provider} enriched {ai.findings_enriched}, accepted "
            f"{ai.ai_findings_accepted} new, dropped {ai.ai_findings_dropped}, "
            f"merged {ai.duplicates_merged} duplicates"
        )
    detail = f" ({ai.error_code})" if ai.error_code else ""
    return f"AI: {ai.status.value}{detail} — deterministic findings retained"


def _agents_section(result: AnalysisResult) -> list[str]:
    """Render the multi-agent execution summary, when present."""
    run = result.agents
    if run is None:
        return []
    lines = [
        "",
        "## Multi-agent execution",
        f"Mode: `{run.mode}` | Agents completed: {run.completed} | "
        f"Nemotron calls: {run.ai_calls}",
    ]
    if result.ai_budget is not None:
        b = result.ai_budget
        lines.append(
            f"AI budget ({b.purpose}): {b.used}/{b.limit} used, "
            f"{b.remaining} remaining"
        )
    for agent in run.agents:
        detail = f"{agent.agent_name}: {agent.status} ({agent.duration_ms} ms"
        if agent.model_calls:
            detail += f", {agent.model_calls} model call(s)"
            if agent.model_used:
                detail += f" via {agent.model_used}"
        if agent.findings_count:
            detail += f", {agent.findings_count} finding(s)"
        if agent.errors:
            detail += f", errors: {'; '.join(agent.errors)}"
        detail += ")"
        lines.append(f"- {detail}")
    return lines


def _provenance_line(finding) -> str | None:
    prov = finding.provenance
    if prov is None:
        return None
    parts = []
    if prov.detected_by:
        parts.append(f"detected by {', '.join(prov.detected_by)}")
    if prov.reviewed_by:
        parts.append(f"reviewed by {', '.join(prov.reviewed_by)}")
    if prov.fixed_by:
        parts.append(f"fixed by {', '.join(prov.fixed_by)}")
    if prov.verified_by:
        parts.append(f"verified by {', '.join(prov.verified_by)}")
    return "Provenance: " + "; ".join(parts) if parts else None


def _knowledge_line(finding) -> str | None:
    # Phase 5: attribute curated knowledge that informed AI explanations.
    ids = getattr(finding, "knowledge_used", None) or []
    if not ids:
        return None
    return (
        "Knowledge consulted (curated guidance, not evidence): "
        + ", ".join(f"[{i}]" for i in ids)
    )


class ReportGenerator:
    """Renders an AnalysisResult into human-readable summaries."""

    def to_markdown(self, result: AnalysisResult) -> str:
        repo = result.repository
        summary = result.summary
        risk = result.risk
        lines = [
            f"# CodeAudit Report — {repo.owner}/{repo.name}",
            "",
            f"Files: {summary.files_discovered} discovered, {summary.files_scanned} scanned "
            f"({summary.files_deep_analyzed} deep-analyzed, {summary.files_unsupported} unsupported, "
            f"{summary.files_skipped} skipped, {summary.files_failed_parse} failed to parse)",
            f"Findings: {summary.findings_total} | Risk: {risk.score}/10 ({risk.level})",
            _ai_line(result),
        ]
        lines.extend(_agents_section(result))
        lines.extend(["", "## Findings"])
        for finding in result.findings:
            lines.extend(
                [
                    "",
                    f"### [{finding.severity.value.upper()}] {finding.title}",
                    f"File: `{finding.file}` line {finding.line} "
                    f"(confidence: {finding.confidence.value}, source: {finding.source.value})",
                    "",
                    "```",
                    finding.evidence,
                    "```",
                    "",
                    finding.description,
                ]
            )
            provenance = _provenance_line(finding)
            if provenance:
                lines.extend(["", provenance])
            knowledge = _knowledge_line(finding)
            if knowledge:
                lines.extend(["", knowledge])
            if finding.suggested_fix:
                lines.extend(["", f"Suggested fix: {finding.suggested_fix}"])
            if finding.ai_reasoning:
                lines.extend(["", f"AI reasoning ({finding.enriched_by}): {finding.ai_reasoning}"])
        return "\n".join(lines) + "\n"

    def to_dict(self, result: AnalysisResult) -> dict:
        """Structured dict form; the JSON API already serializes the model."""
        return result.model_dump(mode="json")

    def to_html(self, result: AnalysisResult) -> str:
        """Self-contained HTML report: inline CSS, no external assets.

        Every dynamic string is HTML-escaped. Secret findings are already
        redacted upstream (Phase 4), so evidence is safe to embed.
        """
        repo = result.repository
        summary = result.summary
        risk = result.risk
        sev_colors = {
            "critical": "#b91c1c",
            "high": "#dc2626",
            "medium": "#d97706",
            "low": "#2563eb",
            "info": "#6b7280",
        }

        def esc(value) -> str:
            return html.escape(str(value), quote=True)

        findings_html = []
        for finding in result.findings:
            sev = finding.severity.value.lower()
            color = sev_colors.get(sev, "#6b7280")
            prov = _provenance_line(finding)
            know = _knowledge_line(finding)
            extras = ""
            if prov:
                extras += f"<p class='meta'>{esc(prov)}</p>"
            if know:
                extras += f"<p class='meta'>{esc(know)}</p>"
            if finding.suggested_fix:
                extras += f"<p><strong>Suggested fix:</strong> {esc(finding.suggested_fix)}</p>"
            if finding.ai_reasoning:
                extras += (
                    f"<p><strong>AI reasoning ({esc(finding.enriched_by or 'ai')}):</strong> "
                    f"{esc(finding.ai_reasoning)}</p>"
                )
            findings_html.append(
                "<section class='finding'>"
                f"<h3><span class='sev' style='background:{color}'>{esc(sev.upper())}</span> "
                f"{esc(finding.title)}</h3>"
                f"<p class='meta'>File: <code>{esc(finding.file)}</code> line {esc(finding.line)} "
                f"| confidence: {esc(finding.confidence.value)} "
                f"| source: {esc(finding.source.value)}</p>"
                f"<pre>{esc(finding.evidence)}</pre>"
                f"<p>{esc(finding.description)}</p>"
                f"{extras}"
                "</section>"
            )

        agents_html = ""
        for line in _agents_section(result):
            if line.startswith("## "):
                agents_html += f"<h2>{esc(line[3:])}</h2>"
            elif line.startswith("- "):
                agents_html += f"<li>{esc(line[2:])}</li>"
            elif line.strip():
                agents_html += f"<p>{esc(line)}</p>"
        if agents_html:
            agents_html = f"<h2>Multi-agent execution</h2><ul>{agents_html}</ul>"

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CodeAudit Report — {esc(repo.owner)}/{esc(repo.name)}</title>
<style>
body {{ font-family: system-ui, -apple-system, sans-serif; max-width: 960px;
margin: 2rem auto; padding: 0 1rem; color: #111827; }}
h1 {{ border-bottom: 3px solid #111827; padding-bottom: .5rem; }}
.finding {{ border: 1px solid #e5e7eb; border-radius: 8px; padding: 1rem;
margin: 1rem 0; }}
.sev {{ color: #fff; border-radius: 4px; padding: .15rem .5rem; font-size: .8rem; }}
pre {{ background: #f3f4f6; padding: .75rem; border-radius: 6px;
overflow-x: auto; font-size: .85rem; }}
.meta {{ color: #6b7280; font-size: .9rem; }}
.risk {{ font-size: 1.25rem; font-weight: bold; }}
.disclaimer {{ background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px;
padding: 1rem; margin-top: 2rem; }}
</style>
</head>
<body>
<h1>CodeAudit Report — {esc(repo.owner)}/{esc(repo.name)}</h1>
<p>Files: {esc(summary.files_discovered)} discovered, {esc(summary.files_scanned)} scanned
({esc(summary.files_deep_analyzed)} deep-analyzed, {esc(summary.files_unsupported)} unsupported,
{esc(summary.files_skipped)} skipped, {esc(summary.files_failed_parse)} failed to parse)</p>
<p class="risk">Risk: {esc(risk.score)}/10 ({esc(risk.level)})</p>
<p>{esc(_ai_line(result))}</p>
{agents_html}
<h2>Findings ({esc(summary.findings_total)})</h2>
{"".join(findings_html)}
<div class="disclaimer"><strong>Scope note:</strong> this report reflects one
analysis run. Absence of findings is not proof of security; findings are
observations grounded in code evidence, not confirmed exploits.</div>
</body>
</html>
"""
