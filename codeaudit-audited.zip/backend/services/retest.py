"""Finding fingerprints and retest diffing (Phase 8).

A fingerprint is a stable identity for a finding across runs so a retest
can tell *new* findings from *persisting* ones and *resolved* ones.

Fingerprint = SHA-256(rule_id | file-or-url | normalized evidence).
Known limitation (documented, not hidden): if the vulnerable code moves
to a different file, or the evidence snippet changes textually, the
fingerprint changes and the finding looks "new" + "resolved" instead of
"persisting". Line numbers are deliberately excluded — a one-line shift
above the finding must not break matching.
"""

from __future__ import annotations

import hashlib


def finding_fingerprint(finding: dict) -> str:
    """Stable 32-hex-char identity for a finding dict."""
    rule = finding.get("rule_id") or finding.get("detector") or "unknown"
    location = finding.get("file") or finding.get("url") or ""
    evidence = finding.get("evidence") or ""
    # Normalize whitespace so trivial formatting drift does not break matching.
    evidence = " ".join(str(evidence).split())
    raw = f"{rule}\x00{location}\x00{evidence}".encode("utf-8", "replace")
    return hashlib.sha256(raw).hexdigest()[:32]


def diff_findings(
    old_findings: list[dict], new_findings: list[dict]
) -> dict[str, list[dict]]:
    """Compare two finding lists by fingerprint.

    Returns {"new": [...], "persisting": [...], "resolved": [...]} where
    each entry is the finding dict from the relevant run (new run for
    "new"/"persisting", old run for "resolved").
    """
    old_map = {finding_fingerprint(f): f for f in old_findings}
    new_map = {finding_fingerprint(f): f for f in new_findings}
    return {
        "new": [new_map[fp] for fp in new_map if fp not in old_map],
        "persisting": [new_map[fp] for fp in new_map if fp in old_map],
        "resolved": [old_map[fp] for fp in old_map if fp not in new_map],
    }
