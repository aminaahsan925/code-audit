# CodeAudit Agent — Demo Frontend (Phase 9)

A static, no-build-step web UI for the CodeAudit backend. Three files,
no npm, no bundler: open `index.html` directly or host it anywhere
static.

## Files

| File | Purpose |
|---|---|
| `index.html` | Page structure: top bar (backend URL + API key), tabs |
| `styles.css` | All styling |
| `app.js` | Vanilla JS: API calls, rendering, job polling |

## Tabs

- **Analyze repo** — `POST /analyze` on a GitHub URL. Optional
  "background job" mode (`?async=true`) polls `GET /jobs/{id}` until
  done. Renders risk score, finding cards with expandable evidence,
  AI status line.
- **Scan website** — `POST /scan/website`. Requires the per-host scan
  token **and** the "I authorize this scan" checkbox (the API 403s
  without both). Optional session cookie for authenticated scans.
- **Findings** — per-project lifecycle. Create/select a project, view
  the latest run's findings with their `acknowledged`/`fixed` status,
  and set statuses (buttons hit
  `POST /projects/{id}/findings/status` with the server-side
  fingerprint).
- **Retest** — `POST /projects/{id}/retest`: re-runs the latest
  analysis/scan and shows new / persisting / resolved findings with
  `verified` / `regressed` annotations. Website retests ask for a
  fresh token + authorization.

## Configuration

- **Backend URL** and **API key** are set in the top bar and persisted
  to `localStorage`. The green/red dot shows `/health` reachability.
- When the backend has `CODEAUDIT_REQUIRE_AUTH=true`, every tab needs
  a valid API key; otherwise the demo works keyless.

## Security notes (shown in the UI too)

- All finding data is HTML-escaped before rendering (evidence is code).
- The scan token / session cookie / API key live only in the browser's
  `localStorage` and request headers — the page never logs them.
- The UI repeats the backend's honesty rules: findings are
  evidence-grounded observations, not confirmed exploits; absence of
  findings is not proof of security.

## Deploy

**Simplest (recommended for the demo):** the backend serves this UI itself
at `/ui` — no CORS configuration, one URL to share. Deploy the repo's
`backend/` with `frontend/` beside it (the standard layout) and open
`https://<your-api>/ui/`. The page defaults to the same origin as its
backend URL in that case.

**Separate static host:** any static host works (Netlify Drop, GitHub
Pages, Vercel). Set the **Backend URL** in the top bar to your deployed
API — the API must then allow the frontend origin via CORS (configure
this on the backend deployment).

## Local preview (Windows PowerShell)

```powershell
# Terminal 1 — backend (from the repo's backend/ directory)
.\.venv\Scripts\python -m uvicorn app.main:app --port 8000

# Terminal 2 — frontend (from the repo's frontend/ directory)
python -m http.server 8080
# open http://localhost:8080
```
